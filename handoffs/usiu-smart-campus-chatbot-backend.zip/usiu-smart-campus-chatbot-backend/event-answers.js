import { EVENTS, EVENTS_PAGE_SOURCE, EVENT_SNAPSHOT_CHECKED } from "./events.js";
import translations from "./fallback-translations.json" with { type: "json" };

const labels = {
  en: { date: "Date", time: "Time", venue: "Venue", admission: "Admission", about: "About", note: "Note", important: "Important", past: "Recent past examples:", upcoming: "Upcoming events:", upcomingShort: "Upcoming events:", checked: "Event information in this guide was checked", dated: "it is a dated snapshot, not a live feed.", updates: "For additions or changes, check the official events page and linked event details.", noPast: "No past event is included in this snapshot.", noFuture: "No future event is recorded in this snapshot; the official listing may have newer announcements.", futureOnly: "I don't have a future event recorded in this snapshot. Check the official listing for newer announcements." },
  sw: { date: "Tarehe", time: "Saa", venue: "Mahali", admission: "Kiingilio", about: "Kuhusu", note: "Dokezo", important: "Muhimu", past: "Mifano ya hivi majuzi ya matukio yaliyopita:", upcoming: "Matukio yajayo:", upcomingShort: "Matukio yajayo:", checked: "Taarifa za matukio katika mwongozo huu zilithibitishwa", dated: "hii ni taarifa ya tarehe fulani, si mtiririko wa moja kwa moja.", updates: "Kwa nyongeza au mabadiliko, angalia ukurasa rasmi wa matukio na maelezo ya matukio yaliyounganishwa.", noPast: "Hakuna tukio lililopita lililojumuishwa katika taarifa hii.", noFuture: "Hakuna tukio la baadaye lililorekodiwa katika taarifa hii; orodha rasmi inaweza kuwa na matangazo mapya zaidi.", futureOnly: "Sina tukio la baadaye katika taarifa hii. Angalia orodha rasmi kwa matangazo mapya zaidi." },
  fr: { date: "Date", time: "Heure", venue: "Lieu", admission: "Entrée", about: "À propos", note: "Remarque", important: "Important", past: "Exemples récents d’événements passés :", upcoming: "Événements à venir :", upcomingShort: "Événements à venir :", checked: "Les informations de ce guide ont été vérifiées le", dated: "il s’agit d’un instantané daté, et non d’un flux en direct.", updates: "Pour les ajouts ou modifications, consultez la page officielle des événements et les détails associés.", noPast: "Aucun événement passé ne figure dans cet instantané.", noFuture: "Aucun événement futur n’est enregistré dans cet instantané ; la liste officielle peut contenir des annonces plus récentes.", futureOnly: "Aucun événement futur ne figure dans cet instantané. Consultez la liste officielle pour les annonces récentes." },
  ar: { date: "التاريخ", time: "الوقت", venue: "المكان", admission: "الدخول", about: "نبذة", note: "ملاحظة", important: "مهم", past: "أمثلة على فعاليات سابقة:", upcoming: "الفعاليات القادمة:", upcomingShort: "الفعاليات القادمة:", checked: "تم التحقق من معلومات الفعاليات في هذا الدليل بتاريخ", dated: "هذه بيانات مؤرخة وليست بثاً مباشراً.", updates: "للاطلاع على الإضافات أو التغييرات، راجع صفحة الفعاليات الرسمية وتفاصيل الفعاليات المرتبطة.", noPast: "لا توجد فعالية سابقة ضمن هذه البيانات.", noFuture: "لا توجد فعالية مستقبلية مسجلة في هذه البيانات؛ وقد تتضمن القائمة الرسمية إعلانات أحدث.", futureOnly: "لا توجد فعالية مستقبلية مسجلة في هذه البيانات. راجع القائمة الرسمية للاطلاع على الإعلانات الأحدث." },
  so: { date: "Taariikh", time: "Waqti", venue: "Goob", admission: "Gelitaan", about: "Ku saabsan", note: "Ogeysiis", important: "Muhiim", past: "Tusaalooyin dhow oo dhacdooyin hore ah:", upcoming: "Dhacdooyinka soo socda:", upcomingShort: "Dhacdooyinka soo socda:", checked: "Macluumaadka dhacdooyinka ee hagahan waxaa la hubiyey", dated: "waa xog taariikh go'an leh, mana aha war toos ah.", updates: "Wax-ku-darro ama isbeddel, ka eeg bogga rasmiga ah ee dhacdooyinka iyo faahfaahinta dhacdooyinka ku xiran.", noPast: "Xogtan kuma jirto dhacdo hore.", noFuture: "Xogtan kuma jirto dhacdo mustaqbal ah; liiska rasmiga ahi wuxuu yeelan karaa ogeysiisyo cusub.", futureOnly: "Xogtan kuma jiro dhacdo mustaqbal ah. Ka eeg liiska rasmiga ah ogeysiisyo cusub." },
  es: { date: "Fecha", time: "Hora", venue: "Lugar", admission: "Entrada", about: "Acerca de", note: "Nota", important: "Importante", past: "Ejemplos recientes de eventos pasados:", upcoming: "Próximos eventos:", upcomingShort: "Próximos eventos:", checked: "La información de eventos de esta guía se verificó el", dated: "es una instantánea fechada, no una transmisión en directo.", updates: "Para ver novedades o cambios, consulta la página oficial de eventos y los detalles enlazados.", noPast: "No hay eventos pasados incluidos en esta instantánea.", noFuture: "No hay eventos futuros registrados en esta instantánea; la lista oficial podría tener anuncios más recientes.", futureOnly: "No tengo eventos futuros registrados en esta instantánea. Consulta la lista oficial para ver novedades." }
};

const eventWords = {
  sw: { event: ["matukio", "tukio"], past: ["yaliyopita", "zamani"], upcoming: ["yajayo", "yanayokuja"] },
  fr: { event: ["événement", "événements", "manifestation"], past: ["passé", "passés", "précédent", "récents"], upcoming: ["à venir", "prochain", "prochains", "futur"] },
  ar: { event: ["فعالية", "فعاليات", "حدث", "أحداث"], past: ["سابقة", "ماضية", "الماضية"], upcoming: ["قادمة", "القادمة", "مستقبلية"] },
  so: { event: ["dhacdo", "dhacdooyinka"], past: ["hore", "dhawaa"], upcoming: ["soo socda", "mustaqbal"] },
  es: { event: ["evento", "eventos"], past: ["pasado", "pasados", "anteriores", "recientes"], upcoming: ["próximos", "próximo", "futuros", "futuro"] }
};
const followUpMarkers = ["more", "tell me more", "what about", "how about", "details", "another", "zaidi", "plus", "أكثر", "dheeraad", "más"];

function todayInNairobi() {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Africa/Nairobi", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const values = Object.fromEntries(parts.filter(part => part.type !== "literal").map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function translatedEvent(event, language) {
  const translated = translations[language]?.events?.[event.id];
  if (!translated) return event;
  return { ...event, ...Object.fromEntries(Object.entries(translated).filter(([, value]) => value !== null && value !== undefined)) };
}

function formatEvent(event, language, words) {
  const item = translatedEvent(event, language);
  const lines = [`• ${item.title}`, `  ${words.date}: ${item.dateLabel}`];
  if (item.timeLabel) lines.push(`  ${words.time}: ${item.timeLabel}`);
  if (item.venue) lines.push(`  ${words.venue}: ${item.venue}`);
  if (item.admission) lines.push(`  ${words.admission}: ${item.admission}`);
  if (item.summary) lines.push(`  ${words.about}: ${item.summary}`);
  if (item.note) lines.push(`  ${words.note}: ${item.note}`);
  return lines.join("\n");
}

function uniqueSources(events, includeListing) {
  const sources = [...(includeListing ? [EVENTS_PAGE_SOURCE] : []), ...events.map(event => event.source)];
  return [...new Map(sources.map(source => [source.url, source])).values()];
}

function answer(text, events, includeListing = true) {
  return { type: "answer", topicId: "events", text, sources: uniqueSources(events, includeListing) };
}

function eventIntent(question, lastTopicId, language) {
  const local = eventWords[language] || {};
  const normalized = question.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const hasEventWord = /\b(?:events?|concerts?|festivals?|conferences?|seminars?|symposiums?)\b/.test(question)
    || (local.event || []).some(word => normalized.includes(word.normalize("NFD").replace(/[\u0300-\u036f]/g, "")));
  const matchesEventName = EVENTS.some(event => event.aliases.some(alias => question.includes(alias)));
  const isFollowUp = lastTopicId === "events" && followUpMarkers.some(marker => question.includes(marker));
  return hasEventWord || matchesEventName || isFollowUp;
}

function listAnswer(question, language) {
  const words = labels[language] || labels.en;
  const local = eventWords[language] || {};
  const today = todayInNairobi();
  const pastOnly = /\b(?:past|previous|recent|last|happened|held|archive|history)\b/.test(question) || (local.past || []).some(word => question.includes(word));
  const upcomingOnly = /\b(?:upcoming|future|coming up|next|happening|will be|what is on|what's on)\b/.test(question) || (local.upcoming || []).some(word => question.includes(word));
  const upcoming = EVENTS.filter(event => event.endDate >= today).sort((a, b) => a.startDate.localeCompare(b.startDate));
  const past = EVENTS.filter(event => event.endDate < today).sort((a, b) => b.endDate.localeCompare(a.endDate));
  const checked = translations[language]?.snapshotChecked || EVENT_SNAPSHOT_CHECKED;
  const sections = [];
  let included = [];

  if (pastOnly && !upcomingOnly) {
    sections.push(words.past);
    included = past;
    sections.push(past.length ? past.map(event => formatEvent(event, language, words)).join("\n\n") : words.noPast);
  } else if (upcomingOnly && !pastOnly) {
    sections.push(words.upcoming);
    included = upcoming;
    sections.push(upcoming.length ? upcoming.map(event => formatEvent(event, language, words)).join("\n\n") : words.futureOnly);
  } else {
    sections.push(words.upcomingShort);
    included = [...upcoming, ...past];
    sections.push(upcoming.length ? upcoming.map(event => formatEvent(event, language, words)).join("\n\n") : words.noFuture);
    sections.push(words.past);
    sections.push(past.length ? past.map(event => formatEvent(event, language, words)).join("\n\n") : words.noPast);
  }
  sections.push(`${words.checked} ${checked}; ${words.dated}`);
  sections.push(words.updates);
  return answer(sections.join("\n\n"), included, true);
}

function detailAnswer(event, language) {
  const words = labels[language] || labels.en;
  const item = translatedEvent(event, language);
  const checked = translations[language]?.snapshotChecked || EVENT_SNAPSHOT_CHECKED;
  const text = [
    item.title,
    `${words.date}: ${item.dateLabel}`,
    item.timeLabel ? `${words.time}: ${item.timeLabel}` : null,
    item.venue ? `${words.venue}: ${item.venue}` : null,
    item.admission ? `${words.admission}: ${item.admission}` : null,
    item.summary ? `${words.about}: ${item.summary}` : null,
    item.note ? `${words.important}: ${item.note}` : null,
    `${words.checked} ${checked}; ${words.updates}`
  ].filter(Boolean).join("\n");
  return answer(text, [event], false);
}

export function findEventAnswer(question, lastTopicId = null, language = "en") {
  if (!eventIntent(question, lastTopicId, language)) return null;
  const matched = EVENTS.find(event => event.aliases.some(alias => question.includes(alias)));
  return matched ? detailAnswer(matched, language) : listAnswer(question, language);
}
