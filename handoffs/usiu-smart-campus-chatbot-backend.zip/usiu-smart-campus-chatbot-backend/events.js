export const EVENT_SNAPSHOT_CHECKED = "9 November 2026";

export const EVENTS_PAGE_SOURCE = {
  label: "USIU-Africa upcoming events",
  url: "https://www.usiu.ac.ke/upcoming-events/"
};

export const EVENTS = [
  {
    id: "rockin-uni-2026",
    title: "Rock’In Uni Comes to USIU-Africa",
    aliases: ["rockin uni", "rock'in uni", "rock in uni"],
    startDate: "2026-11-18",
    endDate: "2026-11-18",
    dateLabel: "18 November 2026",
    timeLabel: "3:00 pm",
    venue: "USIU-Africa Auditorium",
    admission: "Free",
    summary: "The event page says it is hosted in partnership with Rock Data Plus and the USIU-Africa Business Club. Registration details were not specified.",
    source: {
      label: "Rock’In Uni event details",
      url: "https://www.usiu.ac.ke/events/rockin-uni-comes-to-usiu-africa/"
    }
  },
  {
    id: "mr-miss-prejudging-2026",
    title: "Mr. & Miss USIU-Africa 2026 Pre-Judging",
    aliases: ["mr miss usiu", "mr and miss usiu", "pre judging", "pre-judging"],
    startDate: "2026-11-05",
    endDate: "2026-11-06",
    dateLabel: "5–6 November 2026 (official page shows conflicting dates)",
    timeLabel: "Date/time conflict: the detail panel lists 5 November, 5:00 pm–12:00 am; the event description says Friday, 6 November.",
    venue: "USIU-Africa Auditorium",
    admission: "The past listing stated KSh 400 regular, KSh 1,800 for a group of 5, and KSh 3,500 for a group of 10.",
    summary: "A Halloween-themed student pre-judging event for the 2026 Mr. & Miss USIU-Africa competition.",
    note: "The official page is internally inconsistent about the date. Confirm from USIU before relying on the date or time.",
    source: {
      label: "Mr. & Miss USIU-Africa event page",
      url: "https://www.usiu.ac.ke/events/mr-miss-usiu-africa-2026-pre-judging/"
    }
  },
  {
    id: "east-africa-hub-convening-2026",
    title: "2026 East Africa Hub Convening",
    aliases: ["east africa hub convening", "education collaborative convening", "students first"],
    startDate: "2026-10-01",
    endDate: "2026-10-02",
    dateLabel: "1–2 October 2026",
    venue: "USIU-Africa campus and Safari Park Hotel",
    summary: "Hosted by USIU-Africa with The Education Collaborative, the convening brought higher-education leaders together around student-centered, sustainable and technology-enabled campuses.",
    source: {
      label: "East Africa Hub Convening report",
      url: "https://www.usiu.ac.ke/2026-east-africa-hub-convening-african-universities-reimagine-the-future-of-higher-education-with-students-at-the-center/"
    }
  }
];
