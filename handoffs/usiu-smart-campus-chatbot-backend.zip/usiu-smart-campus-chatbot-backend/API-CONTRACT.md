# API contract

## `POST /api/chat`

This is a same-origin, stateless JSON endpoint. The frontend sends the visible recent conversation with every request; the backend does not create or persist a conversation ID.

### Request

`Content-Type: application/json`

```json
{
  "question": "What facilities are available?",
  "history": [
    { "role": "user", "text": "I am visiting campus." },
    { "role": "assistant", "text": "What would you like to know?" }
  ],
  "language": "en"
}
```

Rules:

- `question` is required; after trimming it must contain 1–500 Unicode characters.
- The complete JSON request body is limited to 12,000 bytes.
- `history` is optional. Only `user` and `assistant` roles with string `text` values are accepted; invalid entries are ignored. The last eight entries are considered and each text is trimmed and capped at 1,200 characters.
- `language` is optional. Supported values: `auto`, `en`, `sw`, `fr`, `ar`, `so`, `es`. An unknown value becomes `auto`.
- `message` and `conversationId` are not used. If `question` is omitted, the request is invalid.
- Requests with a non-JSON content type are rejected.

### Success response (`200`)

```json
{
  "answer": "USIU-Africa has ...",
  "sourceIds": ["facilities"],
  "webSources": [
    {
      "label": "Official page",
      "url": "https://www.usiu.ac.ke/example"
    }
  ],
  "destination": null,
  "speechLanguage": "en"
}
```

`answer` is always a readable string. `sourceIds` contains only IDs present in the bundled knowledge/source catalog. `webSources` are drawn from Google Search grounding metadata and filtered to unique public HTTPS URLs with safe labels; this is URL sanitization, not a claim that every page's factual content has been independently audited. `destination` is either `null` or a matched object such as `{ "id": "library", "name": "USIU Library" }` from the bundled route-enabled destinations. `speechLanguage` is a BCP-47-style language value used for optional voice rendering by the existing frontend.

The service never sends Gemini's raw response object to the browser. It does not return `reply`, `conversationId`, the API key, or provider error details.

### Error response

All application errors use JSON:

```json
{ "error": "Human-readable error message" }
```

Statuses:

| Status | Meaning |
| --- | --- |
| `400` | Invalid JSON or missing/invalid `question`. |
| `405` | Unsupported method; `Allow: POST` is included for `/api/chat`. |
| `413` | Request body exceeds 12,000 bytes. |
| `415` | Request content type is not JSON. |
| `429` | In-memory IP limit exceeded, or Gemini provider quota exhausted. |
| `502` | Gemini request failed or response could not be safely normalized. |
| `503` | Backend `GEMINI_API_KEY` is missing. |
| `404` | Unknown backend path. |

`GET /health` returns `200 { "status": "ok" }` for unauthenticated deployment health checks.

## Authentication and CORS

No chatbot-specific authentication or cookies are required or implemented. The backend does not change the host's existing authentication. The expected deployment is same-origin, so no CORS headers are emitted and no cross-origin browser call is needed. If the service is deployed on a separate origin, place a same-origin reverse proxy/path mapping in front of it. Do not enable wildcard CORS; if direct cross-origin calls are unavoidable, use a reviewed explicit origin allowlist.

## Rate limiting

The service permits up to 30 requests per 60-second window per observed socket IP, in memory per process. This resets when a process restarts and is not shared across replicas. Behind a proxy, the observed IP may be the proxy; configure trusted client IP only through the platform's documented mechanism, never by blindly accepting client-supplied forwarding headers.

## Environment variables

- `GEMINI_API_KEY` — required backend-only secret. Keep it in AppDeploy's managed secret store or another server-side secret manager. It is never returned or logged.
- `PORT` — optional hosting port; defaults to `3000` locally.

`.env.example` includes only `GEMINI_API_KEY=` with an empty value. Do not commit a populated `.env` file.
