import translations from "./fallback-translations.json" with { type: "json" };

export const SUPPORTED_FALLBACK_LANGUAGES = ["en", "sw", "fr", "ar", "so", "es"];
export const FALLBACK_SPEECH_LOCALES = {
  en: "en-US", sw: "sw-KE", fr: "fr-FR", ar: "ar", so: "so-SO", es: "es-ES"
};

const topicTerms = {
  sw: {
    contact: ["udahili", "mawasiliano", "nambari", "barua pepe"], directions: ["wapi", "maelekezo", "ramani", "njia", "kufika"],
    facilities: ["huduma", "maktaba", "ukumbi", "bwawa", "kliniki", "mkahawa", "mazoezi"], programs: ["programu", "kozi", "shahada", "masomo"],
    aid: ["ufadhili", "masomo", "fedha", "malipo", "ada"], international: ["kimataifa", "visa", "wageni"],
    housing: ["malazi", "hosteli", "makazi", "chumba"], career: ["kazi", "ajira", "taaluma", "cv"],
    calendar: ["kalenda", "ratiba", "saa", "muhula", "mitihani"], studentlife: ["wanafunzi", "klabu", "matukio", "shughuli"],
    accreditation: ["idhini", "imeidhinishwa", "utambuzi"], online: ["mtandaoni", "online"], project_technologies: ["html", "javascript", "css", "teknolojia"]
  },
  fr: {
    contact: ["admission", "contact", "téléphone", "courriel", "email"], directions: ["où", "adresse", "itinéraire", "carte", "aller"],
    facilities: ["installations", "bibliothèque", "clinique", "piscine", "cafétéria", "salle de sport"], programs: ["programmes", "cours", "diplôme", "études"],
    aid: ["bourse", "aide financière", "financement", "frais"], international: ["international", "visa", "étranger"],
    housing: ["logement", "résidence", "chambre", "hébergement"], career: ["carrière", "emploi", "stage", "travail"],
    calendar: ["calendrier", "horaire", "heures", "semestre", "examens"], studentlife: ["vie étudiante", "club", "événement", "activité"],
    accreditation: ["accréditation", "accrédité", "reconnu"], online: ["en ligne", "distance"], project_technologies: ["html", "javascript", "css", "technologie"]
  },
  ar: {
    contact: ["القبول", "التواصل", "الهاتف", "البريد الإلكتروني"], directions: ["أين", "العنوان", "الاتجاهات", "الخريطة", "الوصول"],
    facilities: ["المرافق", "مرافق", "المكتبة", "العيادة", "المسبح", "المقصف", "الرياضة"], programs: ["البرامج", "الدورات", "الدرجات", "الدراسة"],
    aid: ["المنح", "المساعدة المالية", "التمويل", "الرسوم"], international: ["الدوليين", "التأشيرة", "الأجانب"],
    housing: ["السكن", "الإقامة", "الغرف"], career: ["المهنة", "الوظائف", "التدريب", "العمل"],
    calendar: ["التقويم", "الجدول", "الساعات", "الفصل", "الامتحانات"], studentlife: ["الحياة الطلابية", "الأندية", "الفعاليات", "الأنشطة"],
    accreditation: ["الاعتماد", "معتمدة"], online: ["عبر الإنترنت", "اونلاين"], project_technologies: ["html", "javascript", "css", "التقنيات"]
  },
  so: {
    contact: ["gelitaanka", "xiriir", "telefoon", "iimayl"], directions: ["xagee", "cinwaan", "jiho", "khariidad", "imaadaa"],
    facilities: ["xarumaha", "maktabad", "rug caafimaad", "barkad", "maqaaxi"], programs: ["barnaamij", "koorso", "shahaado", "waxbarasho"],
    aid: ["deeq", "kaalmo dhaqaale", "maalgelin", "lacag"], international: ["caalami", "fiiso", "ajaanib"],
    housing: ["hoy", "guri", "qol", "degaan"], career: ["shaqo", "xirfad", "tababar", "cv"],
    calendar: ["jadwal", "saacado", "teeram", "imtixaan"], studentlife: ["nolosha ardayda", "naadi", "dhacdo", "hawl"],
    accreditation: ["aqoonsi", "aqoonsatay"], online: ["internetka", "online"], project_technologies: ["html", "javascript", "css", "teknoolajiyad"]
  },
  es: {
    contact: ["admisión", "contacto", "teléfono", "correo"], directions: ["dónde", "dirección", "indicaciones", "mapa", "llegar"],
    facilities: ["instalaciones", "biblioteca", "clínica", "piscina", "cafetería", "gimnasio"], programs: ["programas", "cursos", "título", "estudios"],
    aid: ["beca", "ayuda financiera", "financiación", "matrícula"], international: ["internacional", "visa", "visado"],
    housing: ["alojamiento", "residencia", "habitación", "vivienda"], career: ["carrera", "empleo", "prácticas", "trabajo"],
    calendar: ["calendario", "horario", "horas", "semestre", "exámenes"], studentlife: ["vida estudiantil", "club", "evento", "actividad"],
    accreditation: ["acreditación", "acreditada", "reconocida"], online: ["en línea", "online", "distancia"], project_technologies: ["html", "javascript", "css", "tecnología"]
  }
};

const languageWords = {
  sw: ["habari", "tafadhali", "nini", "wapi", "naomba", "je", "chuo", "wanafunzi", "nipe"],
  fr: ["bonjour", "où", "comment", "qu'est-ce", "quel", "quelle", "s'il", "université", "étudiants"],
  so: ["maxaa", "sidee", "xagee", "fadlan", "jaamacadda", "ardayda", "ma", "waa"],
  es: ["hola", "dónde", "cómo", "qué", "cuál", "universidad", "estudiantes", "por favor"]
};

export function detectFallbackLanguage(question) {
  const text = String(question || "").toLowerCase();
  if (/[\u0600-\u06ff]/u.test(text)) return "ar";
  const normalized = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  let best = { code: "en", score: 0 };
  for (const [code, words] of Object.entries(languageWords)) {
    const score = words.reduce((count, word) => count + (normalized.includes(word.normalize("NFD").replace(/[\u0300-\u036f]/g, "")) ? 1 : 0), 0);
    if (score > best.score) best = { code, score };
  }
  return best.score > 0 ? best.code : "en";
}

export function resolveFallbackLanguage(question, selectedLanguage = "auto") {
  if (selectedLanguage && selectedLanguage !== "auto" && SUPPORTED_FALLBACK_LANGUAGES.includes(selectedLanguage)) return selectedLanguage;
  return detectFallbackLanguage(question);
}

export function answerMatchesRequestedLanguage(answerLanguage, requestedLanguage) {
  if (!requestedLanguage || requestedLanguage === "auto") return true;
  if (typeof answerLanguage !== "string") return false;
  return answerLanguage.toLowerCase().split("-")[0] === requestedLanguage.toLowerCase();
}

export function localTopicTerms(topicId, language) {
  return topicTerms[language]?.[topicId] || [];
}

export function localizeFallback(answer, language, topicId = null) {
  if (language === "en") return answer;
  const catalog = translations[language];
  if (!catalog) return answer;
  if (topicId && catalog.topics[topicId]) {
    const translated = catalog.topics[topicId];
    return { ...answer, text: answer.type === "followUp" ? translated.followUp : translated.answer };
  }
  return { ...answer, text: catalog.genericFallback, type: "fallback" };
}

export function fallbackUnknownQuestion(language) {
  return translations[language]?.unknownQuestion || "What would you like to know about USIU-Africa? You can ask about campus facilities, admissions, events, student resources or getting here.";
}

const quotaNotices = {
  en: "Live Gemini answers and Google Search have reached the current API quota. This answer uses the saved local guide, so current details may be missing.",
  sw: "Majibu ya Gemini ya moja kwa moja na Google Search yamefikia kikomo cha sasa cha matumizi ya API. Jibu hili linatumia mwongozo uliohifadhiwa, kwa hiyo huenda taarifa za sasa zikakosekana.",
  fr: "Les réponses Gemini en direct et Google Search ont atteint le quota API actuel. Cette réponse utilise le guide local enregistré ; des informations récentes peuvent manquer.",
  ar: "وصلت إجابات Gemini المباشرة وGoogle Search إلى حصة API الحالية. تستخدم هذه الإجابة الدليل المحلي المحفوظ، لذلك قد تغيب بعض المعلومات الحديثة.",
  so: "Jawaabaha Gemini ee tooska ah iyo Google Search waxay gaareen xadka isticmaalka API-ga hadda. Jawaabtani waxay adeegsanaysaa hagaha maxalliga ah ee kaydsan, sidaas darteed xog cusub way maqnaan kartaa.",
  es: "Las respuestas en directo de Gemini y Google Search alcanzaron la cuota actual de la API. Esta respuesta usa la guía local guardada, por lo que podrían faltar datos recientes."
};

export function fallbackUnavailableNotice(language, reason = "unavailable") {
  if (reason === "quota") return quotaNotices[language] || quotaNotices.en;
  return translations[language]?.unavailableNotice || "Gemini is temporarily unavailable. This local guide answer is in English and is based on saved campus information.";
}
