async function loadCorpus() {
  if (typeof process !== "undefined" && process.versions?.node) {
    const { readFile } = await import("node:fs/promises");
    return JSON.parse(await readFile(new URL("./public/data/usiu-public-knowledge.json", import.meta.url), "utf8"));
  }
  const response = await fetch(new URL("./data/usiu-public-knowledge.json", import.meta.url), { cache: "no-cache" });
  if (!response.ok) throw new Error("Public USIU knowledge data could not be loaded");
  return response.json();
}

const corpus = await loadCorpus().catch(error => {
  console.warn("USIU public knowledge index could not be loaded; continuing with existing local answers.", error);
  return { reviewed_at: null, categories: [], sources: [], cards: [] };
});

export const PUBLIC_KNOWLEDGE_REVIEWED_AT = corpus.reviewed_at;
export const PUBLIC_KNOWLEDGE_CATEGORIES = corpus.categories;
export const PUBLIC_KNOWLEDGE_CARDS = corpus.cards;

export const PUBLIC_SOURCES = Object.freeze(Object.fromEntries(
  corpus.sources.map(source => [source.id, { label: source.label, url: source.url }])
));

const englishCategoryTerms = {
  academics: ["academic", "degree", "course", "program", "catalog", "calendar", "semester", "curriculum", "school"],
  admissions: ["admission", "application", "apply", "applicant", "intake", "entry requirements"],
  "cost-aid": ["tuition", "fee", "scholarship", "financial aid", "payment", "refund", "installment", "mpesa", "m-pesa"],
  "library-research": ["library", "book", "borrow", "journal", "database", "opac", "thesis", "research", "librarian", "ebook", "e-book"],
  "student-services": ["housing", "hostel", "clinic", "counseling", "counselling", "sports", "gym", "student life", "health", "disability", "accommodation"],
  global: ["international", "exchange", "study abroad", "culture", "diversity", "visa", "nationality"],
  "careers-alumni": ["career", "job", "internship", "alumni", "employer", "resume", "résumé", "cv", "placement"],
  "about-contact": ["contact", "phone", "telephone", "address", "about", "history", "location", "accreditation", "campus", "mission"],
  "policies-registrar": ["registrar", "transcript", "student handbook", "record", "academic policy", "drop add", "graduation form"],
  "news-events": ["news", "event", "commencement", "graduation", "announcement"]
};

const localizedCategoryTerms = {
  sw: {
    academics: ["masomo", "kozi", "shahada", "kalenda", "ratiba"], admissions: ["udahili", "kuomba", "maombi"],
    "cost-aid": ["ada", "ufadhili", "malipo", "masomo ya ufadhili", "ufadhili wa masomo"], "library-research": ["maktaba", "vitabu", "mtafiti", "saa za maktaba", "saa ngapi"],
    "student-services": ["wanafunzi", "malazi", "afya", "michezo", "ushauri"], global: ["kimataifa", "kubadilishana", "utamaduni"],
    "careers-alumni": ["kazi", "ajira", "taaluma", "wahitimu"], "about-contact": ["mawasiliano", "anwani", "historia", "chuo kikuu"],
    "policies-registrar": ["msajili", "nakala", "rekodi"], "news-events": ["habari", "matukio", "mahafali"]
  },
  fr: {
    academics: ["études", "cours", "diplôme", "calendrier", "programme"], admissions: ["admission", "candidature", "postuler"],
    "cost-aid": ["frais", "bourse", "aide financière", "paiement"], "library-research": ["bibliothèque", "livre", "recherche", "bibliothécaire"],
    "student-services": ["vie étudiante", "logement", "santé", "sport", "conseil"], global: ["international", "échange", "culture", "diversité"],
    "careers-alumni": ["carrière", "emploi", "stage", "anciens élèves"], "about-contact": ["contact", "adresse", "histoire", "université"],
    "policies-registrar": ["registre", "relevé", "dossier"], "news-events": ["actualités", "événement", "cérémonie", "diplôme"]
  },
  ar: {
    academics: ["الدراسة", "البرامج", "الدورات", "الدرجات", "التقويم"], admissions: ["القبول", "التقديم", "التسجيل"],
    "cost-aid": ["الرسوم", "رسوم", "رسوم الدراسة", "المنح", "المنح الدراسية", "المساعدة المالية", "الدفع"], "library-research": ["المكتبة", "الكتب", "البحث", "أمين المكتبة"],
    "student-services": ["حياة الطلاب", "السكن", "الصحة", "الرياضة", "الإرشاد"], global: ["الدولي", "التبادل", "الثقافة", "التنوع"],
    "careers-alumni": ["المهنة", "الوظيفة", "التدريب", "الخريجون"], "about-contact": ["التواصل", "العنوان", "التاريخ", "الجامعة"],
    "policies-registrar": ["المسجل", "السجل", "كشف الدرجات"], "news-events": ["الأخبار", "الفعاليات", "التخرج"]
  },
  so: {
    academics: ["waxbarasho", "koorso", "shahaado", "jadwal"], admissions: ["gelitaanka", "codsi", "dalab"],
    "cost-aid": ["lacag", "deeq", "deeq waxbarasho", "kaalmo dhaqaale", "bixin"], "library-research": ["maktabad", "buug", "cilmi baaris"],
    "student-services": ["arday", "hoy", "caafimaad", "ciyaaro", "la-talin"], global: ["caalami", "isweydaarsi", "dhaqan"],
    "careers-alumni": ["shaqo", "xirfad", "tababar", "qalin-jabiyey"], "about-contact": ["xiriir", "cinwaan", "taariikh", "jaamacad"],
    "policies-registrar": ["diiwaanhaye", "diiwaan", "warqad dhibco"], "news-events": ["war", "dhacdo", "qalin-jabin"]
  },
  es: {
    academics: ["estudios", "curso", "grado", "calendario", "programa"], admissions: ["admisión", "solicitud", "postular"],
    "cost-aid": ["matrícula", "beca", "ayuda financiera", "pago"], "library-research": ["biblioteca", "libro", "investigación", "bibliotecario"],
    "student-services": ["vida estudiantil", "alojamiento", "salud", "deportes", "orientación"], global: ["internacional", "intercambio", "cultura", "diversidad"],
    "careers-alumni": ["carrera", "empleo", "prácticas", "egresados"], "about-contact": ["contacto", "dirección", "historia", "universidad"],
    "policies-registrar": ["registro", "transcripción", "expediente"], "news-events": ["noticias", "evento", "graduación"]
  }
};

const stopWords = new Set(("a an and are as at be can do does for from how i in is it of on or the to what when where which who with you your usiu africa university about tell please me my this that there have has any all much many much" ).split(/\s+/));

function normalize(value) {
  return String(value || "")
    .toLocaleLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .replace(/[’']/g, "'")
    .replace(/[^\p{L}\p{N}\s'-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function terms(value) {
  return normalize(value).split(/\s+/u).filter(word => word.length > 1 && !stopWords.has(word));
}

function phraseInQuestion(question, phrase) {
  const candidate = normalize(phrase);
  if (!candidate) return false;
  return (` ${question} `).includes(` ${candidate} `) || question.includes(candidate);
}

function localizedCategoryBoost(question, requestedLanguage) {
  const boosts = new Map();
  const commonEnglishTerms = new Set(Object.values(englishCategoryTerms).flat().map(normalize));
  for (const [language, rows] of Object.entries(localizedCategoryTerms)) {
    for (const [category, phrases] of Object.entries(rows)) {
      for (const phrase of phrases) {
        if (commonEnglishTerms.has(normalize(phrase))) continue;
        if (phraseInQuestion(question, phrase)) {
          const selectedLanguageBonus = requestedLanguage === language ? 2 : 0;
          boosts.set(category, Math.max(boosts.get(category) || 0, 8 + Math.min(4, terms(phrase).length) + selectedLanguageBonus));
        }
      }
    }
  }
  return boosts;
}

function scoreCard(question, queryTerms, card, localeBoosts) {
  let score = 0;
  let bestPattern = 0;
  for (const pattern of card.question_patterns || []) {
    const normalizedPattern = normalize(pattern);
    if (normalizedPattern && question.includes(normalizedPattern)) bestPattern = Math.max(bestPattern, 14);
    const patternTerms = new Set(terms(pattern));
    const matched = [...patternTerms].filter(word => queryTerms.has(word)).length;
    if (matched) {
      const coverage = matched / Math.max(1, Math.min(patternTerms.size, 7));
      bestPattern = Math.max(bestPattern, matched * 2.1 + coverage * 2.5);
    }
  }
  score += bestPattern;

  const answerTerms = new Set(terms(card.answer));
  const answerOverlap = [...queryTerms].filter(word => answerTerms.has(word)).length;
  score += Math.min(2.5, answerOverlap * 0.35);

  for (const phrase of englishCategoryTerms[card.category_id] || []) {
    if (phraseInQuestion(question, phrase)) {
      score += 2;
      break;
    }
  }
  score += localeBoosts.get(card.category_id) || 0;
  return { score, patternScore: bestPattern };
}

export function searchPublicKnowledge(rawQuestion, limit = 5, requestedLanguage = "auto") {
  const question = normalize(rawQuestion);
  if (!question) return [];
  const queryTerms = new Set(terms(question));
  const localeBoosts = localizedCategoryBoost(question, requestedLanguage);
  return PUBLIC_KNOWLEDGE_CARDS
    .map(card => ({ ...card, ...scoreCard(question, queryTerms, card, localeBoosts) }))
    .filter(card => card.score >= 3.5 && card.source_ids.every(id => Object.hasOwn(PUBLIC_SOURCES, id)))
    .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id))
    .slice(0, Math.max(0, Math.min(8, limit)));
}

export function findStrongPublicMatch(rawQuestion) {
  if (new Set(terms(rawQuestion)).size < 2) return null;
  const best = searchPublicKnowledge(rawQuestion, 1, "en")[0];
  return best && best.patternScore >= 3.2 ? best : null;
}

export function getPublicSourceRecords(sourceIds) {
  return Object.fromEntries(
    [...new Set(sourceIds || [])]
      .filter(id => Object.hasOwn(PUBLIC_SOURCES, id))
      .map(id => [id, PUBLIC_SOURCES[id]])
  );
}
