# USIU Smart Campus chatbot backend

Backend-only package for the already-integrated React chatbot described in the handoff brief. It exposes `POST /api/chat` and `GET /health`; it does not include or replace a frontend.

## Scope and host-project safety

This package was prepared for the stated AppDeploy project ID `touchline-i4z6y5`, but it has **not** been connected to or deployed into that project. The AppDeploy source tree and backend framework were not provided for inspection, so this package does not guess a host file path or assume Express, a database, authentication, or a particular router. It leaves the existing frontend, login/authentication, database, demo accounts, routes, and realtime features untouched.

The safest default is to run this as a separate Node 22 service and map the host app's same-origin `/api/chat` path to it. If the actual host already has a compatible Node HTTP backend, its owner can inspect the repository and mount/adapt this route without replacing the existing server. Do not overwrite an existing entry file, `package.json`, lockfile, auth route, or database configuration.

The package includes no frontend files, real API keys, passwords, access tokens, or `.env` file. The only mock Gemini responses are in the automated tests; the running service never returns mock answers. The current chatbot data and event records are a dated snapshot; Google Search grounding can help with changing details, but it is not a guarantee that every fact is current.

## Requirements and dependencies

- Node.js 22 or later.
- Runtime dependency: `@google/genai` 3.0.0.
- Backend uses Node built-ins for HTTP, files, paths, and URL handling.
- Tests use Node's built-in `node:test` and `fetch`; no React or chatbot UI dependency is included.
- Google Gemini model: `gemini-3.6-flash`, with Google Search grounding enabled.

## Install and run

1. Extract the ZIP into a new backend-service directory. Do not extract over the host frontend or an existing backend.
2. Install the pinned dependencies with `npm ci`.
3. Configure `GEMINI_API_KEY` as a **server-side managed secret** in the actual hosting environment. The key must never be placed in React/browser code or committed to the repository. `.env.example` contains only the empty placeholder `GEMINI_API_KEY=`.
4. Start with `npm start`. The process listens on `0.0.0.0` and uses the platform-provided `PORT`, defaulting to `3000` for local development.
5. Run the automated suite with `npm test`. These tests inject a mocked Gemini client and do not call Google or require a real key.

The service does not load `.env` files itself. For local use, export `GEMINI_API_KEY` in the server process environment or use a local secret manager; do not commit a populated `.env` file.

## Integration in the existing React page

The React chatbot can keep using the same-origin relative URL. The host must route `/api/chat` to this service (or mount an equivalent handler in its existing backend). Example caller:

```js
async function askCampusChatbot(question, history = [], language = "auto") {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, history, language })
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Chat request failed.");
  return payload;
}
```

Expected successful response fields are `answer`, `sourceIds`, `webSources`, `destination`, and `speechLanguage`. This API is stateless: the frontend keeps the visible conversation and submits recent turns in `history` each time. It does not accept `message`/`conversationId` as substitutes.

## API and deployment docs

- [API contract](API-CONTRACT.md)
- [Deployment note for AppDeploy](DEPLOYMENT.md)

## Files included in this package

- `server.js` — standalone backend entry and `/api/chat` route.
- `data.js`, `events.js`, `event-answers.js` — curated answers and event snapshot.
- `fallback-i18n.js`, `fallback-translations.json` — local language metadata used by the existing knowledge layer.
- `public-knowledge.js`, `web-search.js` — public resource search and Google grounding source sanitization.
- `public/data/usiu-public-knowledge.json` — curated public USIU knowledge cards and source catalog.
- `public/data/campus-map.json` — route-enabled destination metadata used by answer normalization.
- `package.json`, `package-lock.json` — pinned service dependencies and scripts.
- `.env.example`, `.gitignore` — empty secret placeholder and secret/dependency exclusions.
- `API-CONTRACT.md`, `DEPLOYMENT.md` — integration documentation.
- `tests/chat-api.test.js` — mock-based API/security regression tests.

## Files not to overwrite in the host project

Do not replace the host's React components/pages, app shell, package manifests or lockfile, authentication/login routes, database schema/configuration, demo accounts, realtime endpoints, deployment config, or existing server entry file. The archive is a separate service bundle. If its dependency is merged into an existing backend instead, merge the package dependency and add a non-breaking route only after inspecting the real host repository.

## Troubleshooting

- **503 `The chat service is not configured.`** Set the managed backend secret named `GEMINI_API_KEY`; never expose it in the frontend.
- **404 at `/api/chat`.** The service is not running at the configured target, or the AppDeploy route/reverse proxy has not mapped the same-origin path.
- **405.** The chat API accepts only `POST`; the response includes `Allow: POST`.
- **415.** Send `Content-Type: application/json`.
- **400 or 413.** Check the required `question`, 1–500 character limit, valid JSON, and 12,000-byte body limit.
- **429.** The per-process IP limit or Gemini/Google Search quota was reached. Wait and retry; review provider quota/billing separately.
- **502.** Gemini failed or returned an invalid response. Check server-side service logs for the sanitized error category and verify provider/model access; no provider message or key is returned to the browser.
- **Only one client seems to share the limit.** Behind a proxy, the Node socket may see the proxy address for every visitor. Use the platform's documented trusted client-IP mechanism only after confirming it; do not trust arbitrary `X-Forwarded-For` values.
- **Browser CORS error.** This package intentionally sends no permissive CORS headers. Prefer same-origin `/api/chat` reverse proxying rather than direct cross-origin browser access. If cross-origin hosting is unavoidable, configure an explicit origin allowlist at a reviewed gateway.
- **Wrong campus facts or dates.** Check the included public data/event snapshot and its review dates. A new article or a Search result does not automatically update these saved files.
