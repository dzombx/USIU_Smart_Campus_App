import { findEventAnswer } from "./event-answers.js";
import { localTopicTerms, localizeFallback, resolveFallbackLanguage, fallbackUnknownQuestion } from "./fallback-i18n.js";
import { PUBLIC_SOURCES, findStrongPublicMatch } from "./public-knowledge.js";

export { PUBLIC_SOURCES };

export const SOURCES = {
  faq: { label: "USIU-Africa FAQ", url: "https://www.usiu.ac.ke/about-us/faq/" },
  contact: { label: "Official contacts", url: "https://www.usiu.ac.ke/about-us/contact-us/" },
  calendar: { label: "Academic calendars", url: "https://www.usiu.ac.ke/document_category/academic-calendar/" },
  eventCalendar: { label: "USIU-Africa upcoming events", url: "https://www.usiu.ac.ke/upcoming-events/" },
  resources: { label: "Student resources", url: "https://www.usiu.ac.ke/resource-downloads/" },
  studentLife: { label: "Student life", url: "https://www.usiu.ac.ke/student-life/" },
  virtualTour: { label: "Virtual campus tour", url: "https://www.usiu.ac.ke/about-us/virtual-tour/" },
  campusMap: { label: "OpenStreetMap campus view", url: "https://www.openstreetmap.org/?mlat=-1.2127&mlon=36.8803#map=17/-1.2127/36.8803" },
  mapLicense: { label: "OpenStreetMap copyright and ODbL", url: "https://www.openstreetmap.org/copyright" },
  gateInformation: { label: "USIU-Africa campus access information", url: "https://www.usiu.ac.ke/2026-48th-commencement/" }
};

export const TOPICS = [
  {
    id: "project_technologies",
    keywords: ["html", "javascript", "java script", "css", "programming language", "coding language", "web languages", "technology used", "technologies used", "what technology", "what technologies", "what language", "what languages", "what did you use to build", "used to build", "built with", "simple language"],
    answer: "Yes. This chatbot uses all three: HTML gives the page its structure, CSS controls how it looks, and JavaScript makes it interactive—for example, sending your questions and showing map directions. In short: HTML is the structure, CSS is the look, and JavaScript makes things happen.",
    followUp: "This chatbot uses HTML for the page structure, CSS for its appearance, and JavaScript for interactive features such as chat and directions.",
    sources: []
  },
  {
    id: "contact",
    keywords: ["admission", "admissions", "apply", "application", "contact", "phone", "call", "email", "office number", "main line", "whatsapp"],
    answer: "For admissions, contact the Admissions Office at +254 730 116 247, 300, 397, 503 or 522, or email admit@usiu.ac.ke. The university's main lines are +254 730 116 000, 290 or 291. WhatsApp: +254 755 844 849.",
    followUp: "Would you like another admissions contact, or are you looking for application requirements? For the latest requirements, use the official admissions contact below.",
    sources: ["contact"]
  },
  {
    id: "directions",
    keywords: ["where", "address", "location", "directions", "get to", "find campus", "thika road", "campus located", "map", "navigate", "route"],
    answer: "USIU-Africa is on USIU Road, off Thika Road at Exit 7, Nairobi, Kenya. Its mailing address is P. O. Box 14634 – 00800, Nairobi. For approximate mapped outdoor campus routes, open 3D directions. Room-level, stair and some building routes are not mapped.",
    followUp: "Tell me a mapped campus destination, or open 3D directions to choose a start and destination. The route is approximate and only uses connected mapped outdoor paths.",
    sources: ["contact", "campusMap", "mapLicense", "gateInformation"]
  },
  {
    id: "facilities",
    keywords: ["facility", "facilities", "library", "gym", "fitness", "pool", "swimming", "clinic", "medical", "cafeteria", "wifi", "wi-fi", "lecture hall", "lab", "labs", "residence hall", "hostel", "sports"],
    answer: "Campus facilities include lecture halls, a fully equipped library, sports and fitness facilities with a swimming pool and gym, a medical clinic, residence halls, a cafeteria, media labs and campus-wide wireless internet.",
    followUp: "Which facility are you asking about? I can share the facilities the university lists, but I don't have live opening hours or room-by-room directions.",
    sources: ["faq"]
  },
  {
    id: "programs",
    keywords: ["program", "programs", "course", "courses", "degree", "degrees", "undergraduate", "bachelor", "master", "masters", "doctoral", "phd", "study", "major", "pharmacy", "psychology"],
    answer: "USIU-Africa offers undergraduate, master's and doctoral programs in areas including business, science and technology, international relations, communication, pharmacy, psychology and health sciences. It also offers short courses and executive education. Check the university site for the current program list.",
    followUp: "Which level or subject area are you interested in? Program availability can change, so check the official program pages for the current list.",
    sources: ["faq"]
  },
  {
    id: "aid",
    keywords: ["financial aid", "scholarship", "scholarships", "funding", "tuition", "payment plan", "work study", "mastercard foundation", "bursary", "financial support"],
    answer: "Funding options include internal scholarships, financial aid, work-study opportunities, flexible payment plans for eligible students and external partnerships such as the Mastercard Foundation Scholars Program. Eligibility and availability vary, so confirm current details with the university.",
    followUp: "Are you looking for a scholarship or another funding option? For current eligibility and deadlines, contact the university directly.",
    sources: ["faq", "contact"]
  },
  {
    id: "international",
    keywords: ["international student", "international students", "visa", "foreign student", "study in kenya", "orientation", "international office", "global student"],
    answer: "USIU-Africa welcomes international students and provides support with visa processing, orientation, housing and integration through the Office of International Students and Programs. For current processes, contact the university.",
    followUp: "Are you asking about visa support, housing or orientation? The official university contact page can direct you to the right office.",
    sources: ["faq", "contact"]
  },
  {
    id: "housing",
    keywords: ["housing", "accommodation", "hostel", "hostels", "residence", "residence hall", "dorm", "where to stay", "room"],
    answer: "On-campus hostels are available, particularly for first-year and international students. Rooms are typically shared, with basic furnishings and access to common facilities. Please confirm current availability directly with the university.",
    followUp: "Are you asking about availability or accommodation arrangements? I don't have current room availability or pricing.",
    sources: ["faq", "contact"]
  },
  {
    id: "career",
    keywords: ["career", "careers", "internship", "internships", "job", "jobs", "cv", "resume", "employer", "career services", "job fair"],
    answer: "Career Services supports internship placements, CV writing, job-search strategies and connections with employers through job fairs and industry partnerships.",
    followUp: "Would you like to know what career support is offered, or how to reach the relevant office? I don't have the office's current hours.",
    sources: ["faq", "contact"]
  },
  {
    id: "calendar",
    keywords: ["calendar", "academic calendar", "semester", "term dates", "class dates", "exam dates", "registration dates", "when does semester", "schedule", "timetable", "class schedule", "office hours", "opening hours", "open today", "hours"],
    answer: "Check the latest USIU-Africa academic calendar for current term dates. I don't have live schedules or office hours, so contact the university for today's opening times.",
    followUp: "Are you looking for term dates, a class timetable or an office's opening hours? I don't have live schedule data, but the official calendar and contact pages are linked below.",
    sources: ["calendar", "resources", "contact"]
  },
  {
    id: "studentlife",
    keywords: ["student life", "clubs", "club", "activities", "student activities", "campus life", "sports team", "community"],
    answer: "USIU-Africa has campus clubs and student activities. For current announcements, check the Student Life page or ask about recent past and upcoming events.",
    followUp: "Are you looking for clubs, activities or a particular event? I have a dated sample of official past and upcoming event listings, and the university page may have newer announcements.",
    sources: ["studentLife", "eventCalendar"]
  },
  {
    id: "accreditation",
    keywords: ["accreditation", "accredited", "recognition", "recognized", "recognised", "cue", "wasc", "accredit", "internationally recognized"],
    answer: "USIU-Africa is accredited by Kenya's Commission for University Education (CUE) and the WASC Senior College and University Commission (WSCUC) in the United States.",
    followUp: "Would you like information about programs or university contacts? The official FAQ has more background.",
    sources: ["faq"]
  },
  {
    id: "online",
    keywords: ["online program", "online programs", "online degree", "online degrees", "distance learning", "virtual program"],
    answer: "USIU-Africa offers fully online degree programs, including selected bachelor's and master's degrees. Confirm the current online program list on the university site.",
    followUp: "Are you asking about online degrees or admissions? The program list and availability should be confirmed on the official site.",
    sources: ["faq"]
  }
];

const FOLLOW_UP_MARKERS = ["more", "tell me more", "what about", "and", "how about"];

function asksForCurrentTiming(question) {
  return /\b(?:hours?|opening time|opening hours|timetable|schedule|term dates|exam dates|registration dates|open today)\b/.test(question)
    || /\bwhen\b.*\b(?:open|start|close|begin|end)\b/.test(question);
}

export function findAnswer(rawQuestion, lastTopicId = null, requestedLanguage = "auto") {
  const language = resolveFallbackLanguage(rawQuestion, requestedLanguage);
  const question = rawQuestion.toLowerCase().replace(/[’']/g, "'").replace(/[^\p{L}\p{N}\s'-]/gu, " ").replace(/\s+/g, " ").trim();
  if (!question) return { type: "fallback", topicId: null, text: fallbackUnknownQuestion(language) };

  const eventAnswer = findEventAnswer(question, lastTopicId, language);
  if (eventAnswer) return eventAnswer;

  if (language === "en") {
    const publicMatch = findStrongPublicMatch(rawQuestion);
    if (publicMatch) {
      return {
        type: "publicAnswer",
        topicId: null,
        text: `${publicMatch.answer}\n\n${publicMatch.context}`,
        sources: publicMatch.source_ids.map(id => PUBLIC_SOURCES[id]).filter(Boolean)
      };
    }
  }

  if (asksForCurrentTiming(question)) {
    const timing = TOPICS.find(topic => topic.id === "calendar");
    return localizeFallback({ type: "answer", topicId: timing.id, text: timing.answer, sources: timing.sources.map(key => SOURCES[key]) }, language, timing.id);
  }

  const scored = TOPICS.map(topic => {
    let score = 0;
    for (const keyword of topic.keywords) {
      if (question.includes(keyword)) score += keyword.includes(" ") ? 3 : 1;
    }
    for (const keyword of localTopicTerms(topic.id, language)) {
      if (question.includes(keyword)) score += keyword.includes(" ") ? 3 : 1;
    }
    return { topic, score };
  }).sort((a, b) => b.score - a.score);

  if (scored[0]?.score >= 1) {
    const { topic } = scored[0];
    return localizeFallback({ type: "answer", topicId: topic.id, text: topic.answer, sources: topic.sources.map(key => SOURCES[key]) }, language, topic.id);
  }

  if (lastTopicId && FOLLOW_UP_MARKERS.some(marker => question.includes(marker))) {
    const previous = TOPICS.find(topic => topic.id === lastTopicId);
    if (previous) return localizeFallback({ type: "followUp", topicId: previous.id, text: previous.followUp, sources: previous.sources.map(key => SOURCES[key]) }, language, previous.id);
  }

  return localizeFallback({
    type: "fallback",
    text: "I’m not confident I have a reliable answer for that yet. Could you add a little detail, or choose one of these topics: facilities, admissions, events, student support or directions? For current information, try the official FAQ, contacts, event listings or student resources.",
    sources: [SOURCES.faq, SOURCES.contact, SOURCES.resources, SOURCES.eventCalendar]
  }, language);
}

export const SUGGESTED_QUESTIONS = [
  "What facilities are available on campus?",
  "How do I contact admissions?",
  "What financial aid options are available?",
  "Where can I find the academic calendar?",
  "What past and upcoming events have there been at USIU-Africa?"
];
