# Package boundary

This archive contains only the Node.js chatbot backend, its imported USIU data/helpers, and backend documentation/tests. It does not contain the React frontend, a host AppDeploy source tree, or credentials. It is intended to be added as a separate service or carefully mounted after inspecting the host repository. No existing host file should be overwritten.