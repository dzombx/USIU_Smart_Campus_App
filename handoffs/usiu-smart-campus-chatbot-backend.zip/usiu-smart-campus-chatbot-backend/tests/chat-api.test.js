import test from "node:test";
import assert from "node:assert/strict";
import { createUSIUChatServer } from "../server.js";

const MOCK_SECRET = "unit-test-placeholder-not-a-real-api-key";

function modelResponse(overrides = {}) {
  const result = {
    answer: "USIU-Africa has a library, clinic and cafeteria.",
    sourceIds: ["faq", "not-in-catalog"],
    destinationId: null,
    answerLanguage: "en",
    ...overrides
  };
  return {
    text: JSON.stringify(result),
    candidates: [{
      groundingMetadata: {
        groundingChunks: [
          { web: { uri: "https://www.usiu.ac.ke/about-us/faq/", title: "Official FAQ" } },
          { web: { uri: "https://example.org/source", title: "Grounded source" } },
          { web: { uri: "http://insecure.example/source", title: "Insecure" } },
          { web: { uri: "https://user:password@example.net/source", title: "Credential URL" } }
        ]
      }
    }]
  };
}

function mockAI({ response = modelResponse(), error, onGenerate } = {}) {
  return {
    models: {
      async generateContent(request) {
        onGenerate?.(request);
        if (error) throw error;
        return response;
      }
    }
  };
}

async function withServer(options, run) {
  const server = createUSIUChatServer({
    env: { GEMINI_API_KEY: MOCK_SECRET },
    createAI: () => mockAI(),
    logger: { error() {} },
    retryDelayMs: 0,
    retryJitterMs: 0,
    ...options
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  const address = server.address();
  try {
    await run(`http://127.0.0.1:${address.port}`);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
}

function post(base, body, extraHeaders = {}) {
  return fetch(`${base}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...extraHeaders },
    body: typeof body === "string" ? body : JSON.stringify(body)
  });
}

async function readJson(response) {
  return response.json();
}

test("valid request returns the exact normalized API contract with sanitized citations", async () => {
  let generatedRequest;
  let receivedKey;
  await withServer({
    createAI: key => {
      receivedKey = key;
      return mockAI({ onGenerate: request => { generatedRequest = request; } });
    }
  }, async base => {
    const response = await post(base, {
      question: "What facilities are available?",
      history: [{ role: "user", text: "I am visiting campus." }],
      language: "en",
      conversationId: "must-not-be-returned"
    });
    const body = await readJson(response);

    assert.equal(response.status, 200);
    assert.deepEqual(Object.keys(body).sort(), ["answer", "destination", "sourceIds", "speechLanguage", "webSources"].sort());
    assert.equal(body.answer, "USIU-Africa has a library, clinic and cafeteria.");
    assert.deepEqual(body.sourceIds, ["faq"]);
    assert.deepEqual(body.webSources, [
      { label: "Official FAQ", url: "https://www.usiu.ac.ke/about-us/faq/" },
      { label: "Grounded source", url: "https://example.org/source" }
    ]);
    assert.equal(body.destination, null);
    assert.equal(body.speechLanguage, "en-US");
    assert.equal(receivedKey, MOCK_SECRET);
    assert.equal(generatedRequest.model, "gemini-3.6-flash");
    assert.equal(generatedRequest.config.responseMimeType, "application/json");
    assert.deepEqual(generatedRequest.config.tools, [{ googleSearch: {} }]);
    assert.match(generatedRequest.contents, /TRUSTED CAMPUS DATA/);
    assert.doesNotMatch(JSON.stringify(body), /conversationId|must-not-be-returned/);
  });
});

test("missing question and a question over 500 characters return 400", async () => {
  await withServer({}, async base => {
    const missing = await post(base, { history: [] });
    assert.equal(missing.status, 400);
    assert.equal(typeof (await readJson(missing)).error, "string");

    const oversized = await post(base, { question: "x".repeat(501) });
    assert.equal(oversized.status, 400);
  });
});

test("request body over 12,000 bytes returns 413", async () => {
  await withServer({}, async base => {
    const response = await post(base, {
      question: "Hello",
      history: [{ role: "user", text: "x".repeat(13_000) }]
    });
    assert.equal(response.status, 413);
    assert.match((await readJson(response)).error, /too large/i);
  });
});

test("invalid JSON and non-JSON content types return 400 and 415", async () => {
  await withServer({}, async base => {
    const invalid = await post(base, "{", { "Content-Type": "application/json" });
    assert.equal(invalid.status, 400);
    assert.equal(typeof (await readJson(invalid)).error, "string");

    const wrongType = await post(base, JSON.stringify({ question: "Hi" }), { "Content-Type": "text/plain" });
    assert.equal(wrongType.status, 415);
  });
});

test("invalid history entries are dropped, history is capped to eight, and text to 1,200 characters", async () => {
  let generatedRequest;
  await withServer({
    createAI: () => mockAI({ onGenerate: request => { generatedRequest = request; } })
  }, async base => {
    const history = [
      { role: "user", text: "too-old" },
      ...Array.from({ length: 8 }, (_, i) => ({ role: i % 2 ? "assistant" : "user", text: `keep-${i}` })),
      { role: "system", text: "untrusted role must be dropped" },
      { role: "assistant", text: `  ${"x".repeat(1_300)}  ` }
    ];
    const response = await post(base, { question: "Tell me about campus", history, language: "en" });
    assert.equal(response.status, 200);

    const historyMatch = generatedRequest.contents.match(/CHAT HISTORY: ([\s\S]*?)\n\nCURRENT QUESTION:/);
    assert.ok(historyMatch);
    const normalized = JSON.parse(historyMatch[1]);
    assert.equal(normalized.length, 7);
    assert.ok(normalized.every(turn => ["user", "assistant"].includes(turn.role)));
    assert.ok(normalized.every(turn => turn.text.length <= 1_200));
    assert.equal(normalized.at(-1).text.length, 1_200);
    assert.equal(normalized.at(-1).text[0], "x");
    assert.ok(!JSON.stringify(normalized).includes("too-old"));
    assert.ok(!JSON.stringify(normalized).includes("untrusted role"));
  });
});

test("unknown language becomes auto and the detected model language is returned", async () => {
  let generatedRequest;
  await withServer({
    createAI: () => mockAI({
      response: modelResponse({ answer: "Habari za chuo.", answerLanguage: "sw-KE" }),
      onGenerate: request => { generatedRequest = request; }
    })
  }, async base => {
    const response = await post(base, { question: "Habari za chuo", language: "xx" });
    const body = await readJson(response);
    assert.equal(response.status, 200);
    assert.match(generatedRequest.contents, /Reply in the same language as the user's question/);
    assert.equal(body.speechLanguage, "sw-KE");
  });
});

test("route destination is emitted only for a known routable destination", async () => {
  await withServer({
    routeDestinations: [{ id: "library", name: "USIU Library" }],
    createAI: () => mockAI({ response: modelResponse({ destinationId: "library" }) })
  }, async base => {
    const response = await post(base, { question: "Directions to the library" });
    const body = await readJson(response);
    assert.equal(response.status, 200);
    assert.deepEqual(body.destination, { id: "library", name: "USIU Library" });
    assert.deepEqual(body.sourceIds, ["campusMap", "mapLicense"]);
  });
});

test("missing GEMINI_API_KEY returns 503 without calling the model", async () => {
  let called = false;
  await withServer({
    env: {},
    createAI: () => { called = true; return mockAI(); }
  }, async base => {
    const response = await post(base, { question: "Hello" });
    assert.equal(response.status, 503);
    assert.deepEqual(await readJson(response), { error: "The chat service is not configured." });
    assert.equal(called, false);
  });
});

test("Gemini failure returns a safe 502 and does not leak its message or key to response/logs", async () => {
  const privateMessage = `provider details with ${MOCK_SECRET}`;
  const logEntries = [];
  await withServer({
    createAI: () => mockAI({ error: Object.assign(new Error(privateMessage), { status: 400 }) }),
    logger: { error: (...args) => logEntries.push(args) }
  }, async base => {
    const response = await post(base, { question: "What facilities are available?" });
    const responseText = await response.text();
    assert.equal(response.status, 502);
    assert.doesNotMatch(responseText, /provider details|unit-test-placeholder/);
    assert.doesNotMatch(JSON.stringify(logEntries), /provider details|unit-test-placeholder/);
  });
});

test("provider quota failure returns a safe 429", async () => {
  await withServer({
    createAI: () => mockAI({ error: Object.assign(new Error("quota details"), { status: 429 }) })
  }, async base => {
    const response = await post(base, { question: "What facilities are available?" });
    assert.equal(response.status, 429);
    assert.match((await readJson(response)).error, /quota/i);
  });
});

test("per-IP rate limit returns 429 after the configured request count", async () => {
  await withServer({ maxRequestsPerWindow: 1 }, async base => {
    const first = await post(base, { question: "Hello" });
    assert.equal(first.status, 200);
    const second = await post(base, { question: "Hello again" });
    assert.equal(second.status, 429);
    assert.equal(typeof (await readJson(second)).error, "string");
  });
});

test("non-POST chat requests return JSON 405 with Allow: POST; health is available", async () => {
  await withServer({}, async base => {
    const method = await fetch(`${base}/api/chat`);
    assert.equal(method.status, 405);
    assert.equal(method.headers.get("allow"), "POST");
    assert.equal(typeof (await readJson(method)).error, "string");

    const health = await fetch(`${base}/health`);
    assert.equal(health.status, 200);
    assert.deepEqual(await readJson(health), { status: "ok" });
  });
});
