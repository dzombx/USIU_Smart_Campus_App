# Deployment note — AppDeploy project `touchline-i4z6y5`

**This package has not been deployed or connected to AppDeploy.** The target repository/backend was not available to inspect, so no existing file path is named or guessed here.

## Safest integration route

Run this archive as a separate Node 22 backend service. Add the package files to a new backend service source location selected after inspecting the actual deployment setup. Configure the host's same-origin `/api/chat` path to reverse-proxy to this service's `/api/chat`, and route `/health` to the service for health checks if needed. Keep the React frontend using relative `fetch("/api/chat", ...)`; no frontend changes are required if that is already its contract.

If the AppDeploy project already includes a compatible Node HTTP backend, its owner should inspect the real repository and determine which existing server/router owns API routes. Add `/api/chat` there non-destructively, preserve all other route handlers and host startup logic, and merge only the `@google/genai` dependency. Do not overwrite an unknown server file or package manifest. This ZIP is a complete service and is not a drop-in Express/Koa/Next route file; framework-specific mounting needs to be adapted to the host after inspection.

## Required configuration

- Configure the server-side managed secret named `GEMINI_API_KEY` in AppDeploy. The real key is intentionally not in this archive and should not be sent through chat, WhatsApp, or frontend code.
- Let AppDeploy provide `PORT`; the service listens on that port. Node.js 22 or later is required.
- The service includes an in-memory limit of 30 requests per observed IP per minute. For multiple replicas or proxy IP behavior, use only a documented trusted-client-IP mechanism or a shared host-side limiter after reviewing the platform contract.
- No frontend credentials or cookies are expected by this API. Keep the host's authentication, database, demo users, realtime routes, and other APIs unchanged.

## Files to add

For the separate-service option, add the **entire contents of this ZIP** to the selected new service directory: `server.js`, the imported chatbot data/helper modules, `public/data/*`, package manifest/lockfile, tests, and the documentation. Do not copy or overwrite anything into the React frontend directory. The archive does not contain a frontend.

If the existing backend is selected instead, do not copy over its root files. Inspect the host framework, then selectively merge the imported data/helper files into a nonconflicting location and adapt the route while preserving all existing backend entry points and dependencies. The host's exact receiving file cannot be identified from the supplied information.

## Verification

1. In the extracted service directory, run `npm ci` and `npm test`. The automated tests mock Gemini; they need no real API key and make no provider calls.
2. Set the managed secret and start the service with AppDeploy's normal Node process command (`npm start`). Confirm `GET /health` returns `200`.
3. From a trusted test client, call the host's same-origin `POST /api/chat` path with a harmless question and verify the response contains `answer`, `sourceIds`, `webSources`, `destination`, and `speechLanguage`.
4. Confirm `GET /api/chat` returns `405` with `Allow: POST`; confirm an empty/missing-key test environment returns `503` without exposing secrets.
5. Do not place a real key in a command transcript or test fixture. Do not test from the browser using the provider key.

A sample live verification request, to run only after deployment and secret configuration (it consumes provider quota):

```sh
curl -i -X POST 'https://YOUR-SAME-ORIGIN/api/chat' \
  -H 'Content-Type: application/json' \
  --data '{"question":"What facilities are available?","history":[],"language":"en"}'
```

Replace the placeholder origin with the real AppDeploy origin. Do not paste a secret into this command.
