const MAX_WEB_SOURCES = 5;
const MAX_URL_LENGTH = 2048;
const MAX_LABEL_LENGTH = 140;

export function createGroundedJsonConfig() {
  return {
    responseMimeType: "application/json",
    maxOutputTokens: 800,
    tools: [{ googleSearch: {} }]
  };
}

function isPublicHttpsUrl(value) {
  if (typeof value !== "string" || value.length < 8 || value.length > MAX_URL_LENGTH) return null;
  let url;
  try {
    url = new URL(value);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" || url.username || url.password) return null;
  const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
  if (!hostname.includes(".") || hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".local") || hostname.endsWith(".internal")) return null;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname) || hostname.startsWith("[")) return null;
  return url;
}

function cleanLabel(value, fallback) {
  if (typeof value !== "string") return fallback;
  const label = value.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim();
  return (label || fallback).slice(0, MAX_LABEL_LENGTH);
}

export function sanitizeWebSources(entries, limit = MAX_WEB_SOURCES) {
  if (!Array.isArray(entries)) return [];
  const max = Math.max(0, Math.min(MAX_WEB_SOURCES, Number.isFinite(limit) ? Math.floor(limit) : MAX_WEB_SOURCES));
  if (max === 0) return [];
  const seen = new Set();
  const safe = [];
  for (const entry of entries) {
    const url = isPublicHttpsUrl(entry?.url || entry?.uri);
    if (!url || seen.has(url.href)) continue;
    seen.add(url.href);
    safe.push({
      url: url.href,
      label: cleanLabel(entry?.label || entry?.title, url.hostname)
    });
    if (safe.length >= max) break;
  }
  return safe;
}

export function extractGoogleSearchSources(response, limit = MAX_WEB_SOURCES) {
  const candidates = Array.isArray(response?.candidates) ? response.candidates : [];
  const entries = [];
  for (const candidate of candidates) {
    const metadata = candidate?.groundingMetadata || candidate?.grounding_metadata;
    const chunks = metadata?.groundingChunks || metadata?.grounding_chunks;
    if (!Array.isArray(chunks)) continue;
    for (const chunk of chunks) {
      const web = chunk?.web || chunk?.webPage || chunk?.web_page;
      if (!web) continue;
      entries.push({ url: web.uri || web.url, label: web.title || web.domain });
    }
  }
  return sanitizeWebSources(entries, limit);
}
