USIU Smart Campus complete AppDeploy handoff

1. Read USIU_Smart_Campus_Complete_AppDeploy_Integration_Prompt.md.
2. Apply USIU_Smart_Campus_v10_Login_Contrast.zip to the existing AppDeploy frontend as instructed.
3. Deploy or mount usiu-smart-campus-chatbot-backend.zip non-destructively as instructed.
4. Do not replace Marlies' existing backend, authentication, database, credentials, routes, or realtime behavior.
