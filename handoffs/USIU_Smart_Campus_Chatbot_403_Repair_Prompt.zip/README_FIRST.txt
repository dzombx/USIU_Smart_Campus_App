USIU Smart Campus chatbot repair handoff

Open USIU_Smart_Campus_Chatbot_403_Repair_Prompt.txt and paste its complete contents into the AppDeploy-connected agent for the existing project.

The observed problem is HTTP 403 from AppDeploy's access-restriction page on POST /api/chat. The prompt requires a non-destructive backend deployment and route verification.
