USIU Smart Campus — updated source export

This bundle is based on the AppDeploy build export supplied by the project owner.
Applied changes: teammate visual styling in source/src/index.css (with Tailwind directives and finance component hooks retained), and authenticated header wording in source/src/App.tsx.

All backend files, package configuration, Vite/Tailwind configuration, login placeholder, and tests are retained from the supplied build export. The build_manifest directory is intentionally omitted because its hashes and deployment metadata describe the original deployed build, not this edited source.

This is a source handoff only. It has not been uploaded to AppDeploy or deployed.
