# Emmanuel chatbot integration review

The chatbot ZIP was inspected without executing it. It is a clean, isolated React integration package and contains no API keys, passwords, or backend secrets.

## What it contains

- `integrations/emmanuel-chatbot/src/USIUChatbot.jsx` — reusable React chat widget.
- `integrations/emmanuel-chatbot/src/chat-client.js` — API adapter.
- `integrations/emmanuel-chatbot/src/usiu-chatbot.css` — scoped widget styles.
- `integrations/emmanuel-chatbot/docs/API-CONTRACT.md` — request/response and deployment contract.
- `integrations/emmanuel-chatbot/examples/ExistingReactPage.jsx` — usage example.
- Tests and package metadata.

## Backend dependency

The widget calls `POST /api/chat` and expects the existing Node backend. The ZIP does not include the backend, curated campus data, or `GEMINI_API_KEY`. The backend must remain deployed separately with the key stored server-side only.

The current backend is stateless and accepts `{ question, history, language }`. It does not accept `conversationId`. The widget keeps recent visible history in memory and maps its message into the required `question` field.

## Safe integration decision

The chatbot package is included here under `integrations/emmanuel-chatbot` but is not automatically inserted into `src/App.tsx`. This avoids replacing the current campus UI or changing the API seam before the backend origin and same-origin routing are confirmed.

The safest next integration is:

1. Copy the three runtime source files into a non-conflicting `src/chatbot/` folder.
2. Import `USIUChatbot` and its scoped stylesheet into the existing chatbot area.
3. Use an empty backend base URL when the AppDeploy project proxies `/api/chat` on the same origin.
4. Otherwise configure only the public backend origin through `VITE_USIU_CHAT_API_BASE_URL` and configure narrowly scoped CORS on the backend.
5. Keep `GEMINI_API_KEY` in the Node backend only.

No map or 3D integration is required by this package.
