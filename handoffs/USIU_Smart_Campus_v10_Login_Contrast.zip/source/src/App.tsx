import { useState, useEffect, useRef, useCallback } from 'react';
import { api, ws } from '@appdeploy/client';
import {
  Home,
  Calendar,
  Building2,
  Search,
  Utensils,
  Wallet,
  MapPin,
  Clock,
  Users,
  CheckCircle2,
  Plus,
  ChevronRight,
  X,
  AlertCircle,
  Loader2,
  LogOut,
  Mail,
  Lock,
  User,
  BarChart3,
  Trash2,
  Pencil,
  FileText,
  ExternalLink,
  Moon,
  Sun,
  MessageCircle,
} from 'lucide-react';
// The chatbot integration is intentionally delivered as portable JSX from Emmanuel's package.
// @ts-expect-error The host AppDeploy project compiles JSX imports through Vite.
import USIUChatbot from './chatbot/USIUChatbot.jsx';

type Tab =
  | 'home'
  | 'events'
  | 'services'
  | 'lostfound'
  | 'cafeteria'
  | 'finance'
  | 'admin'
  | 'chatbot';

interface AuthUser {
  userId: string;
  email: string;
  name: string;
  role: 'student' | 'admin';
}

interface EventItem {
  id: string;
  title: string;
  category: string;
  date: string;
  time: string;
  location: string;
  description: string;
  capacity: number;
  registered: number;
  isRegistered?: boolean;
}

interface LostFoundItem {
  id: string;
  type: 'lost' | 'found';
  title: string;
  description: string;
  location: string;
  date: string;
  contact: string;
  status: 'open' | 'claimed';
  photoUrl?: string | null;
  photoPath?: string | null;
}

interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
  description: string;
}

interface CampusService {
  id: string;
  category: 'Academic' | 'Non-Academic';
  title: string;
  description: string;
  contact?: string;
  website?: string;
  attachmentName?: string;
  attachmentUrl?: string | null;
}

interface Order {
  id: string;
  items: string[];
  total: number;
  pickupTime: string;
  status: string;
  createdAt: number;
}

interface Expense {
  id: string; title: string; amount: number; category: string; date: string;
  expenseType?: 'daily' | 'monthly';
}
interface MonthlyExpense { id: string; title: string; amount: number; category: string; createdAt?: number; }

interface QueueState {
  length: number;
  estimatedWait: number;
  updatedAt: number;
}

interface CampusWeather {
  temperature: number;
  windSpeed: number;
  weatherCode: number;
}

interface AdminStats {
  totalUsers: number;
  activeSessions: number;
  signedInUsers: number;
  recentUsers: {
    id: string;
    email: string;
    name: string;
    createdAt: number | null;
    isSignedIn: boolean; role?: string;
  }[];
  totalUsageEvents: number;
  usageByCategory: Record<string, number>;
  uniqueUsersTracked: number;
  usageReports: Record<'daily' | 'weekly' | 'monthly', { key: string; visits: number; uniqueUsers: number; byCategory: Record<string, number> }[]>;
}

const TOKEN_KEY = 'sc_token';
const USER_KEY = 'sc_user';

const CATEGORIES = ['All', 'Academic', 'Sports', 'Social', 'Cultural'];
const FAQS = [
  {
    q: 'How do I reset my campus Wi-Fi password?',
    a: 'Go to ICT Support and submit a ticket or visit the helpdesk in the Admin building.',
  },
  {
    q: 'Where can I get a student ID card replacement?',
    a: 'Student Affairs office, ground floor. Bring a passport photo and pay the replacement fee.',
  },
  {
    q: 'How do I book a counselling session?',
    a: 'Use the Career & Counselling Services page or call the listed number during office hours.',
  },
];

const MENU: MenuItem[] = [
  {
    id: 'm1',
    name: 'Chicken Rice Bowl',
    price: 350,
    category: 'Mains',
    description: 'Grilled chicken, rice, vegetables',
  },
  {
    id: 'm2',
    name: 'Veggie Wrap',
    price: 250,
    category: 'Mains',
    description: 'Fresh vegetables, hummus, whole-wheat wrap',
  },
  {
    id: 'm3',
    name: 'Beef Burger',
    price: 450,
    category: 'Mains',
    description: 'Homemade patty, cheese, fries',
  },
  {
    id: 'm4',
    name: 'Caesar Salad',
    price: 300,
    category: 'Salads',
    description: 'Romaine, croutons, parmesan',
  },
  {
    id: 'm5',
    name: 'Fruit Smoothie',
    price: 200,
    category: 'Drinks',
    description: 'Banana, mango, yogurt',
  },
  {
    id: 'm6',
    name: 'Coffee / Tea',
    price: 120,
    category: 'Drinks',
    description: 'Hot or iced',
  },
];

const EXPENSE_CATEGORIES = [
  'General',
  'Food',
  'Transport',
  'Books',
  'Entertainment',
  'Housing',
  'Other',
];

function cx(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(' ');
}

function CampusMark() {
  return (
    <span className="campus-brand-mark" aria-hidden="true">
      <span className="campus-brand-ribbon campus-brand-ribbon-blue" />
      <span className="campus-brand-ribbon campus-brand-ribbon-yellow" />
      <span className="campus-brand-letter">U</span>
    </span>
  );
}

function formatKsh(amount: number) {
  return 'Ksh ' + amount.toLocaleString('en-KE', { maximumFractionDigits: 0 });
}

function weatherDescription(code: number) {
  if (code === 0) return 'Clear skies';
  if ([1, 2].includes(code)) return 'Partly cloudy';
  if (code === 3) return 'Overcast';
  if ([45, 48].includes(code)) return 'Misty';
  if ([51, 53, 55, 56, 57].includes(code)) return 'Light drizzle';
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return 'Rain nearby';
  if ([71, 73, 75, 77, 85, 86].includes(code)) return 'Cool and cloudy';
  if ([95, 96, 99].includes(code)) return 'Storm nearby';
  return 'Changing conditions';
}

function getStoredToken(): string | null {
  try {
    return sessionStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

function getStoredUser(): AuthUser | null {
  try {
    const raw = sessionStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveSession(token: string, user: AuthUser) {
  sessionStorage.setItem(TOKEN_KEY, token);
  sessionStorage.setItem(USER_KEY, JSON.stringify(user));
}

function clearSession() {
  sessionStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem(USER_KEY);
}

export default function App() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [accountOpen, setAccountOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    try {
      return localStorage.getItem('usiu-theme') === 'dark';
    } catch {
      return false;
    }
  });
  const [authReady, setAuthReady] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [loginPortal, setLoginPortal] = useState<'student' | 'admin'>('student');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoBase64, setPhotoBase64] = useState<string | null>(null);
  const [photoContentType, setPhotoContentType] = useState('image/jpeg');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [menu, setMenu] = useState<
    {
      id: string;
      name: string;
      price: number;
      category: string;
      description: string;
      available?: boolean;
    }[]
  >([]);

  const [tab, setTab] = useState<Tab>('home');
  const [events, setEvents] = useState<EventItem[]>([]);
  const [lostFound, setLostFound] = useState<LostFoundItem[]>([]);
  const [campusServices, setCampusServices] = useState<CampusService[]>([]);
  const [serviceFilter, setServiceFilter] = useState<'All' | 'Academic' | 'Non-Academic'>('All');
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [serviceFileBase64, setServiceFileBase64] = useState<string | null>(null);
  const [serviceFileName, setServiceFileName] = useState('');
  const [serviceFileType, setServiceFileType] = useState('');
  const [orders, setOrders] = useState<Order[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [monthlyExpenses, setMonthlyExpenses] = useState<MonthlyExpense[]>([]);
  const [financeView, setFinanceView] = useState<'25days' | '6months'>('25days');
  const [curveDays, setCurveDays] = useState(25);
  const [selectedCalendarDate, setSelectedCalendarDate] = useState(new Date().toISOString().slice(0, 10));
  const [calendarMonth, setCalendarMonth] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const [editingExpenseId, setEditingExpenseId] = useState<string | null>(null);
  const [monthlyBudget, setMonthlyBudget] = useState(0);
  const [budgetInput, setBudgetInput] = useState('');
  const [adminStats, setAdminStats] = useState<AdminStats | null>(null);
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [queue, setQueue] = useState<QueueState>({
    length: 0,
    estimatedWait: 0,
    updatedAt: 0,
  });
  const [campusWeather, setCampusWeather] = useState<CampusWeather | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [lfFilter, setLfFilter] = useState<'all' | 'lost' | 'found'>('all');
  const [selectedLostFound, setSelectedLostFound] = useState<LostFoundItem | null>(null);
  const [editingMenuId, setEditingMenuId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState<string | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [pickupTime, setPickupTime] = useState('12:30');
  const [submitting, setSubmitting] = useState(false);

  const connRef = useRef<ReturnType<typeof ws.connect> | null>(null);

  useEffect(() => {
    document.documentElement.dataset.theme = darkMode ? 'dark' : 'light';
    try {
      localStorage.setItem('usiu-theme', darkMode ? 'dark' : 'light');
    } catch {
      /* Theme still works when storage is unavailable. */
    }
  }, [darkMode]);

  useEffect(() => {
    let active = true;
    const token = getStoredToken();
    const stored = getStoredUser();

    if (!token || !stored) {
      setAuthReady(true);
      return () => {
        active = false;
      };
    }

    api
      .post('/api/auth/session', { _token: token })
      .then((res) => {
        if (!active) return;
        const validatedUser = res.data.user as AuthUser;
        saveSession(token, validatedUser);
        setUser(validatedUser);
      })
      .catch(() => {
        if (!active) return;
        clearSession();
        setUser(null);
      })
      .finally(() => {
        if (active) setAuthReady(true);
      });

    return () => {
      active = false;
    };
  }, []);

  const loadAll = useCallback(async () => {
    if (!getStoredToken()) return;
    try {
      setLoading(true);
      setError(null);
      const token = getStoredToken();

      const isAdmin = user?.role === 'admin';
      const [ev, lf, ords, exp, bud, recurring, q, stats, menuRes, servicesRes] = await Promise.all([
        api.post('/api/events/list', { _token: token }),
        api.get('/api/lostfound'),
        isAdmin ? Promise.resolve({ data: { items: [] } }) : api.post('/api/orders/list', { _token: token }),
        isAdmin ? Promise.resolve({ data: { items: [] } }) : api.post('/api/expenses/list', { _token: token }),
        isAdmin ? Promise.resolve({ data: { monthlyBudget: 0 } }) : api.post('/api/budget/get', { _token: token }),
        isAdmin ? Promise.resolve({ data: { items: [] } }) : api.post('/api/recurring-expenses/list', { _token: token }),
        api.get('/api/queue'),
        isAdmin ? api.post('/api/admin/stats', { _token: token }) : Promise.resolve({ data: null }),
        api.post('/api/menu/list', {}),
        api.post('/api/services/list', { _token: token }),
      ]);
      setEvents(ev.data.items || []); setLostFound(lf.data.items || []);
      setCampusServices(servicesRes.data.items || []);
      setOrders(ords.data.items || []); setExpenses(exp.data.items || []);
      setMonthlyExpenses(recurring.data.items || []);
      setMonthlyBudget(bud.data.monthlyBudget || 0); setBudgetInput(String(bud.data.monthlyBudget || ''));
      setQueue(q.data || { length: 0, estimatedWait: 0, updatedAt: Date.now() });
      setAdminStats(stats.data || null); setMenu(menuRes.data.items || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (user) loadAll();
  }, [user, loadAll]);

  useEffect(() => {
    let active = true;
    fetch('https://api.open-meteo.com/v1/forecast?latitude=-1.2186&longitude=36.8834&current=temperature_2m,weather_code,wind_speed_10m&timezone=Africa%2FNairobi')
      .then(response => response.ok ? response.json() : Promise.reject(new Error('Weather unavailable')))
      .then(data => {
        if (!active || !data.current) return;
        setCampusWeather({
          temperature: Number(data.current.temperature_2m),
          windSpeed: Number(data.current.wind_speed_10m),
          weatherCode: Number(data.current.weather_code),
        });
      })
      .catch(() => {
        if (active) setCampusWeather(null);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!user) return;
    api.post('/api/usage/track', { category: tab, _token: getStoredToken() }).catch(() => {});
  }, [user, tab]);

  useEffect(() => {
    if (!user) return;
    const conn = ws.connect();
    connRef.current = conn;

    conn.onMessage((msg: any) => {
      if (
        msg?.type === 'entity.update' &&
        msg.payload?.entity_type === 'queue' &&
        msg.payload?.entity_id === 'main'
      ) {
        setQueue(msg.payload.data);
      }
    });

    conn.ready.then(() => {
      const connection_id = conn.connectionId;
      if (connection_id) {
        api
          .post('/api/subscriptions', {
            entity_type: 'queue',
            entity_id: 'main',
            connection_id,
          })
          .catch(() => {});
      }
    });

    return () => {
      if (conn.connectionId) {
        api
          .post('/api/subscriptions/remove', {
            entity_type: 'queue',
            entity_id: 'main',
            connection_id: conn.connectionId,
          })
          .catch(() => {});
      }
      conn.disconnect();
    };
  }, [user]);

  async function handleAuth(e: React.FormEvent) {
    e.preventDefault();
    setAuthError(null);
    setAuthLoading(true);
    try {
      const path =
        authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const payload: any = {
        email: authEmail.trim(),
        password: authPassword,
        portal: loginPortal,
      };
      if (authMode === 'register') {
        payload.name = authName.trim();
      }

      const res = await api.post(path, payload);
      const { token, user: u } = res.data;
      saveSession(token, u);
      setUser(u);
      setAuthPassword('');
    } catch (err: any) {
      setAuthError(err?.message || 'Authentication failed');
    } finally {
      setAuthLoading(false);
    }
  }

  async function handleLogout() {
    try {
      const token = getStoredToken();
      await api.post('/api/auth/logout', { _token: token });
    } catch {
      /* ignore */
    }
    clearSession();
    setUser(null);
    setExpenses([]); setMonthlyExpenses([]);
    setMonthlyBudget(0);
    setAdminStats(null);
  }

  const filteredEvents =
    categoryFilter === 'All'
      ? events
      : events.filter(e => e.category === categoryFilter);

  const filteredLf =
    lfFilter === 'all'
      ? lostFound
      : lostFound.filter(i => i.type === lfFilter);

  function onServiceFileSelected(file: File | null) {
    if (!file) {
      setServiceFileBase64(null);
      setServiceFileName('');
      setServiceFileType('');
      return;
    }
    const allowed = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowed.includes(file.type)) {
      setError('Choose a PNG, JPG, WEBP, GIF, PDF or Word document.');
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      setError('Attachment must be 4 MB or smaller.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      setServiceFileBase64(result.split(',')[1] || '');
      setServiceFileName(file.name);
      setServiceFileType(file.type);
    };
    reader.readAsDataURL(file);
  }

  function startEditService(service: CampusService) {
    setEditingServiceId(service.id);
    setServiceFileBase64(null);
    setServiceFileName('');
    setServiceFileType('');
    setFormData({ category: service.category, title: service.title, description: service.description || '', contact: service.contact || '', website: service.website || '' });
    setShowForm('campus-service');
  }

  async function saveCampusService() {
    if (user?.role !== 'admin' || !formData.title?.trim()) return;
    try {
      setSubmitting(true);
      await api.post('/api/services/save', {
        id: editingServiceId || undefined,
        category: formData.category || 'Academic',
        title: formData.title,
        description: formData.description || '',
        contact: formData.contact || '',
        website: formData.website || '',
        attachmentBase64: serviceFileBase64 || undefined,
        attachmentName: serviceFileName || undefined,
        attachmentContentType: serviceFileType || undefined,
        _token: getStoredToken(),
      });
      setShowForm(null);
      setEditingServiceId(null);
      setFormData({});
      setServiceFileBase64(null);
      setServiceFileName('');
      setServiceFileType('');
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Could not save campus service');
    } finally {
      setSubmitting(false);
    }
  }

  async function deleteCampusService(id: string) {
    if (user?.role !== 'admin' || !window.confirm('Delete this campus service and its uploaded attachment?')) return;
    try {
      setSubmitting(true);
      await api.post('/api/services/delete', { id, _token: getStoredToken() });
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Could not delete campus service');
    } finally {
      setSubmitting(false);
    }
  }

  async function createEvent() {
    if (!formData.title || !formData.date || !formData.time || !formData.location) { setError('Please complete the event title, date, time and location.'); return; }
    try {
      setSubmitting(true);
      await api.post('/api/events', { title: formData.title, category: formData.category || 'Social', date: formData.date, time: formData.time, location: formData.location, description: formData.description || '', capacity: Number(formData.capacity) || 100, _token: getStoredToken() });
      setShowForm(null); setFormData({}); await loadAll();
    } catch (e: any) { setError(e?.message || 'Failed to publish event'); }
    finally { setSubmitting(false); }
  }

  async function registerForEvent(eventId: string) {
    if (user?.role !== 'student') return;
    try {
      setSubmitting(true);
      const token = getStoredToken();
      await api.post('/api/events/' + eventId + '/register', { _token: token });
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Registration failed');
    } finally {
      setSubmitting(false);
    }
  }

  async function addMenuItem() {
    if (!formData.name || !formData.price) return;
    try {
      setSubmitting(true);
      const token = getStoredToken();
      const payload = { id: editingMenuId || undefined, name: formData.name, price: Number(formData.price), category: formData.category || 'Mains', description: formData.description || '', available: true, _token: token };
      await api.post(editingMenuId ? '/api/menu/update' : '/api/menu/add', payload);
      setEditingMenuId(null);
      setShowForm(null);
      setFormData({});
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Failed to add menu item');
    } finally {
      setSubmitting(false);
    }
  }

  async function deleteMenuItem(id: string) {
    try {
      setSubmitting(true);
      const token = getStoredToken();
      await api.post('/api/menu/delete', { id, _token: token });
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Failed to delete item');
    } finally {
      setSubmitting(false);
    }
  }

  function onPhotoSelected(file: File | null) {
    if (!file) {
      setPhotoPreview(null);
      setPhotoBase64(null);
      return;
    }
    if (!file.type.startsWith('image/')) {
      setError('Please choose an image file');
      return;
    }
    if (file.size > 2.5 * 1024 * 1024) {
      setError('Photo must be under 2.5 MB');
      return;
    }
    setPhotoContentType(file.type || 'image/jpeg');
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      setPhotoPreview(result);
      setPhotoBase64(result);
    };
    reader.readAsDataURL(file);
  }

  async function submitLostFound() {
    if (!formData.title || !formData.description) return;
    try {
      setSubmitting(true);
      await api.post('/api/lostfound', {
        type: formData.type || 'lost',
        title: formData.title,
        description: formData.description,
        location: formData.location || 'Campus',
        contact: formData.contact || 'Student',
        photoBase64: photoBase64 || undefined,
        photoContentType: photoContentType,
      });
      setShowForm(null);
      setFormData({});
      setPhotoPreview(null);
      setPhotoBase64(null);
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Failed to submit');
    } finally {
      setSubmitting(false);
    }
  }

  async function placeOrder() {
    if (user?.role !== 'student' || selectedItems.length === 0) return;
    try {
      setSubmitting(true);
      const items = menu.filter(m => selectedItems.includes(m.id));
      const total = items.reduce((s, i) => s + i.price, 0);
      await api.post('/api/orders', {
        items: items.map(i => i.name),
        total,
        pickupTime,
        _token: getStoredToken(),
      });
      setSelectedItems([]);
      setShowForm(null);
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Order failed');
    } finally {
      setSubmitting(false);
    }
  }

  async function addExpense() {
    const category = formData.category === 'Custom' ? (formData.customCategory || '').trim() : (formData.category || 'General');
    if (user?.role !== 'student' || !category || formData.amount === '' || !Number.isFinite(Number(formData.amount)) || Number(formData.amount) < 0) return;
    try {
      setSubmitting(true);
      const token = getStoredToken();
      const payload = {
        title: category, amount: Number(formData.amount), category,
        date: formData.date || new Date().toISOString().slice(0, 10), _token: token,
      };
      if (editingExpenseId) await api.post('/api/expenses/update', { id: editingExpenseId, ...payload });
      else await api.post('/api/expenses', { ...payload, expenseType: 'daily' });
      setShowForm(null); setFormData({}); setEditingExpenseId(null); await loadAll();
    } catch (e: any) { setError(e?.message || 'Failed to save expense'); }
    finally { setSubmitting(false); }
  }

  function startEditExpense(expense: Expense) {
    setEditingExpenseId(expense.id);
    setFormData({ title: expense.title, amount: String(expense.amount), category: EXPENSE_CATEGORIES.includes(expense.category) ? expense.category : 'Custom', customCategory: EXPENSE_CATEGORIES.includes(expense.category) ? '' : expense.category, date: String(expense.date || '').slice(0, 10) });
    setShowForm('expense');
  }

  async function deleteExpense(id: string) {
    if (user?.role !== 'student' || !window.confirm('Delete this expense? This cannot be undone.')) return;
    try {
      setSubmitting(true);
      await api.post('/api/expenses/delete', { id, _token: getStoredToken() });
      await loadAll();
    } catch (e: any) { setError(e?.message || 'Failed to delete expense'); }
    finally { setSubmitting(false); }
  }

  async function addMonthlyExpense() {
    if (user?.role !== 'student' || !formData.title || !formData.amount) return;
    try {
      setSubmitting(true);
      await api.post('/api/recurring-expenses', { title: formData.title, amount: Number(formData.amount), category: formData.category === 'Custom' ? (formData.customCategory || '').trim() : (formData.category || 'Housing'), _token: getStoredToken() });
      setShowForm(null); setFormData({}); await loadAll();
    } catch (e: any) { setError(e?.message || 'Failed to save monthly expense'); }
    finally { setSubmitting(false); }
  }
  async function deleteMonthlyExpense(id: string) {
    try {
      setSubmitting(true);
      await api.post('/api/recurring-expenses/delete', { id, _token: getStoredToken() });
      await loadAll();
    } catch (e: any) { setError(e?.message || 'Failed to remove monthly expense'); }
    finally { setSubmitting(false); }
  }

  async function saveBudget() {
    if (user?.role !== 'student') return;
    try {
      setSubmitting(true);
      const token = getStoredToken();
      const res = await api.post('/api/budget/set', {
        monthlyBudget: Number(budgetInput) || 0,
        _token: token,
      });
      setMonthlyBudget(res.data.monthlyBudget || 0);
    } catch (e: any) {
      setError(e?.message || 'Failed to save budget');
    } finally {
      setSubmitting(false);
    }
  }

  async function joinQueue() {
    if (user?.role !== 'student') return;
    try {
      setSubmitting(true);
      await api.post('/api/queue/join');
      await loadAll();
    } catch (e: any) {
      setError(e?.message || 'Could not join queue');
    } finally {
      setSubmitting(false);
    }
  }

  const currentDate = new Date();
  const currentMonthKey = currentDate.toISOString().slice(0, 7);
  const currentMonthExpenses = expenses.filter(e => String(e.date || '').slice(0, 7) === currentMonthKey);
  const monthlyFixedTotal = monthlyExpenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const totalSpent = currentMonthExpenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0) + monthlyFixedTotal;
  const remaining = monthlyBudget - totalSpent;
  const budgetPct = monthlyBudget > 0
    ? Math.min(100, Math.round((totalSpent / monthlyBudget) * 100))
    : 0;

  const byCategory: Record<string, number> = {};
  [...currentMonthExpenses, ...monthlyExpenses].forEach(expense => {
    byCategory[expense.category || 'General'] = (byCategory[expense.category || 'General'] || 0) + Number(expense.amount || 0);
  });
  const topCategory = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0];

  const localDayKey = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return year + '-' + month + '-' + day;
  };
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dailySpend = Array.from({ length: 25 }, (_, index) => {
    const day = new Date(today);
    day.setDate(today.getDate() - 24 + index);
    const key = localDayKey(day);
    const amount = expenses
      .filter(expense => expense.expenseType !== 'monthly' && String(expense.date || '').slice(0, 10) === key)
      .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
    return {
      key,
      amount,
      label: day.toLocaleDateString('en-KE', { day: 'numeric', month: 'short' }),
      shortLabel: day.toLocaleDateString('en-KE', { day: 'numeric' }),
    };
  });
  const dailyTotal = dailySpend.reduce((sum, day) => sum + day.amount, 0);
  const calendarMonthStart = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), 1);
  const calendarStartOffset = (calendarMonthStart.getDay() + 6) % 7;
  const calendarDays = Array.from({ length: 42 }, (_, index) => {
    const date = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), index - calendarStartOffset + 1);
    const key = localDayKey(date);
    const dayExpenses = expenses.filter(expense => String(expense.date || '').slice(0, 10) === key);
    return { key, date, inMonth: date.getMonth() === calendarMonth.getMonth(), amount: dayExpenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0), count: dayExpenses.length };
  });
  const selectedDayExpenses = expenses.filter(expense => String(expense.date || '').slice(0, 10) === selectedCalendarDate).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  const selectedDayTotal = selectedDayExpenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const curveSpend = Array.from({ length: curveDays }, (_, index) => {
    const day = new Date(today);
    day.setDate(today.getDate() - curveDays + 1 + index);
    const key = localDayKey(day);
    const amount = expenses
      .filter(expense => expense.expenseType !== 'monthly' && String(expense.date || '').slice(0, 10) === key)
      .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
    return {
      key,
      amount,
      label: day.toLocaleDateString('en-KE', { day: 'numeric', month: 'short' }),
      shortLabel: day.toLocaleDateString('en-KE', { day: 'numeric' }),
    };
  });
  const curveTotal = curveSpend.reduce((sum, day) => sum + day.amount, 0);
  const curveMax = Math.max(...curveSpend.map(day => day.amount), 1);
  const curvePoints = curveSpend.map((day, index) => {
    const x = 38 + index * (722 / Math.max(curveDays - 1, 1));
    const y = 185 - (day.amount / curveMax) * 145;
    return x + ',' + y;
  }).join(' ');
  const hasCurveData = curveSpend.some(day => day.amount > 0);
  const weeklySpend = Array.from({ length: 4 }, (_, index) => {
    const days = dailySpend.slice(index * 7, index === 3 ? 25 : (index + 1) * 7);
    return {
      label: 'Week ' + (index + 1),
      range: days[0].label + ' – ' + days[days.length - 1].label,
      amount: days.reduce((sum, day) => sum + day.amount, 0),
    };
  });
  const recentSevenDaySpend = dailySpend.slice(-7).reduce((sum, day) => sum + day.amount, 0);
  const averageDailySpend = recentSevenDaySpend / 7;
  const projectedNext25Days = averageDailySpend * 25;
  const monthlySpend = Array.from({ length: 6 }, (_, index) => {
    const monthDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 5 + index, 1);
    const key = monthDate.toISOString().slice(0, 7);
    const amount = expenses
      .filter(expense => String(expense.date || '').slice(0, 7) === key)
      .reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
    return { key, amount, label: monthDate.toLocaleDateString('en-KE', { month: 'short' }) };
  });
  const trendMax = Math.max(...monthlySpend.map(month => month.amount), 1);
  const trendPoints = monthlySpend.map((month, index) => {
    const x = 38 + index * (542 / 5);
    const y = 185 - (month.amount / trendMax) * 150;
    return x + ',' + y;
  }).join(' ');
  const hasTrendData = monthlySpend.some(month => month.amount > 0);

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <Loader2 className="animate-spin text-slate-600" size={32} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="campus-auth-screen min-h-screen bg-slate-200 flex items-center justify-center p-4">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8">
            <div className="campus-auth-brand mb-4">
              <CampusMark />
            </div>
            <h1 className="text-2xl font-bold text-slate-900">Smart Campus</h1>
            <p className="text-slate-500 text-sm mt-1">
              {loginPortal === 'admin'
                ? 'Admin portal — manage campus services'
                : 'Student portal — campus life in one place'}
            </p>
            <p className="auth-welcome-message">
              Welcome to your home away from home.
            </p>
          </div>

          <form
            onSubmit={handleAuth}
            className="bg-white rounded-2xl shadow-lg border border-slate-200 p-6 space-y-4"
          >
            {loginPortal === 'student' && (
              <div className="flex rounded-xl bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setAuthError(null);
                  }}
                  className={cx(
                    'flex-1 py-2 rounded-lg text-sm font-medium transition',
                    authMode === 'login'
                      ? 'auth-mode-tab-active'
                      : 'auth-mode-tab-inactive'
                  )}
                >
                  Login
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('register');
                    setAuthError(null);
                  }}
                  className={cx(
                    'flex-1 py-2 rounded-lg text-sm font-medium transition',
                    authMode === 'register'
                      ? 'auth-mode-tab-active'
                      : 'auth-mode-tab-inactive'
                  )}
                >
                  Register
                </button>
              </div>
            )}

            {authMode === 'register' && (
              <>
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">Name</label>
                  <div className="relative">
                    <User
                      size={16}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                    />
                    <input
                      type="text"
                      value={authName}
                      onChange={e => setAuthName(e.target.value)}
                      placeholder="Your name"
                      className="w-full border border-slate-200 rounded-xl pl-10 pr-3 py-2.5 text-sm"
                    />
                  </div>
                </div>

              </>
            )}

            <div>
              <label className="text-xs text-slate-500 mb-1 block">Email</label>
              <div className="relative">
                <Mail
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="email"
                  required
                  value={authEmail}
                  onChange={e => setAuthEmail(e.target.value)}
                  placeholder="student@campus.edu"
                  className="w-full border border-slate-200 rounded-xl pl-10 pr-3 py-2.5 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-500 mb-1 block">
                Password
              </label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="password"
                  required
                  minLength={8}
                  value={authPassword}
                  onChange={e => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full border border-slate-200 rounded-xl pl-10 pr-3 py-2.5 text-sm"
                />
              </div>
            </div>

            {authError && (
              <div className="bg-red-50 text-red-700 text-sm px-3 py-2 rounded-xl flex items-start gap-2">
                <AlertCircle size={16} className="shrink-0 mt-0.5" />
                {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="btn-primary w-full py-3"
            >
              {authLoading
                ? 'Please wait…'
                : authMode === 'login'
                  ? 'Sign In'
                  : 'Create Account'}
            </button>

            <p className="text-center text-xs text-slate-400">
              Demo accounts use the secure project bootstrap password. Not for production use.
            </p>

            <div className="pt-2 border-t border-slate-100 text-center">
              {loginPortal === 'student' ? (
                <button
                  type="button"
                  onClick={() => {
                    setLoginPortal('admin');
                    setAuthMode('login');
                    setAuthError(null);
                  }}
                  className="text-sm text-slate-700 font-medium underline underline-offset-2"
                >
                  Admin login →
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setLoginPortal('student');
                    setAuthMode('login');
                    setAuthError(null);
                  }}
                  className="text-sm text-slate-700 font-medium underline underline-offset-2"
                >
                  ← Student login
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="campus-app-shell min-h-screen pb-24 relative">
      <header className="sticky top-0 z-30 bg-slate-800 text-white px-4 py-4 shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <div className="campus-brand-lockup">
              <CampusMark />
              <div>
                <h1 className="text-xl font-bold tracking-tight">USIU Smart Campus</h1>
                <span className="campus-brand-caption">CAMPUS HUB</span>
              </div>
            </div>
            <p className="text-slate-300 text-xs">
              Campus Hub · {user.name || user.email}
              {user.role === 'admin' ? ' · Admin' : ' · Student'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="bg-white/10 rounded-full px-3 py-1 text-xs flex items-center gap-1">
              <Users size={12} />
              Queue: {queue.length} people
            </div>
            <button
              type="button"
              onClick={() => setDarkMode(current => !current)}
              className="theme-toggle bg-white/10 hover:bg-white/20 rounded-full p-2 transition"
              title={darkMode ? 'Use light theme' : 'Use dark theme'}
              aria-label={darkMode ? 'Use light theme' : 'Use dark theme'}
            >
              {darkMode ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <div className="account-control">
              <button
                type="button"
                onClick={() => setAccountOpen(current => !current)}
                className="account-button bg-white/10 hover:bg-white/20 rounded-full p-2 transition"
                title="View account details"
                aria-label="View account details"
                aria-expanded={accountOpen}
              >
                <User size={16} />
              </button>
              {accountOpen && (
                <div className="account-popover" role="dialog" aria-label="Account details">
                  <div className="account-popover-heading">Account details</div>
                  <strong>{user.name || 'Student'}</strong>
                  <span>{user.email}</span>
                  <span className="account-role">{user.role === 'admin' ? 'Administrator' : 'Student'}</span>
                </div>
              )}
            </div>
            <button
              onClick={handleLogout}
              className="bg-white/10 hover:bg-white/20 rounded-full px-3 py-2 transition flex items-center gap-2 text-sm font-medium"
              title="Sign out"
              aria-label="Log out"
            >
              <LogOut size={16} />
              <span>Log out</span>
            </button>
          </div>
        </div>
      </header>

      {error && (
        <div className="mx-4 mt-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-start gap-2 text-sm">
          <AlertCircle size={18} className="shrink-0 mt-0.5" />
          <div className="flex-1">{error}</div>
          <button onClick={() => setError(null)}>
            <X size={16} />
          </button>
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400">
          <Loader2 className="animate-spin mb-3" size={32} />
          <p>Loading campus data…</p>
        </div>
      ) : (
        <main className="px-4 pt-4">
          {tab === 'chatbot' && (
            <section className="chatbot-page" aria-labelledby="chatbot-page-title">
              <div className="chatbot-page__intro">
                <div>
                  <p className="chatbot-page__eyebrow">USIU CAMPUS ASSISTANT</p>
                  <h2 id="chatbot-page-title">Ask your campus.</h2>
                  <p>Get grounded answers about facilities, support, admissions, events, and student life.</p>
                </div>
                <button type="button" className="chatbot-page__back" onClick={() => setTab('home')}>
                  Back to campus hub
                </button>
              </div>
              <USIUChatbot
                className="chatbot-page__widget"
                title="USIU Campus Chatbot"
                backendUrl=""
                language="auto"
              />
            </section>
          )}

          {tab === 'home' && (
            <div className="space-y-4">
              <div className="card p-5 welcome-hero">
                <div className="welcome-hero-image" aria-hidden="true" />
                <div className="welcome-hero-content">
                  <p className="welcome-eyebrow">USIU-AFRICA · CAMPUS HUB</p>
                  <h2 className="welcome-name">
                    Welcome back, {user.name?.split(' ')[0] || 'Student'}
                  </h2>
                  <p className="welcome-subtitle">Stay on top of campus life</p>
                </div>
                <div className="weather-widget" aria-label="Current weather near USIU-Africa">
                  <span className="weather-widget-label">Campus weather</span>
                  {campusWeather ? (
                    <>
                      <strong>{Math.round(campusWeather.temperature)}°C</strong>
                      <span>{weatherDescription(campusWeather.weatherCode)}</span>
                      <small>Wind {Math.round(campusWeather.windSpeed)} km/h · USIU area</small>
                    </>
                  ) : (
                    <span>Weather unavailable right now</span>
                  )}
                </div>
              </div>

              {adminStats && (
                <div className="grid grid-cols-3 gap-2">
                  <div className="card p-3 text-center">
                    <div className="text-lg font-bold text-slate-800">
                      {adminStats.totalUsers}
                    </div>
                    <div className="text-[10px] text-slate-500 uppercase tracking-wide">
                      Users
                    </div>
                  </div>
                  <div className="card p-3 text-center">
                    <div className="text-lg font-bold text-slate-800">
                      {adminStats.signedInUsers}
                    </div>
                    <div className="text-[10px] text-slate-500 uppercase tracking-wide">
                      Signed in
                    </div>
                  </div>
                  <div className="card p-3 text-center">
                    <div className="text-lg font-bold text-slate-800">
                      {adminStats.activeSessions}
                    </div>
                    <div className="text-[10px] text-slate-500 uppercase tracking-wide">
                      Sessions
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setTab('events')}
                  className="card p-4 text-left hover:shadow-md transition"
                >
                  <Calendar className="text-slate-600 mb-2" size={22} />
                  <div className="font-medium text-sm">Events</div>
                  <div className="text-xs text-slate-500">
                    {events.length} upcoming
                  </div>
                </button>
                <button
                  onClick={() => setTab('services')}
                  className="card p-4 text-left hover:shadow-md transition"
                >
                  <Building2 className="text-slate-600 mb-2" size={22} />
                  <div className="font-medium text-sm">Campus Services</div>
                  <div className="text-xs text-slate-500">
                    {campusServices.length} services available
                  </div>
                </button>
                <button
                  onClick={() => setTab('cafeteria')}
                  className="card p-4 text-left hover:shadow-md transition"
                >
                  <Utensils className="text-slate-600 mb-2" size={22} />
                  <div className="font-medium text-sm">Cafeteria</div>
                  <div className="text-xs text-slate-500">
                    Queue: {queue.length} people · ~{queue.estimatedWait} min
                  </div>
                </button>
                <button
                  onClick={() => setTab('lostfound')}
                  className="card p-4 text-left hover:shadow-md transition"
                >
                  <Search className="text-slate-600 mb-2" size={22} />
                  <div className="font-medium text-sm">Lost & Found</div>
                  <div className="text-xs text-slate-500">
                    {lostFound.filter(i => i.status === 'open').length} open
                  </div>
                </button>
                {user.role === 'student' && <button onClick={() => setTab('finance')} className="card p-4 text-left hover:shadow-md transition"><Wallet className="text-slate-600 mb-2" size={22} /><div className="font-medium text-sm">Finance</div><div className="text-xs text-slate-500">{formatKsh(totalSpent)} spent this month</div></button>}
              </div>

              <div className="card p-4">
                <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Clock size={16} className="text-slate-600" /> Next Events
                </h3>
                {events.slice(0, 3).map(ev => (
                  <div
                    key={ev.id}
                    className="flex items-center gap-3 py-2 border-b border-slate-50 last:border-0"
                  >
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700 text-xs font-bold">
                      {ev.date.slice(5)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">
                        {ev.title}
                      </div>
                      <div className="text-xs text-slate-500">
                        {ev.time} · {ev.location}
                      </div>
                    </div>
                    <ChevronRight size={16} className="text-slate-300" />
                  </div>
                ))}
                {events.length === 0 && (
                  <p className="text-sm text-slate-400">No upcoming events</p>
                )}
              </div>

              {user.role === 'admin' && (
              <button
                onClick={() => setTab('admin')}
                className="card p-4 w-full text-left flex items-center gap-3 hover:shadow-md transition"
              >
                <BarChart3 className="text-slate-600" size={22} />
                <div>
                  <div className="font-medium text-sm">User database</div>
                  <div className="text-xs text-slate-500">
                    View registered & signed-in users
                  </div>
                </div>
                <ChevronRight size={16} className="text-slate-300 ml-auto" />
              </button>
              )}
            </div>
          )}

          {user.role === 'admin' && tab === 'admin' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">User database</h2>

              <div className="grid grid-cols-3 gap-2">
                <div className="card p-4 text-center">
                  <div className="text-2xl font-bold text-slate-800">
                    {adminStats?.totalUsers ?? '—'}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Registered users
                  </div>
                </div>
                <div className="card p-4 text-center">
                  <div className="text-2xl font-bold text-slate-800">
                    {adminStats?.signedInUsers ?? '—'}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Currently signed in
                  </div>
                </div>
                <div className="card p-4 text-center">
                  <div className="text-2xl font-bold text-slate-800">
                    {adminStats?.activeSessions ?? '—'}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Active sessions
                  </div>
                </div>
              </div>

              <section className="card p-4 space-y-4">
                <div><h3 className="font-semibold">App usage analytics</h3><p className="text-xs text-slate-500 mt-1">Visits recorded when signed-in users open each section.</p></div>
                <div className="grid grid-cols-2 gap-3"><div className="rounded-xl bg-slate-50 p-3"><div className="text-2xl font-bold">{adminStats?.totalUsageEvents ?? 0}</div><div className="text-xs text-slate-500">Total area visits</div></div><div className="rounded-xl bg-slate-50 p-3"><div className="text-2xl font-bold">{adminStats?.uniqueUsersTracked ?? 0}</div><div className="text-xs text-slate-500">Users with tracked activity</div></div></div>
                <div className="space-y-3">{['home','events','services','lostfound','cafeteria','finance'].map(category => { const count = adminStats?.usageByCategory?.[category] || 0; const max = Math.max(1, ...Object.values(adminStats?.usageByCategory || {})); return <div key={category}><div className="flex justify-between text-xs mb-1"><span className="capitalize">{category === 'lostfound' ? 'Lost & Found' : category}</span><strong>{count} visits</strong></div><div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-violet-500" style={{ width: (count / max * 100) + '%' }} /></div></div>; })}</div>
              </section>
              <section className="card p-4 space-y-4">
                <div>
                  <h3 className="font-semibold">App Reports</h3>
                  <p className="text-xs text-slate-500 mt-1">Usage recorded from signed-in app activity. Reports use the activity records currently available.</p>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(['daily', 'weekly', 'monthly'] as const).map(period => (
                    <button key={period} onClick={() => setReportPeriod(period)} className={cx('rounded-xl px-3 py-2 text-sm font-medium capitalize', reportPeriod === period ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600')}>
                      {period}
                    </button>
                  ))}
                </div>
                {(() => {
                  const buckets = adminStats?.usageReports?.[reportPeriod] || [];
                  const latest = buckets[0];
                  const maxVisits = Math.max(1, ...Object.values(latest?.byCategory || {}));
                  return (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="rounded-xl bg-slate-50 p-3"><div className="text-2xl font-bold">{latest?.visits ?? 0}</div><div className="text-xs text-slate-500">{reportPeriod} visits</div></div>
                        <div className="rounded-xl bg-slate-50 p-3"><div className="text-2xl font-bold">{latest?.uniqueUsers ?? 0}</div><div className="text-xs text-slate-500">Active users</div></div>
                      </div>
                      <div className="text-xs font-semibold text-slate-500">{latest ? 'Latest recorded ' + reportPeriod.slice(0, -2) + ' · ' + latest.key : 'No activity recorded for this period yet'}</div>
                      <div className="space-y-3">{['home','events','services','lostfound','cafeteria','finance'].map(category => { const count = latest?.byCategory?.[category] || 0; return <div key={category}><div className="flex justify-between text-xs mb-1"><span className="capitalize">{category === 'lostfound' ? 'Lost & Found' : category}</span><strong>{count} visits</strong></div><div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-violet-500" style={{ width: (count / maxVisits * 100) + '%' }} /></div></div>; })}</div>
                      <div className="border-t pt-3 space-y-2">
                        <div className="text-xs font-semibold text-slate-500">Recent {reportPeriod} activity</div>
                        {buckets.map(bucket => <div key={bucket.key} className="flex justify-between text-xs"><span className="text-slate-600">{bucket.key}</span><span className="font-semibold">{bucket.visits} visits · {bucket.uniqueUsers} users</span></div>)}
                        {buckets.length === 0 && <p className="text-xs text-slate-400">No recorded activity yet.</p>}
                      </div>
                    </div>
                  );
                })()}
              </section>
              <div className="card p-4">
                <h3 className="font-semibold text-sm mb-3">Recent users</h3>
                <div className="space-y-2">
                  {(adminStats?.recentUsers || []).map(u => (
                    <div
                      key={u.id}
                      className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0"
                    >
                      <div className="min-w-0">
                        <div className="font-medium text-sm truncate">
                          {u.name}
                        </div>
                        <div className="text-xs text-slate-400 truncate">
                          {u.email}
                          {(u as any).role === 'admin' ? ' · Admin' : ''}
                        </div>
                      </div>
                      <span
                        className={cx(
                          'badge shrink-0 ml-2',
                          u.isSignedIn
                            ? 'bg-slate-800 text-white'
                            : 'bg-slate-100 text-slate-500'
                        )}
                      >
                        {u.isSignedIn ? 'Signed in' : 'Offline'}
                      </span>
                    </div>
                  ))}
                  {(!adminStats?.recentUsers ||
                    adminStats.recentUsers.length === 0) && (
                    <p className="text-sm text-slate-400 text-center py-4">
                      No users yet
                    </p>
                  )}
                </div>
              </div>

              <p className="text-xs text-slate-400 text-center">Admin manages users, events, cafeteria menu and app analytics. Finance entry, event attendance and food ordering are student-only.</p>
            </div>
          )}

          {tab === 'events' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center gap-3"><h2 className="text-lg font-bold">Campus Events</h2>{user.role === 'admin' && <button onClick={() => { setShowForm('event'); setFormData({ category: 'Social', capacity: '100' }); }} className="btn-primary text-sm"><Plus size={15} className="inline mr-1" /> Publish event</button>}</div>
              {user.role === 'admin' && showForm === 'event' && <section className="card p-4 space-y-3"><h3 className="font-semibold">Publish a campus event</h3>
                <input placeholder="Event title" className="w-full border rounded-xl px-3 py-2 text-sm" value={formData.title || ''} onChange={e => setFormData(d => ({ ...d, title: e.target.value }))} />
                <select className="w-full border rounded-xl px-3 py-2 text-sm" value={formData.category || 'Social'} onChange={e => setFormData(d => ({ ...d, category: e.target.value }))}>{CATEGORIES.filter(c => c !== 'All').map(c => <option key={c}>{c}</option>)}</select>
                <textarea placeholder="Event description" className="w-full border rounded-xl px-3 py-2 text-sm" value={formData.description || ''} onChange={e => setFormData(d => ({ ...d, description: e.target.value }))} />
                <div className="grid grid-cols-2 gap-2"><input type="date" className="border rounded-xl px-3 py-2 text-sm" value={formData.date || ''} onChange={e => setFormData(d => ({ ...d, date: e.target.value }))} /><input type="time" className="border rounded-xl px-3 py-2 text-sm" value={formData.time || ''} onChange={e => setFormData(d => ({ ...d, time: e.target.value }))} /></div>
                <input placeholder="Location" className="w-full border rounded-xl px-3 py-2 text-sm" value={formData.location || ''} onChange={e => setFormData(d => ({ ...d, location: e.target.value }))} />
                <input type="number" min="1" placeholder="Capacity" className="w-full border rounded-xl px-3 py-2 text-sm" value={formData.capacity || ''} onChange={e => setFormData(d => ({ ...d, capacity: e.target.value }))} />
                <div className="flex gap-2"><button onClick={() => setShowForm(null)} className="btn-secondary flex-1">Cancel</button><button onClick={createEvent} disabled={submitting} className="btn-primary flex-1">Publish event</button></div>
              </section>}
              <div className="flex gap-2 overflow-x-auto pb-1">
                {CATEGORIES.map(c => (
                  <button
                    key={c}
                    onClick={() => setCategoryFilter(c)}
                    className={cx(
                      'px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition',
                      categoryFilter === c
                        ? 'bg-slate-800 text-white'
                        : 'bg-white text-slate-600 border border-slate-200'
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
              <div className="space-y-3">
                {filteredEvents.map(ev => (
                  <div key={ev.id} className="card p-4">
                    <span className="badge bg-slate-100 text-slate-700 mb-1">
                      {ev.category}
                    </span>
                    <h3 className="font-semibold">{ev.title}</h3>
                    <p className="text-sm text-slate-500 mt-1">
                      {ev.description}
                    </p>
                    <div className="flex flex-wrap gap-3 mt-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Calendar size={12} /> {ev.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={12} /> {ev.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin size={12} /> {ev.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users size={12} /> {ev.registered}/{ev.capacity}
                      </span>
                    </div>
                    {user.role === 'student' && <button onClick={() => registerForEvent(ev.id)} disabled={submitting || !!ev.isRegistered || ev.registered >= ev.capacity} className={cx('mt-3 w-full py-2 rounded-xl text-sm font-medium transition', ev.isRegistered ? 'bg-slate-100 text-slate-700' : 'btn-primary')}>{ev.isRegistered ? <span className="flex items-center justify-center gap-1"><CheckCircle2 size={16} /> Registered — see you there</span> : ev.registered >= ev.capacity ? 'Full' : 'Register to attend'}</button>}
                    {user.role === 'admin' && <p className="mt-3 text-xs text-slate-500">Admin view · {ev.registered} student registrations</p>}
                  </div>
                ))}
                {filteredEvents.length === 0 && (
                  <p className="text-center text-slate-400 py-8">
                    No events in this category
                  </p>
                )}
              </div>
            </div>
          )}

          {tab === 'services' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold">Campus Services</h2>
                  <p className="text-sm text-slate-500 mt-1">Academic and non-academic support across USIU-Africa</p>
                </div>
                {user.role === 'admin' && (
                  <button onClick={() => { setEditingServiceId(null); setFormData({ category: 'Academic' }); setServiceFileBase64(null); setServiceFileName(''); setServiceFileType(''); setShowForm('campus-service'); }} className="btn-primary text-sm flex items-center gap-1">
                    <Plus size={15} /> Add service
                  </button>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                {(['All', 'Academic', 'Non-Academic'] as const).map(filter => (
                  <button key={filter} onClick={() => setServiceFilter(filter)} className={cx('px-3 py-2 rounded-full text-xs font-semibold border', serviceFilter === filter ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-200')}>
                    {filter === 'All' ? 'All services' : filter + ' services'}
                  </button>
                ))}
              </div>

              {showForm === 'campus-service' && user.role === 'admin' && (
                <section className="card p-4 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-semibold">{editingServiceId ? 'Edit campus service' : 'Add campus service'}</h3>
                    <button onClick={() => { setShowForm(null); setEditingServiceId(null); setFormData({}); setServiceFileBase64(null); }} className="text-sm text-slate-500">Cancel</button>
                  </div>
                  <label className="block text-xs font-medium text-slate-600">Category</label>
                  <select value={formData.category || 'Academic'} onChange={e => setFormData(d => ({ ...d, category: e.target.value }))} className="finance-input w-full rounded-xl px-3 py-3 text-sm">
                    <option>Academic</option><option>Non-Academic</option>
                  </select>
                  <input value={formData.title || ''} onChange={e => setFormData(d => ({ ...d, title: e.target.value }))} placeholder="Service name" className="finance-input w-full rounded-xl px-3 py-3 text-sm" />
                  <textarea value={formData.description || ''} onChange={e => setFormData(d => ({ ...d, description: e.target.value }))} placeholder="Description and information" rows={3} className="finance-input w-full rounded-xl px-3 py-3 text-sm" />
                  <textarea value={formData.contact || ''} onChange={e => setFormData(d => ({ ...d, contact: e.target.value }))} placeholder="Phone, email, office or contact details" rows={3} className="finance-input w-full rounded-xl px-3 py-3 text-sm" />
                  <input value={formData.website || ''} onChange={e => setFormData(d => ({ ...d, website: e.target.value }))} placeholder="Website link (https://...)" className="finance-input w-full rounded-xl px-3 py-3 text-sm" />
                  <label className="block text-xs font-medium text-slate-600">Upload an image or document (optional, max 4 MB)</label>
                  <input type="file" accept="image/png,image/jpeg,image/webp,image/gif,application/pdf,.doc,.docx" onChange={e => onServiceFileSelected(e.target.files?.[0] || null)} className="w-full text-xs" />
                  {serviceFileName && <p className="text-xs text-emerald-700">Selected: {serviceFileName}</p>}
                  <button onClick={saveCampusService} disabled={submitting || !formData.title?.trim()} className="btn-primary w-full">{submitting ? 'Saving…' : editingServiceId ? 'Save changes' : 'Upload and publish service'}</button>
                </section>
              )}

              {(['Academic', 'Non-Academic'] as const).filter(category => serviceFilter === 'All' || serviceFilter === category).map(category => {
                const entries = campusServices.filter(service => service.category === category);
                return (
                  <section key={category} className="space-y-3">
                    <div className="flex items-center justify-between"><h3 className="font-bold text-base">{category} Services</h3><span className="text-xs text-slate-400">{entries.length} listed</span></div>
                    {entries.map(service => (
                      <article key={service.id} className="card p-4 space-y-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <span className="text-[10px] uppercase tracking-wide text-cyan-700 font-semibold">{service.category}</span>
                            <h4 className="font-semibold mt-1">{service.title}</h4>
                          </div>
                          {user.role === 'admin' && <div className="flex shrink-0 gap-2"><button onClick={() => startEditService(service)} className="text-xs text-cyan-700 flex items-center gap-1"><Pencil size={13}/> Edit</button><button onClick={() => deleteCampusService(service.id)} disabled={submitting} className="text-xs text-rose-600 flex items-center gap-1"><Trash2 size={13}/> Delete</button></div>}
                        </div>
                        {service.description && <p className="text-sm text-slate-600 whitespace-pre-line">{service.description}</p>}
                        {service.contact && <div className="rounded-xl bg-slate-50 p-3 text-xs text-slate-600 whitespace-pre-line">{service.contact}</div>}
                        {service.website && (
                          <a
                            href={service.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block rounded-xl border border-cyan-100 bg-cyan-50/60 p-3 text-left hover:bg-cyan-50"
                            aria-label={`Open official website for ${service.title}`}
                          >
                            <span className="flex items-center gap-1 text-xs font-semibold text-cyan-800">
                              Open official website <ExternalLink size={12}/>
                            </span>
                            <span className="mt-1 block break-all text-xs text-cyan-700 underline underline-offset-2">
                              {service.website}
                            </span>
                          </a>
                        )}
                        {service.attachmentUrl && <a href={service.attachmentUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-xs font-semibold text-violet-700"><FileText size={15}/> {service.attachmentName || 'View uploaded attachment'} <ExternalLink size={12}/></a>}
                      </article>
                    ))}
                    {entries.length === 0 && <p className="card p-4 text-sm text-slate-400">No services in this section yet.</p>}
                  </section>
                );
              })}
            </div>
          )}

          {tab === 'lostfound' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold">Lost & Found</h2>
                <button
                  onClick={() => {
                    setShowForm('lf');
                    setFormData({ type: 'lost' });
                  }}
                  className="btn-primary text-sm flex items-center gap-1"
                >
                  <Plus size={16} /> Report
                </button>
              </div>
              <div className="flex gap-2">
                {(['all', 'lost', 'found'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setLfFilter(f)}
                    className={cx(
                      'px-3 py-1.5 rounded-full text-xs font-medium capitalize',
                      lfFilter === f
                        ? 'bg-slate-800 text-white'
                        : 'bg-white border border-slate-200 text-slate-600'
                    )}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {showForm === 'lf' && (
                <div className="card p-4 space-y-3 border-2 border-slate-200">
                  <div className="flex gap-2">
                    <button
                      onClick={() =>
                        setFormData(d => ({ ...d, type: 'lost' }))
                      }
                      className={cx(
                        'flex-1 py-2 rounded-xl text-sm font-medium',
                        formData.type === 'lost'
                          ? 'bg-slate-800 text-white'
                          : 'bg-slate-100'
                      )}
                    >
                      Lost
                    </button>
                    <button
                      onClick={() =>
                        setFormData(d => ({ ...d, type: 'found' }))
                      }
                      className={cx(
                        'flex-1 py-2 rounded-xl text-sm font-medium',
                        formData.type === 'found'
                          ? 'bg-slate-800 text-white'
                          : 'bg-slate-100'
                      )}
                    >
                      Found
                    </button>
                  </div>
                  <input
                    placeholder="Item title (e.g. Black backpack)"
                    className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
                    value={formData.title || ''}
                    onChange={e =>
                      setFormData(d => ({ ...d, title: e.target.value }))
                    }
                  />
                  <textarea
                    placeholder="Description"
                    className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
                    rows={2}
                    value={formData.description || ''}
                    onChange={e =>
                      setFormData(d => ({
                        ...d,
                        description: e.target.value,
                      }))
                    }
                  />
                  <input
                    placeholder="Location found / lost"
                    className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
                    value={formData.location || ''}
                    onChange={e =>
                      setFormData(d => ({ ...d, location: e.target.value }))
                    }
                  />
                  <input
                    placeholder="Contact info"
                    className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
                    value={formData.contact || ''}
                    onChange={e =>
                      setFormData(d => ({ ...d, contact: e.target.value }))
                    }
                  />
                  <div>
                    <label className="text-xs text-slate-500 mb-1 block">
                      Photo (optional, max 2.5 MB)
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      className="w-full text-sm text-slate-600 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:bg-slate-100 file:text-slate-700"
                      onChange={e =>
                        onPhotoSelected(e.target.files?.[0] || null)
                      }
                    />
                    {photoPreview && (
                      <img
                        src={photoPreview}
                        alt="Preview"
                        className="mt-2 w-full max-h-40 object-cover rounded-xl border border-slate-200"
                      />
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setShowForm(null);
                        setPhotoPreview(null);
                        setPhotoBase64(null);
                      }}
                      className="btn-secondary flex-1"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={submitLostFound}
                      disabled={submitting}
                      className="btn-primary flex-1"
                    >
                      {submitting ? 'Saving…' : 'Submit'}
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {filteredLf.map(item => (
                  <div key={item.id} className="card p-4">
                    {item.photoUrl && (
                      <img
                        src={item.photoUrl}
                        alt={item.title}
                        className="w-full h-40 object-cover rounded-xl mb-3 border border-slate-100"
                      />
                    )}
                    <div className="flex items-start justify-between">
                      <span
                        className={cx(
                          'badge',
                          item.type === 'lost'
                            ? 'bg-slate-200 text-slate-800'
                            : 'bg-slate-100 text-slate-600'
                        )}
                      >
                        {item.type.toUpperCase()}
                      </span>
                      <span
                        className={cx(
                          'badge',
                          item.status === 'open'
                            ? 'bg-amber-50 text-amber-700'
                            : 'bg-slate-100 text-slate-500'
                        )}
                      >
                        {item.status}
                      </span>
                    </div>
                    <h3 className="font-semibold mt-2">{item.title}</h3>
                    <p className="text-sm text-slate-500 mt-1">
                      {item.description}
                    </p>
                    <div className="flex gap-3 mt-2 text-xs text-slate-400"><span className="flex items-center gap-1"><MapPin size={11} /> {item.location}</span><span>{item.date}</span></div>
                    <button onClick={() => setSelectedLostFound(item)} className="mt-3 text-sm font-semibold text-cyan-700">View item details <ChevronRight size={14} className="inline" /></button>
                  </div>
                ))}
                {filteredLf.length === 0 && (
                  <p className="text-center text-slate-400 py-8">
                    No items found
                  </p>
                )}
              </div>
            </div>
          )}

          {selectedLostFound && <div className="fixed inset-0 z-50 bg-black/60 p-4 flex items-center justify-center" onClick={() => setSelectedLostFound(null)}>
            <section className="bg-white rounded-2xl w-full max-w-md max-h-[85vh] overflow-y-auto p-5 space-y-3" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between"><h3 className="font-bold text-lg">Reported item details</h3><button onClick={() => setSelectedLostFound(null)} aria-label="Close details"><X size={20} /></button></div>
              {selectedLostFound.photoUrl && <img src={selectedLostFound.photoUrl} alt={selectedLostFound.title} className="w-full max-h-56 object-cover rounded-xl" />}
              <div className="flex gap-2"><span className="badge bg-slate-100 text-slate-700">{selectedLostFound.type.toUpperCase()}</span><span className="badge bg-amber-50 text-amber-700">{selectedLostFound.status}</span></div>
              <h4 className="font-semibold">{selectedLostFound.title}</h4><p className="text-sm text-slate-600 whitespace-pre-wrap">{selectedLostFound.description}</p>
              <div className="text-sm space-y-2 border-t pt-3"><p><strong>Location:</strong> {selectedLostFound.location}</p><p><strong>Date reported:</strong> {selectedLostFound.date}</p><p><strong>Contact:</strong> {selectedLostFound.contact || 'Not provided'}</p></div>
              <button onClick={() => setSelectedLostFound(null)} className="btn-primary w-full">Close</button>
            </section></div>}

          {tab === 'cafeteria' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Cafeteria</h2>

              <div className="card p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-slate-500 font-medium">
                      Live Queue
                    </div>
                    <div className="text-3xl font-bold text-slate-800 mt-1">
                      {queue.length} people
                    </div>
                    <div className="text-xs text-slate-500">
                      ~{queue.estimatedWait} min wait
                    </div>
                  </div>
                  {user.role === 'student' && <button onClick={joinQueue} disabled={submitting} className="btn-primary text-sm">Join Virtual Queue</button>}
                  {user.role === 'admin' && <span className="text-xs text-slate-400">Admin · view only</span>}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Menu</h3>
                {user.role === 'student' && <button onClick={() => setShowForm('order')} disabled={selectedItems.length === 0} className={cx('text-sm font-medium px-3 py-1.5 rounded-xl', selectedItems.length > 0 ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-400')}>Order ({selectedItems.length})</button>}
              </div>

              <div className="space-y-2">
                {user?.role === 'admin' && (
                <div className="card p-4 space-y-3 border border-slate-200">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-sm">Manage menu (Admin)</h3>
                    <button
                      onClick={() => {
                        setEditingMenuId(null);
                        setShowForm('menu');
                        setFormData({ category: 'Mains' });
                      }}
                      className="btn-primary text-xs flex items-center gap-1 py-1.5"
                    >
                      <Plus size={14} /> Add item
                    </button>
                  </div>
                  {showForm === 'menu' && (
                    <div className="space-y-2 pt-2 border-t border-slate-100">
                      <input
                        placeholder="Item name"
                        className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm"
                        value={formData.name || ''}
                        onChange={e =>
                          setFormData(d => ({ ...d, name: e.target.value }))
                        }
                      />
                      <input
                        type="number"
                        placeholder="Price (Ksh)"
                        className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm"
                        value={formData.price || ''}
                        onChange={e =>
                          setFormData(d => ({ ...d, price: e.target.value }))
                        }
                      />
                      <input
                        placeholder="Description"
                        className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm"
                        value={formData.description || ''}
                        onChange={e =>
                          setFormData(d => ({
                            ...d,
                            description: e.target.value,
                          }))
                        }
                      />
                      <select
                        className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm"
                        value={formData.category || 'Mains'}
                        onChange={e =>
                          setFormData(d => ({
                            ...d,
                            category: e.target.value,
                          }))
                        }
                      >
                        <option>Mains</option>
                        <option>Salads</option>
                        <option>Drinks</option>
                        <option>Snacks</option>
                      </select>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setShowForm(null)}
                          className="btn-secondary flex-1 text-sm"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={addMenuItem}
                          disabled={submitting}
                          className="btn-primary flex-1 text-sm"
                        >
                          {submitting ? 'Saving…' : 'Save item'}
                        </button>
                      </div>
                    </div>
                  )}
                  <div className="space-y-1">
                    {menu.map(item => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between text-sm py-1.5 border-b border-slate-50 last:border-0"
                      >
                        <div>
                          <span className="font-medium">{item.name}</span>
                          <span className="text-slate-400 ml-2">
                            {formatKsh(item.price)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2"><button onClick={() => { setEditingMenuId(item.id); setFormData({ name: item.name, price: String(item.price), category: item.category, description: item.description }); setShowForm('menu'); }} className="text-cyan-700 text-xs font-medium">Edit</button><button onClick={() => deleteMenuItem(item.id)} className="text-slate-400 hover:text-red-600 p-1" title="Remove"><Trash2 size={14} /></button></div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

                {menu.map(item => {
                  const selected = selectedItems.includes(item.id);
                  return (
                    <button key={item.id} disabled={user.role === 'admin'} onClick={() => { if (user.role !== 'student') return; setSelectedItems(prev => selected ? prev.filter(id => id !== item.id) : [...prev, item.id]); }} className={cx('w-full card p-3 text-left flex items-center gap-3 transition', selected && 'ring-2 ring-slate-400 bg-slate-50', user.role === 'admin' && 'cursor-default')}>
                      <div className="flex-1">
                        <div className="font-medium text-sm">{item.name}</div>
                        <div className="text-xs text-slate-500">
                          {item.description}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-sm">
                          {formatKsh(item.price)}
                        </div>
                        <div className="text-xs text-slate-400">
                          {item.category}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {user.role === 'student' && showForm === 'order' && (
                <div className="fixed inset-0 bg-black/40 z-40 flex items-end">
                  <div className="bg-white rounded-t-3xl w-full max-w-lg mx-auto p-5 space-y-4">
                    <h3 className="font-bold text-lg">Confirm Pre-Order</h3>
                    <div className="space-y-1 text-sm">
                      {menu.filter(m => selectedItems.includes(m.id)).map(
                        m => (
                          <div key={m.id} className="flex justify-between">
                            <span>{m.name}</span>
                            <span>{formatKsh(m.price)}</span>
                          </div>
                        )
                      )}
                      <div className="border-t pt-2 font-semibold flex justify-between">
                        <span>Total</span>
                        <span>
                          {formatKsh(
                            menu.filter(m =>
                              selectedItems.includes(m.id)
                            ).reduce((s, i) => s + i.price, 0)
                          )}
                        </span>
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-slate-500">
                        Pickup time
                      </label>
                      <input
                        type="time"
                        value={pickupTime}
                        onChange={e => setPickupTime(e.target.value)}
                        className="w-full border border-slate-200 rounded-xl px-3 py-2.5 mt-1"
                      />
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowForm(null)}
                        className="btn-secondary flex-1"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={placeOrder}
                        disabled={submitting}
                        className="btn-primary flex-1"
                      >
                        {submitting ? 'Placing…' : 'Place Order'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {user.role === 'student' && orders.length > 0 && (
                <div className="card p-4">
                  <h3 className="font-semibold text-sm mb-3">
                    Your Recent Orders
                  </h3>
                  {orders.slice(0, 5).map(o => (
                    <div
                      key={o.id}
                      className="py-2 border-b border-slate-50 last:border-0 text-sm"
                    >
                      <div className="flex justify-between">
                        <span className="font-medium">
                          {o.items.join(', ')}
                        </span>
                        <span className="badge bg-slate-100 text-slate-700">
                          {o.status}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Pickup {o.pickupTime} · {formatKsh(o.total)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {user.role === 'student' && tab === 'finance' && (
            <div className="space-y-5 finance-dashboard">
              <div className="finance-header flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-[0.22em] text-cyan-300 font-semibold">Money overview</p>
                  <h2 className="text-2xl font-bold mt-1">Finance analytics</h2>
                  <p className="text-sm text-slate-400 mt-1">Your spending, budget and financial trends</p>
                </div>

              </div>

              {showForm === 'expense' && <section className="finance-entry-form finance-panel p-4 sm:p-5 space-y-3">
                <div className="flex justify-between items-center"><h3 className="font-semibold">{editingExpenseId ? 'Edit daily expense' : 'Record a daily expense'}</h3><button onClick={() => { setShowForm(null); setEditingExpenseId(null); }} className="text-xs text-slate-400">Close</button></div>
                <input type="number" min="0" placeholder="Amount (Ksh)" className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.amount || ''} onChange={e => setFormData(d => ({ ...d, amount: e.target.value }))} />
                <label className="text-xs text-slate-400">Date of expense (past dates are allowed)</label><input type="date" className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.date || selectedCalendarDate || new Date().toISOString().slice(0,10)} onChange={e => setFormData(d => ({ ...d, date: e.target.value }))} />
                <select className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.category || 'General'} onChange={e => setFormData(d => ({ ...d, category: e.target.value }))}>{EXPENSE_CATEGORIES.map(c => <option key={c}>{c}</option>)}<option value="Custom">Add my own category…</option></select>
                {formData.category === 'Custom' && <input placeholder="Enter your category" className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.customCategory || ''} onChange={e => setFormData(d => ({ ...d, customCategory: e.target.value }))} />}
                <div className="flex gap-2"><button onClick={() => { setShowForm(null); setEditingExpenseId(null); }} className="btn-secondary flex-1">Cancel</button><button onClick={addExpense} disabled={submitting || (formData.category === 'Custom' && !formData.customCategory?.trim())} className="btn-primary flex-1">{submitting ? 'Saving…' : editingExpenseId ? 'Update expense' : 'Save daily expense'}</button></div>
              </section>}

              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
                <div className="finance-stat-card">
                  <div className="flex items-center justify-between text-slate-400 text-xs"><span>Spent this month</span><Wallet size={17} className="text-cyan-300" /></div>
                  <div className="text-2xl font-bold mt-3">{formatKsh(totalSpent)}</div>
                  <div className="text-xs text-cyan-300 mt-2">Current month expenses</div>
                </div>
                <div className="finance-stat-card">
                  <div className="flex items-center justify-between text-slate-400 text-xs"><span>Remaining budget</span><BarChart3 size={17} className="text-violet-300" /></div>
                  <div className={cx('text-2xl font-bold mt-3', remaining < 0 && 'text-rose-300')}>{formatKsh(remaining)}</div>
                  <div className="text-xs text-slate-400 mt-2">{monthlyBudget > 0 ? budgetPct + '% of budget used' : 'Set a monthly budget below'}</div>
                </div>
                <div className="finance-stat-card">
                  <div className="flex items-center justify-between text-slate-400 text-xs"><span>Top spending area</span><Wallet size={17} className="text-fuchsia-300" /></div>
                  <div className="text-2xl font-bold mt-3 truncate">{topCategory ? topCategory[0] : '—'}</div>
                  <div className="text-xs text-slate-400 mt-2">{topCategory ? formatKsh(topCategory[1]) + ' this month' : 'Add expenses to see insights'}</div>
                </div>
                <div className="finance-stat-card">
                  <div className="flex items-center justify-between text-slate-400 text-xs"><span>Next 25-day estimate</span><BarChart3 size={17} className="text-emerald-300" /></div>
                  <div className="text-2xl font-bold mt-3">{formatKsh(projectedNext25Days)}</div>
                  <div className="text-xs text-slate-400 mt-2">Estimate using the latest 7-day average</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                <section className="finance-panel lg:col-span-3 p-4 sm:p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div><h3 className="font-semibold">Expenditure curve</h3><p className="text-xs text-slate-400 mt-1">Choose how many days of daily spending to display</p></div>
                    <div className="flex flex-wrap items-center gap-2">
                      {financeView === '25days' && (
                        <label className="flex items-center gap-2 text-xs text-slate-300">
                          <span>Days</span>
                          <select value={curveDays} onChange={e => setCurveDays(Number(e.target.value))} className="finance-chip bg-slate-900 border border-slate-700 rounded-lg px-3 py-2" aria-label="Choose expenditure curve date range">
                            {[7, 14, 25, 30, 60, 90, 180].map(days => <option key={days} value={days}>{days} days</option>)}
                          </select>
                        </label>
                      )}
                      <div className="flex gap-1 rounded-xl bg-slate-900/70 p-1">
                        <button onClick={() => setFinanceView('25days')} className={cx('finance-chip', financeView === '25days' && 'bg-cyan-400/20 text-cyan-200')}>Daily curve</button>
                        <button onClick={() => setFinanceView('6months')} className={cx('finance-chip', financeView === '6months' && 'bg-cyan-400/20 text-cyan-200')}>6 months</button>
                      </div>
                    </div>
                  </div>
                  {financeView === '25days' ? (
                    hasCurveData ? (
                      <div className="mt-5">
                        <svg viewBox="0 0 800 230" className="w-full h-auto" role="img" aria-label={'Daily expenditure over the latest ' + curveDays + ' days'}>
                          {[35, 85, 135, 185].map(y => <line key={y} x1="38" x2="760" y1={y} y2={y} stroke="rgba(148,163,184,.16)" strokeDasharray="4 6" />)}
                          <defs><linearGradient id="dailySpendArea" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#22d3ee" stopOpacity=".34" /><stop offset="100%" stopColor="#22d3ee" stopOpacity="0" /></linearGradient></defs>
                          <polygon points={'38,185 ' + curvePoints + ' 760,185'} fill="url(#dailySpendArea)" />
                          <polyline points={curvePoints} fill="none" stroke="#22d3ee" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                          {curveSpend.map((day, index) => {
                            const x = 38 + index * (722 / Math.max(curveDays - 1, 1));
                            const y = 185 - (day.amount / curveMax) * 145;
                            const labelEvery = Math.max(1, Math.ceil(curveDays / 7));
                            return <g key={day.key}><circle cx={x} cy={y} r="3.5" fill="#a78bfa" stroke="#e0e7ff" strokeWidth="1.5" />{(index % labelEvery === 0 || index === curveDays - 1) && <text x={x} y="215" textAnchor="middle" fill="#94a3b8" fontSize="10">{day.shortLabel}</text>}</g>;
                          })}
                        </svg>
                        <div className="flex flex-wrap justify-between gap-2 text-xs text-slate-400 mt-1"><span>{curveDays}-day recorded total: {formatKsh(curveTotal)}</span><span>Peak day: {formatKsh(curveMax)}</span></div>
                      </div>
                    ) : <div className="finance-empty mt-5">No expenses recorded in the latest {curveDays} days yet. Add daily entries to build your spending trend.</div>
                  ) : (
                    hasTrendData ? (
                      <div className="mt-5">
                        <svg viewBox="0 0 600 230" className="w-full h-auto" role="img" aria-label="Monthly expenditure trend chart">
                          {[35, 85, 135, 185].map(y => <line key={y} x1="38" x2="580" y1={y} y2={y} stroke="rgba(148,163,184,.16)" strokeDasharray="4 6" />)}
                          <defs><linearGradient id="spendArea" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#22d3ee" stopOpacity=".34" /><stop offset="100%" stopColor="#22d3ee" stopOpacity="0" /></linearGradient></defs>
                          <polygon points={'38,185 ' + trendPoints + ' 580,185'} fill="url(#spendArea)" />
                          <polyline points={trendPoints} fill="none" stroke="#22d3ee" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                          {monthlySpend.map((m, i) => {
                            const x = 38 + i * (542 / 5);
                            const y = 185 - (m.amount / trendMax) * 150;
                            return <g key={m.key}><circle cx={x} cy={y} r="5" fill="#a78bfa" stroke="#e0e7ff" strokeWidth="2" /><text x={x} y="215" textAnchor="middle" fill="#94a3b8" fontSize="12">{m.label}</text></g>;
                          })}
                        </svg>
                        <div className="flex justify-between text-xs text-slate-400 mt-1"><span>Highest month: {formatKsh(trendMax)}</span><span>Based on recorded expenses</span></div>
                      </div>
                    ) : <div className="finance-empty mt-5">Add expenses to build your historical spending trend.</div>
                  )}
                </section>

                <section className="finance-panel lg:col-span-2 p-4 sm:p-5">
                  <h3 className="font-semibold">Where your money goes</h3>
                  <p className="text-xs text-slate-400 mt-1">Category breakdown for this month</p>
                  {Object.keys(byCategory).length ? (
                    <div className="space-y-4 mt-5">
                      {Object.entries(byCategory).sort((a, b) => b[1] - a[1]).map(([cat, amt], i) => (
                        <div key={cat}>
                          <div className="flex justify-between text-xs mb-2"><span className="text-slate-300">{cat}</span><span className="font-semibold">{formatKsh(amt)}</span></div>
                          <div className="h-2.5 rounded-full bg-slate-800 overflow-hidden"><div className="h-full rounded-full" style={{ width: ((amt / Math.max(totalSpent, 1)) * 100) + '%', background: ['#22d3ee', '#8b5cf6', '#ec4899', '#38bdf8', '#a3e635', '#f59e0b'][i % 6] }} /></div>
                        </div>
                      ))}
                    </div>
                  ) : <div className="finance-empty mt-5">Category insights will appear after your first expense.</div>}
                </section>
              </div>

              <section className="finance-panel p-4 sm:p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div><h3 className="font-semibold">Weekly spending summary</h3><p className="text-xs text-slate-400 mt-1">Four weekly checkpoints across the 25-day tracking window</p></div>
                  <span className="finance-chip">{formatKsh(dailyTotal)} total</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 mt-4">
                  {weeklySpend.map(week => (
                    <div key={week.label} className="rounded-xl border border-slate-700/70 bg-slate-900/45 p-3">
                      <div className="text-xs text-slate-400">{week.label}</div>
                      <div className="text-lg font-semibold mt-1">{formatKsh(week.amount)}</div>
                      <div className="text-[11px] text-slate-500 mt-1">{week.range}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2"><div className="font-medium text-sm">Projected spend for the next 25 days</div><div className="text-lg font-bold text-emerald-200">{formatKsh(projectedNext25Days)}</div></div>
                  <p className="text-xs text-slate-400 mt-1">Estimate only: latest 7-day recorded spending divided by 7, multiplied by 25. It updates as new expenses are entered.</p>
                </div>
              </section>

              <section className="finance-panel p-4 sm:p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div><h3 className="font-semibold">Monthly budget</h3><p className="text-xs text-slate-400 mt-1">Set a target and track how much is left</p></div>
                  <span className="finance-chip">{budgetPct}% used</span>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 mt-4">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">Ksh</span>
                    <input type="number" min={0} value={budgetInput} onChange={e => setBudgetInput(e.target.value)} placeholder="Enter monthly budget" className="finance-input w-full rounded-xl pl-12 pr-3 py-3 text-sm" />
                  </div>
                  <button onClick={saveBudget} disabled={submitting} className="btn-primary text-sm px-5">{submitting ? 'Saving…' : 'Save budget'}</button>
                </div>
                {monthlyBudget > 0 && <div className="mt-4">
                  <div className="flex justify-between text-xs text-slate-400 mb-2"><span>{formatKsh(totalSpent)} spent</span><span>{formatKsh(Math.max(remaining, 0))} remaining</span></div>
                  <div className="h-3 rounded-full bg-slate-800 overflow-hidden"><div className={cx('h-full rounded-full transition-all', budgetPct > 90 ? 'bg-rose-400' : 'bg-gradient-to-r from-cyan-400 to-violet-500')} style={{ width: budgetPct + '%' }} /></div>
                </div>}
              </section>



              <section className="finance-panel p-4 sm:p-5 space-y-3">
                <div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold">Monthly fixed expenses</h3><p className="text-xs text-slate-400 mt-1">Rent, subscriptions, Wi-Fi and other monthly commitments</p></div><button onClick={() => { setShowForm('monthly-expense'); setFormData({ category: 'Housing' }); }} className="btn-primary text-xs whitespace-nowrap"><Plus size={14} className="inline mr-1" /> Add monthly cost</button></div>
                {showForm === 'monthly-expense' && <div className="rounded-xl border border-slate-700 p-3 space-y-2"><input placeholder="e.g. Rent or subscription" className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.title || ''} onChange={e => setFormData(d => ({ ...d, title: e.target.value }))} /><input type="number" min="0" placeholder="Monthly amount (Ksh)" className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.amount || ''} onChange={e => setFormData(d => ({ ...d, amount: e.target.value }))} /><select className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.category || 'Housing'} onChange={e => setFormData(d => ({ ...d, category: e.target.value }))}>{EXPENSE_CATEGORIES.map(c => <option key={c}>{c}</option>)}<option value="Custom">Add my own category…</option></select>{formData.category === 'Custom' && <input placeholder="Enter your category" className="finance-input w-full rounded-xl px-3 py-3 text-sm" value={formData.customCategory || ''} onChange={e => setFormData(d => ({ ...d, customCategory: e.target.value }))} />}<div className="flex gap-2"><button onClick={() => setShowForm(null)} className="btn-secondary flex-1">Cancel</button><button onClick={addMonthlyExpense} disabled={submitting || (formData.category === 'Custom' && !formData.customCategory?.trim())} className="btn-primary flex-1">Save monthly cost</button></div></div>}
                <div className="space-y-2">{monthlyExpenses.map(item => <div key={item.id} className="transaction-row flex items-center justify-between gap-3 p-3 rounded-xl"><div className="min-w-0"><div className="font-medium text-sm">{item.title}</div><div className="text-xs text-slate-400 mt-1">{item.category} · Recurs monthly</div></div><div className="flex items-center gap-3"><strong className="text-sm">{formatKsh(item.amount)}</strong><button onClick={() => deleteMonthlyExpense(item.id)} className="text-rose-300 text-xs">Remove</button></div></div>)}{monthlyExpenses.length === 0 && <p className="finance-empty">No monthly fixed costs added yet.</p>}</div>
                <div className="flex justify-between border-t border-slate-700 pt-3 text-sm"><span className="text-slate-400">Monthly fixed costs</span><strong>{formatKsh(monthlyFixedTotal)}</strong></div>
              </section>

              <section className="finance-calendar finance-panel p-4 sm:p-5 space-y-4">
                <div className="flex flex-wrap justify-between items-center gap-2"><div><h3 className="font-semibold">Expense calendar</h3><p className="text-xs text-slate-400 mt-1">Choose any past or current date to review, add or adjust its spending</p></div><button onClick={() => { setEditingExpenseId(null); setFormData({ category: 'General', date: selectedCalendarDate }); setShowForm('expense'); }} className="btn-primary text-xs"><Plus size={14} className="inline mr-1" /> Add expense for this date</button><span className="finance-chip">{expenses.length} daily records</span></div>
                <div className="flex items-center justify-between gap-3"><button onClick={() => setCalendarMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() - 1, 1))} className="btn-secondary px-3 py-2" aria-label="Previous month">‹</button><h4 className="font-semibold">{calendarMonth.toLocaleDateString('en-KE', { month: 'long', year: 'numeric' })}</h4><button onClick={() => setCalendarMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 1))} className="btn-secondary px-3 py-2" aria-label="Next month">›</button></div>
                <div className="grid grid-cols-7 gap-1 text-center text-[11px] text-slate-400">{['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(day => <div key={day} className="py-1">{day}</div>)}</div>
                <div className="grid grid-cols-7 gap-1">{calendarDays.map(day => <button key={day.key} onClick={() => setSelectedCalendarDate(day.key)} className={cx('min-h-[62px] rounded-xl border p-1 flex flex-col items-center justify-start gap-1', day.inMonth ? 'border-slate-700 text-slate-100' : 'border-transparent text-slate-600', selectedCalendarDate === day.key && 'ring-2 ring-cyan-400 bg-cyan-950/40')}><span className="text-xs">{day.date.getDate()}</span>{day.count > 0 && <><span className="h-1.5 w-1.5 rounded-full bg-cyan-400" /><span className="text-[9px] leading-tight text-cyan-200">{formatKsh(day.amount)}</span></>}</button>)}</div>
                <div className="rounded-xl border border-slate-700 p-3 space-y-3"><div className="flex flex-wrap justify-between items-center gap-2"><div><h4 className="font-semibold text-sm">{new Date(selectedCalendarDate + 'T12:00:00').toLocaleDateString('en-KE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</h4><p className="text-xs text-slate-400">{selectedDayExpenses.length} expense records</p></div><strong className="text-cyan-200">{formatKsh(selectedDayTotal)}</strong></div>
                  {selectedDayExpenses.map(ex => <div key={ex.id} className="transaction-row flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl"><div className="min-w-0 flex-1"><div className="font-medium text-sm">{ex.category}</div><div className="text-xs text-slate-400 mt-1">{formatKsh(ex.amount)}</div></div><div className="flex gap-2"><button onClick={() => startEditExpense(ex)} className="text-xs text-cyan-300 flex items-center gap-1"><Pencil size={13}/> Edit</button><button onClick={() => deleteExpense(ex.id)} disabled={submitting} className="text-xs text-rose-300 flex items-center gap-1"><Trash2 size={13}/> Remove</button></div></div>)}
                  {selectedDayExpenses.length === 0 && <p className="finance-empty">No daily expenses recorded for this date. Select another day or add an expense for this date.</p>}
                </div>
                <button onClick={() => { const todayKey = new Date().toISOString().slice(0, 10); setSelectedCalendarDate(todayKey); setCalendarMonth(new Date(new Date().getFullYear(), new Date().getMonth(), 1)); }} className="text-xs text-cyan-300">Jump to today</button>
              </section>
            </div>
          )}
        </main>
      )}

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30">
        <div className="max-w-lg mx-auto flex justify-around py-2">
          {[
            { id: 'home' as const, icon: Home, label: 'Home' },
            { id: 'chatbot' as const, icon: MessageCircle, label: 'Chat' },
            { id: 'events' as const, icon: Calendar, label: 'Events' },
            { id: 'services' as const, icon: Building2, label: 'Services' },
            { id: 'lostfound' as const, icon: Search, label: 'Lost' },
            { id: 'cafeteria' as const, icon: Utensils, label: 'Cafeteria' },
            ...(user.role === 'student' ? [{ id: 'finance' as const, icon: Wallet, label: 'Finance' }] : []),
          ].map(item => {
            const active = tab === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setTab(item.id)}
                className={cx(
                  'flex flex-col items-center gap-0.5 px-2 py-1 min-w-[52px]',
                  active ? 'text-slate-900' : 'text-slate-400'
                )}
              >
                <Icon size={20} strokeWidth={active ? 2.5 : 2} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {tab !== 'chatbot' && (
        <button
          type="button"
          className="chatbot-launcher"
          onClick={() => setTab('chatbot')}
          aria-label="Open USIU Campus Chatbot"
          title="Ask the USIU Campus Chatbot"
        >
          <MessageCircle size={24} strokeWidth={2.2} />
          <span className="chatbot-launcher__ping" aria-hidden="true" />
          <span className="chatbot-launcher__label">Ask campus</span>
        </button>
      )}
    </div>
  );
}
