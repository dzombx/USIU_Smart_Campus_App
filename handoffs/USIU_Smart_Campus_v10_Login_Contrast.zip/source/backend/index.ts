import { router, json, error, db, storage, secrets } from '@appdeploy/sdk';
import {
  notifySubscribers,
  realtimeSubscriptionRoutes,
} from './realtime-subscribers';
import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'crypto';

const EVENTS_TABLE = 'events';
const LOSTFOUND_TABLE = 'lostfound';
const ORDERS_TABLE = 'orders';
const EXPENSES_TABLE = 'expenses';
const QUEUE_TABLE = 'queue_state';
const USERS_TABLE = 'users';
const SESSIONS_TABLE = 'sessions';
// Sessions created before this rollout must sign in again.
const SESSION_VALID_AFTER = 1794255020306;
const BUDGETS_TABLE = 'budgets';
const REGISTRATIONS_TABLE = 'event_registrations';
const MENU_TABLE = 'menu_items';
const RECURRING_EXPENSES_TABLE = 'recurring_expenses';
const USAGE_TABLE = 'usage_events';
const CAMPUS_SERVICES_TABLE = 'campus_services';

const CAMPUS_SERVICE_SEED = [
  { category: 'Academic', title: 'Admissions Office', description: 'Guidance on applying to USIU-Africa and admission enquiries.', contact: 'Tel: +254 730 116 247 / 300 / 397 / 503 / 522\nEmail: admit@usiu.ac.ke\nWhatsApp: +254 755 844 849' },
  { category: 'Academic', title: 'Library', description: 'Library services and learning resources.', contact: 'Tel: +257 730 116 429 / 254 / 549 / 294\nWhatsApp: 0782 620 858' },
  { category: 'Academic', title: 'Registrar', description: 'Academic records and official registrar enquiries.', contact: 'Tel: +257 730 116 786\nEmail: registrar@usiu.ac.ke' },
  { category: 'Academic', title: 'Placement and Careers', description: 'CV reviews, internships, career counselling, career fairs and professional networking.', contact: 'Tel: 0730 116 778 / 779 / 796\nEmail: careeroffice@usiu.ac.ke' },
  { category: 'Academic', title: 'Chandaria School of Business', description: 'Business education with practical skills and a global mindset.', contact: 'Email: admissions@usiu.ac.ke\nPhone: +254 730 116 000', website: 'https://csob.usiu.ac.ke/our-faculty/' },
  { category: 'Academic', title: 'School of Science and Technology', description: 'Computing, data science, pharmacy, nursing and related fields.', contact: 'Email: sst@usiu.ac.ke\nDean: Prof. Gabriel Okello — gokello@usiu.ac.ke\nPhone: +254 730 116 000 / 290 / 291', website: 'https://sst.usiu.ac.ke/our-faculty/' },
  { category: 'Academic', title: 'School of Humanities and Social Sciences', description: 'Languages, social sciences, arts, critical thinking and cultural understanding.', contact: 'Email: admit@usiu.ac.ke\nDean: Shital M. Maru, PhD — smaru@usiu.ac.ke\nPhone: +254 730 116 000 / 290 / 291', website: 'https://shss.usiu.ac.ke/our-faculty/' },
  { category: 'Academic', title: 'School of Communication and Creative Arts', description: 'Journalism, film production, animation, media, storytelling and creative skills.', contact: 'Email: admissions@usiu.ac.ke\nPhone: +254 730 116 000', website: 'https://sccca.usiu.ac.ke/our-faculty/' },
  { category: 'Academic', title: 'School of Pharmacy and Health Sciences', description: 'Pharmacy, nursing, biochemistry, epidemiology, analytical chemistry and clinical practice.', contact: 'Email: admit@usiu.ac.ke\nDean: Shital M. Maru, PhD — smaru@usiu.ac.ke\nPhone: +254 730 116 000 / 290 / 291', website: 'https://sphs.usiu.ac.ke/our-faculty/' },
  { category: 'Academic', title: 'School of Graduate Studies', description: 'Coordination of master’s and doctoral programmes and research support.', contact: 'Email: admissions@usiu.ac.ke\nPhone: +254 730 116 000' },
  { category: 'Academic', title: 'Academic Advising', description: 'Academic advisor contacts are listed for CSOB, SST, SPHS, SHSS and SCCCA, but individual phone numbers were not provided in the supplied document.', contact: 'Contact details: Not provided in the supplied document.' },
  { category: 'Non-Academic', title: 'IT Helpdesk', description: 'Technical support for campus IT services and multimedia enquiries.', contact: 'Tel: +254 730 116 333\nEmail: helpdesk@usiu.ac.ke\nMultimedia: multimedia@usiu.ac.ke' },
  { category: 'Non-Academic', title: 'Finance Office', description: 'Finance office enquiries.', contact: 'Tel: +254 730 116 403\nEmail: finance@usiu.ac.ke' },
  { category: 'Non-Academic', title: 'Alumni Relations', description: 'Alumni relations and engagement.', contact: 'Tel: +254 730 116 417 / +254 730 116 895\nEmail: alumni@usiu.ac.ke' },
  { category: 'Non-Academic', title: 'Clubs, Societies and Student Activities', description: 'Students can join over 33 clubs and societies and 19 sports teams, including cultural, academic, recreational and career-focused groups.', website: 'https://www.usiu.ac.ke/clubs-activities/' },
  { category: 'Non-Academic', title: 'Sports and Fitness', description: 'Competitive sports, fitness programmes and recreational activities, including dance crews.', website: 'https://www.usiu.ac.ke/sports-fitness/' },
  { category: 'Non-Academic', title: 'Health and Wellness Support', description: 'The Counseling & Wellbeing Center offers individual and group counselling for stress, anxiety, depression, relationship issues and academic pressure, as well as crisis intervention, professional support and wellness workshops. On-campus medical care is also available.', website: 'https://www.usiu.ac.ke/health-wellness/' },
  { category: 'Non-Academic', title: 'Cultural Events and Campus Life', description: 'Campus activities include talent shows, career fairs, themed student nights, guest speaker series and academic conferences.' },
  { category: 'Non-Academic', title: 'Inclusion and Disability Support', description: 'Accessibility support through physical, technological and attitudinal accommodations, inclusive policies and support services.', website: 'https://www.usiu.ac.ke/disability-inclusion/' },
  { category: 'Non-Academic', title: 'Housing and Community Living', description: 'On-campus housing options support student community living.', website: 'https://www.usiu.ac.ke/student-life/housing-accommodation/' },
  { category: 'Non-Academic', title: 'Administrative and Student Affairs', description: 'The Registrar’s Office handles official academic and non-academic matters, including completion, continuation and good-conduct letters, contact-detail updates and international student passes.' },
  { category: 'Non-Academic', title: 'Student Leadership Programmes', description: 'Student leadership development opportunities.', website: 'https://www.usiu.ac.ke/student-leadership-programs/' },
  { category: 'Non-Academic', title: 'Gender Equity and Protection', description: 'Campus information on gender equity and protection.', website: 'https://www.usiu.ac.ke/gender-equity-and-protection/' },
];

const ADMIN_EMAILS = [
  'marlsadmin@usiu.edu',
  'trevoradmin@usiu.edu',
  'emmanueladmin@usiu.edu',
];

const DEMO_ACCOUNTS = [
  { email: 'marlsadmin@usiu.edu', name: 'Marls Admin', role: 'admin' },
  { email: 'trevoradmin@usiu.edu', name: 'Trevor Admin', role: 'admin' },
  { email: 'emmanueladmin@usiu.edu', name: 'Emmanuel Admin', role: 'admin' },
  { email: 'studentdemo@usiu.edu', name: 'Demo Student', role: 'student' },
];

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  return salt + ':' + scryptSync(password, salt, 64).toString('hex');
}

function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash) return false;
  const separator = storedHash.indexOf(':');
  if (separator > 0) {
    const salt = storedHash.slice(0, separator);
    const expected = Buffer.from(storedHash.slice(separator + 1), 'hex');
    const actual = scryptSync(password, salt, 64);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  }
  const legacy = Buffer.from(createHash('sha256').update(password).digest('hex'), 'hex');
  const expected = Buffer.from(storedHash, 'hex');
  return expected.length === legacy.length && timingSafeEqual(expected, legacy);
}

function makeToken(): string {
  return randomBytes(32).toString('hex');
}

async function ensureDemoAccounts() {
  const bootstrapPassword = await secrets.readSecret('SMART_CAMPUS_ADMIN_BOOTSTRAP_SECRET');
  if (!bootstrapPassword || bootstrapPassword.length < 12) {
    throw new Error('The Smart Campus demo bootstrap secret is missing or too short.');
  }

  const passwordFingerprint = createHash('sha256').update(bootstrapPassword).digest('hex');
  const { items } = await db.list(USERS_TABLE, { limit: 500 });
  for (const demo of DEMO_ACCOUNTS) {
    const existing = items.find(
      (u: any) => String(u.email || '').toLowerCase() === demo.email
    ) as any;
    if (!existing) {
      await db.add(USERS_TABLE, [{
        email: demo.email,
        name: demo.name,
        role: demo.role,
        passwordHash: hashPassword(bootstrapPassword),
        demoSeedVersion: 3,
        demoPasswordFingerprint: passwordFingerprint,
        createdAt: Date.now(),
      }]);
    } else if (
      existing.demoSeedVersion !== 3 ||
      existing.demoPasswordFingerprint !== passwordFingerprint
    ) {
      const record = { ...existing };
      delete record.id;
      await db.update(USERS_TABLE, [{
        id: existing.id,
        record: {
          ...record,
          name: demo.name,
          role: demo.role,
          passwordHash: hashPassword(bootstrapPassword),
          demoSeedVersion: 3,
          demoPasswordFingerprint: passwordFingerprint,
        },
      }]);
    }
  }
}

async function getUserFromToken(token: string | undefined) {
  if (!token) return null;
  const { items } = await db.list(SESSIONS_TABLE, { limit: 200 });
  const session = items.find((s: any) => s.token === token);
  if (!session) return null;
  const sessionCreatedAt = Number((session as any).createdAt || 0);
  if (!sessionCreatedAt || sessionCreatedAt < SESSION_VALID_AFTER) return null;
  if ((session as any).expiresAt && (session as any).expiresAt < Date.now()) {
    return null;
  }
  const [user] = await db.get(USERS_TABLE, [(session as any).userId]);
  if (!user) return null;
  const email = String((user as any).email || '').toLowerCase();
  return {
    userId: (user as any).id || (session as any).userId,
    email,
    name: (user as any).name || email,
    role: ADMIN_EMAILS.includes(email) ? 'admin' : 'student',
  };
}

function getTokenFromEvent(event: any, body?: any): string | undefined {
  if (body && typeof body._token === 'string' && body._token) {
    return body._token;
  }
  const headers = event?.headers || {};
  const auth =
    headers.authorization ||
    headers.Authorization ||
    headers['x-session-token'] ||
    headers['X-Session-Token'];
  if (!auth) return undefined;
  if (typeof auth === 'string' && auth.toLowerCase().startsWith('bearer ')) {
    return auth.slice(7).trim();
  }
  return typeof auth === 'string' ? auth : undefined;
}

async function ensureSeed() {
  const { items } = await db.list(EVENTS_TABLE, { limit: 5 });
  if (items.length === 0) {
    await db.add(EVENTS_TABLE, [
      {
        title: 'Freshers Orientation Week',
        category: 'Academic',
        date: '2026-11-12',
        time: '09:00',
        location: 'Main Hall',
        description:
          'Welcome sessions, campus tour and club fair for new students.',
        capacity: 300,
        registered: 0,
      },
      {
        title: 'Inter-Faculty Football Final',
        category: 'Sports',
        date: '2026-11-15',
        time: '15:30',
        location: 'Sports Complex',
        description:
          'Championship match between Engineering and Business faculties.',
        capacity: 500,
        registered: 0,
      },
      {
        title: 'Cultural Night – Music & Dance',
        category: 'Cultural',
        date: '2026-11-18',
        time: '18:00',
        location: 'Open Amphitheatre',
        description: 'Student performances celebrating campus diversity.',
        capacity: 400,
        registered: 0,
      },
      {
        title: 'Career Fair 2026',
        category: 'Academic',
        date: '2026-11-20',
        time: '10:00',
        location: 'Exhibition Centre',
        description: 'Meet top employers and explore internship opportunities.',
        capacity: 600,
        registered: 0,
      },
      {
        title: 'Movie Night under the Stars',
        category: 'Social',
        date: '2026-11-14',
        time: '19:30',
        location: 'Lawn Area B',
        description: 'Outdoor screening of a popular film. Bring a blanket!',
        capacity: 200,
        registered: 0,
      },
    ]);
  }

  const { items: lf } = await db.list(LOSTFOUND_TABLE, { limit: 2 });
  if (lf.length === 0) {
    await db.add(LOSTFOUND_TABLE, [
      {
        type: 'lost',
        title: 'Black Nike Backpack',
        description:
          'Contains textbooks and a blue water bottle. Lost near the library.',
        location: 'Library entrance',
        date: '2026-11-07',
        contact: 'student@campus.edu',
        status: 'open',
      },
      {
        type: 'found',
        title: 'Silver AirPods Case',
        description: 'Found on a bench outside the cafeteria.',
        location: 'Cafeteria courtyard',
        date: '2026-11-08',
        contact: 'security desk',
        status: 'open',
      },
    ]);
  }

  const [q] = await db.get(QUEUE_TABLE, ['main']);
  if (!q) {
    await db.tx.add(QUEUE_TABLE, [
      {
        id: 'main',
        length: 10,
        estimatedWait: 15,
        updatedAt: Date.now(),
      },
    ]);
  }

  const { items: menu } = await db.list(MENU_TABLE, { limit: 5 });
  if (menu.length === 0) {
    await db.add(MENU_TABLE, [
      {
        name: 'Chicken Rice Bowl',
        price: 350,
        category: 'Mains',
        description: 'Grilled chicken, rice, vegetables',
        available: true,
      },
      {
        name: 'Veggie Wrap',
        price: 250,
        category: 'Mains',
        description: 'Fresh vegetables, hummus, whole-wheat wrap',
        available: true,
      },
      {
        name: 'Beef Burger',
        price: 450,
        category: 'Mains',
        description: 'Homemade patty, cheese, fries',
        available: true,
      },
      {
        name: 'Caesar Salad',
        price: 300,
        category: 'Salads',
        description: 'Romaine, croutons, parmesan',
        available: true,
      },
      {
        name: 'Fruit Smoothie',
        price: 200,
        category: 'Drinks',
        description: 'Banana, mango, yogurt',
        available: true,
      },
      {
        name: 'Coffee / Tea',
        price: 120,
        category: 'Drinks',
        description: 'Hot or iced',
        available: true,
      },
    ]);
  }
}

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],

  ...realtimeSubscriptionRoutes,

  'POST /api/auth/register': [
    async ({ body }) => {
      try {
        await ensureDemoAccounts();
      } catch {
        return error('Demo accounts are not configured. Contact the project administrator.', 503);
      }
      const data = (body || {}) as any;
      const email = String(data.email || '').trim().toLowerCase();
      const password = String(data.password || '');
      const name = String(data.name || '').trim() || email.split('@')[0];

      if (!email || !email.includes('@')) return error('Valid email is required', 400);
      if (password.length < 8) return error('Password must be at least 8 characters', 400);
      if (ADMIN_EMAILS.includes(email)) {
        return error('This demo admin account is reserved. Use the Admin login.', 403);
      }

      const { items: existing } = await db.list(USERS_TABLE, { limit: 500 });
      if (existing.some((u: any) => String(u.email || '').toLowerCase() === email)) {
        return error('An account with this email already exists', 400);
      }

      const [userId] = await db.add(USERS_TABLE, [{
        email,
        passwordHash: hashPassword(password),
        name,
        role: 'student',
        createdAt: Date.now(),
      }]);
      if (!userId) return error('Could not create account', 500);

      const token = makeToken();
      await db.add(SESSIONS_TABLE, [{
        token,
        userId,
        expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
        createdAt: Date.now(),
      }]);

      return json({ token, user: { userId, email, name, role: 'student' } });
    },
  ],

  'POST /api/auth/login': [
    async ({ body }) => {
      try {
        await ensureDemoAccounts();
      } catch {
        return error('Demo accounts are not configured. Contact the project administrator.', 503);
      }
      const data = (body || {}) as any;
      const email = String(data.email || '').trim().toLowerCase();
      const password = String(data.password || '');
      const portal = data.portal === 'admin' ? 'admin' : 'student';

      if (!email || !password) return error('Email and password are required', 400);

      const { items } = await db.list(USERS_TABLE, { limit: 500 });
      const user = items.find(
        (u: any) => String(u.email || '').toLowerCase() === email
      ) as any;
      if (!user || !verifyPassword(password, String(user.passwordHash || ''))) {
        return error('Invalid email or password', 401);
      }

      if (user.passwordHash && !user.passwordHash.includes(':')) {
        const upgraded = { ...user };
        delete upgraded.id;
        await db.update(USERS_TABLE, [{
          id: user.id,
          record: { ...upgraded, passwordHash: hashPassword(password) },
        }]);
      }

      const role = ADMIN_EMAILS.includes(email) ? 'admin' : 'student';
      if (portal === 'admin' && role !== 'admin') {
        return error('This account is not approved for the admin portal.', 403);
      }

      const token = makeToken();
      await db.add(SESSIONS_TABLE, [{
        token,
        userId: user.id,
        expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
        createdAt: Date.now(),
      }]);

      return json({
        token,
        user: { userId: user.id, email: user.email, name: user.name || user.email, role },
      });
    },
  ],

  'POST /api/auth/session': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Your session has expired. Please sign in again.', 401);
      return json({ user });
    },
  ],

  'POST /api/auth/logout': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      if (token) {
        const { items } = await db.list(SESSIONS_TABLE, { limit: 500 });
        const match = items.filter((s: any) => s.token === token);
        if (match.length > 0) {
          await db.delete(
            SESSIONS_TABLE,
            match.map((s: any) => s.id)
          );
        }
      }
      return json({ ok: true });
    },
  ],

  'POST /api/services/list': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Sign in to view campus services', 401);
      let { items } = await db.list(CAMPUS_SERVICES_TABLE, { limit: 100 });
      if (items.length === 0) {
        const seeded = await db.add(CAMPUS_SERVICES_TABLE, CAMPUS_SERVICE_SEED.map(item => ({ ...item, createdAt: Date.now(), updatedAt: Date.now() })));
        if (seeded.some(id => !id)) return error('Could not load campus services', 500);
        items = (await db.list(CAMPUS_SERVICES_TABLE, { limit: 100 })).items;
      }
      items = items.filter((item: any) => {
        const contact = String(item.contact || '').trim();
        const website = String(item.website || '').trim();
        return Boolean(website) || (Boolean(contact) && !/not provided/i.test(contact));
      });
      items.sort((a: any, b: any) => String(a.category).localeCompare(String(b.category)) || String(a.title).localeCompare(String(b.title)));
      const paths = items.map((item: any) => item.attachmentPath).filter(Boolean) as string[];
      const signed = paths.length ? await storage.url(paths) : [];
      const urls = new Map(signed.map(item => [item.path, item.url]));
      return json({ items: items.map((item: any) => ({ ...item, attachmentUrl: item.attachmentPath ? urls.get(item.attachmentPath) || null : null })) });
    },
  ],
  'POST /api/services/save': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') return error('Admin access required', 403);
      const data = (body || {}) as any;
      const id = String(data.id || '');
      const category = String(data.category || '');
      const title = String(data.title || '').trim();
      if (!title || !['Academic', 'Non-Academic'].includes(category)) return error('A title and valid service category are required', 400);
      const suppliedContact = String(data.contact || '').trim();
      const suppliedWebsite = String(data.website || '').trim();
      if (!suppliedContact || /not provided/i.test(suppliedContact)) {
        if (!suppliedWebsite) return error('Add contact details or an official website before saving this service', 400);
      }
      let existing: any = null;
      if (id) {
        [existing] = await db.get(CAMPUS_SERVICES_TABLE, [id]);
        if (!existing) return error('Campus service not found', 404);
      }
      let attachmentPath = existing?.attachmentPath || '';
      let attachmentName = existing?.attachmentName || '';
      if (data.attachmentBase64) {
        const contentType = String(data.attachmentContentType || '');
        const allowedTypes = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!allowedTypes.includes(contentType)) return error('Upload a PNG, JPG, WEBP, GIF, PDF or Word document', 400);
        const content = String(data.attachmentBase64);
        if (content.length > 6 * 1024 * 1024) return error('Attachment is too large. Maximum size is 4 MB.', 400);
        const extension = String(data.attachmentName || 'attachment').split('.').pop()?.toLowerCase().replace(/[^a-z0-9]/g, '') || 'bin';
        const path = 'campus-services/' + Date.now() + '-' + randomBytes(8).toString('hex') + '.' + extension;
        const [uploaded] = await storage.write([{ path, content, contentType }]);
        if (!uploaded) return error('Attachment upload failed', 500);
        if (attachmentPath) await storage.delete([attachmentPath]);
        attachmentPath = path;
        attachmentName = String(data.attachmentName || 'Attachment').slice(0, 160);
      }
      const record = { category, title, description: String(data.description || '').trim(), contact: String(data.contact || '').trim(), website: String(data.website || '').trim(), attachmentPath, attachmentName, createdAt: existing?.createdAt || Date.now(), updatedAt: Date.now() };
      if (id) {
        const [updated] = await db.update(CAMPUS_SERVICES_TABLE, [{ id, record }]);
        if (!updated) return error('Could not update campus service', 500);
        return json({ ok: true, id });
      }
      const [newId] = await db.add(CAMPUS_SERVICES_TABLE, [record]);
      if (!newId) return error('Could not create campus service', 500);
      return json({ ok: true, id: newId });
    },
  ],
  'POST /api/services/delete': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') return error('Admin access required', 403);
      const id = String((body as any)?.id || '');
      if (!id) return error('Campus service id is required', 400);
      const [item] = await db.get(CAMPUS_SERVICES_TABLE, [id]);
      if (!item) return error('Campus service not found', 404);
      const [deleted] = await db.delete(CAMPUS_SERVICES_TABLE, [id]);
      if (!deleted) return error('Could not delete campus service', 500);
      if ((item as any).attachmentPath) await storage.delete([(item as any).attachmentPath]);
      return json({ ok: true });
    },
  ],

  'GET /api/events': [
    async ({ event, body }) => {
      await ensureSeed();
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);

      const { items } = await db.list(EVENTS_TABLE, { limit: 50 });

      let myEventIds = new Set<string>();
      if (user) {
        const { items: regs } = await db.list(REGISTRATIONS_TABLE, {
          limit: 200,
        });
        myEventIds = new Set(
          regs
            .filter((r: any) => r.userId === user.userId)
            .map((r: any) => r.eventId)
        );
      }

      const mapped = items.map((ev: any) => ({
        ...ev,
        isRegistered: myEventIds.has(ev.id),
      }));

      return json({ items: mapped });
    },
  ],

  'POST /api/events/list': [
    async ({ event, body }) => {
      await ensureSeed();
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);

      const { items } = await db.list(EVENTS_TABLE, { limit: 50 });

      let myEventIds = new Set<string>();
      if (user) {
        const { items: regs } = await db.list(REGISTRATIONS_TABLE, {
          limit: 200,
        });
        myEventIds = new Set(
          regs
            .filter((r: any) => r.userId === user.userId)
            .map((r: any) => r.eventId)
        );
      }

      const mapped = items.map((ev: any) => ({
        ...ev,
        isRegistered: myEventIds.has(ev.id),
      }));

      return json({ items: mapped });
    },
  ],

  'POST /api/events': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') return error('Admin access required', 403);
      const data = (body || {}) as any;
      const capacity = Number(data.capacity) || 100;
      if (!data.title || !data.date || !data.time || !data.location || capacity < 1) return error('Event title, date, time, location and valid capacity are required', 400);
      const [id] = await db.add(EVENTS_TABLE, [{ title: String(data.title).trim(), category: String(data.category || 'Social'), date: String(data.date), time: String(data.time), location: String(data.location).trim(), description: String(data.description || ''), capacity, registered: 0, createdAt: Date.now() }]);
      return json({ id, ok: true });
    },
  ],

  'POST /api/events/:id/register': [
    async ({ params, event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Please sign in to register for events', 401);
      if (user.role !== 'student') return error('Only student accounts can register for events', 403);

      const id = params.id;
      const [ev] = await db.get(EVENTS_TABLE, [id]);
      if (!ev) return error('Event not found', 404);

      const { items: regs } = await db.list(REGISTRATIONS_TABLE, { limit: 500 });
      const already = regs.find(
        (r: any) => r.eventId === id && r.userId === user.userId
      );
      if (already) {
        return json({
          ok: true,
          alreadyRegistered: true,
          registered: (ev as any).registered || 0,
        });
      }

      const current = (ev as any).registered || 0;
      if (current >= (ev as any).capacity) {
        return error('Event is full', 400);
      }

      await db.add(REGISTRATIONS_TABLE, [
        {
          eventId: id,
          userId: user.userId,
          userName: user.name,
          userEmail: user.email,
          createdAt: Date.now(),
        },
      ]);

      const newRegistered = current + 1;
      await db.tx.update(
        EVENTS_TABLE,
        [{ id, record: { registered: newRegistered } }],
        { patch: true }
      );

      return json({ ok: true, registered: newRegistered });
    },
  ],

  'POST /api/events/:id/registrations': [
    async ({ params, event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') {
        return error('Admin access required', 403);
      }

      const { items: regs } = await db.list(REGISTRATIONS_TABLE, { limit: 500 });
      const forEvent = regs
        .filter((r: any) => r.eventId === params.id)
        .sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0));

      return json({ items: forEvent });
    },
  ],

  'GET /api/lostfound': [
    async () => {
      await ensureSeed();
      const { items } = await db.list(LOSTFOUND_TABLE, { limit: 50 });
      const withPhotos = await Promise.all(
        items.map(async (item: any) => {
          if (!item.photoPath) return { ...item, photoUrl: null };
          try {
            const [u] = await storage.url([item.photoPath]);
            return { ...item, photoUrl: u?.url || null };
          } catch {
            return { ...item, photoUrl: null };
          }
        })
      );
      return json({ items: withPhotos });
    },
  ],

  'POST /api/lostfound': [
    async ({ body }) => {
      const data = (body || {}) as any;
      if (!data.title || !data.description) {
        return error('title and description are required');
      }

      let photoPath: string | null = null;
      if (data.photoBase64 && typeof data.photoBase64 === 'string') {
        const contentType = data.photoContentType || 'image/jpeg';
        const ext = contentType.includes('png')
          ? 'png'
          : contentType.includes('webp')
            ? 'webp'
            : 'jpg';
        photoPath =
          'lostfound/' +
          Date.now() +
          '-' +
          Math.random().toString(36).slice(2, 8) +
          '.' +
          ext;
        // Strip data URL prefix if present
        let b64 = data.photoBase64;
        const comma = b64.indexOf(',');
        if (b64.startsWith('data:') && comma !== -1) {
          b64 = b64.slice(comma + 1);
        }
        const [ok] = await storage.write([
          { path: photoPath, content: b64, contentType },
        ]);
        if (!ok) {
          return error('Failed to upload photo', 500);
        }
      }

      const [id] = await db.add(LOSTFOUND_TABLE, [
        {
          type: data.type === 'found' ? 'found' : 'lost',
          title: data.title,
          description: data.description,
          location: data.location || 'Campus',
          date: new Date().toISOString().slice(0, 10),
          contact: data.contact || 'Anonymous',
          status: 'open',
          photoPath,
        },
      ]);

      let photoUrl: string | null = null;
      if (photoPath) {
        try {
          const [u] = await storage.url([photoPath]);
          photoUrl = u?.url || null;
        } catch {
          photoUrl = null;
        }
      }

      return json({ id, ok: true, photoUrl });
    },
  ],

  'GET /api/menu': [
    async () => {
      await ensureSeed();
      const { items } = await db.list(MENU_TABLE, { limit: 100 });
      return json({ items });
    },
  ],

  'POST /api/menu/list': [
    async () => {
      await ensureSeed();
      const { items } = await db.list(MENU_TABLE, { limit: 100 });
      return json({ items });
    },
  ],

  'POST /api/menu/add': [
    async ({ body, event }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') {
        return error('Admin access required', 403);
      }

      const data = (body || {}) as any;
      if (!data.name || data.price == null) {
        return error('name and price are required', 400);
      }

      const [id] = await db.add(MENU_TABLE, [
        {
          name: String(data.name),
          price: Number(data.price),
          category: data.category || 'Mains',
          description: data.description || '',
          available: data.available !== false,
          createdAt: Date.now(),
        },
      ]);
      return json({ id, ok: true });
    },
  ],

  'POST /api/menu/update': [
    async ({ body, event }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') {
        return error('Admin access required', 403);
      }

      const data = (body || {}) as any;
      if (!data.id) return error('id required', 400);

      await db.tx.update(
        MENU_TABLE,
        [
          {
            id: data.id,
            record: {
              name: data.name,
              price: Number(data.price),
              category: data.category,
              description: data.description,
              available: data.available !== false,
            },
          },
        ],
        { patch: true }
      );
      return json({ ok: true });
    },
  ],

  'POST /api/menu/delete': [
    async ({ body, event }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') {
        return error('Admin access required', 403);
      }

      const data = (body || {}) as any;
      if (!data.id) return error('id required', 400);
      await db.delete(MENU_TABLE, [data.id]);
      return json({ ok: true });
    },
  ],

  'POST /api/orders/list': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);

      const { items } = await db.list(ORDERS_TABLE, { limit: 100 });
      const mine = items
        .filter((order: any) => order.userId === user.userId)
        .sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0));
      return json({ items: mine });
    },
  ],

  'POST /api/orders': [
    async ({ body, event }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);
      if (user.role !== 'student') return error('Only student accounts can place cafeteria orders', 403);

      const data = (body || {}) as any;
      if (!Array.isArray(data.items) || data.items.length === 0) {
        return error('items required');
      }
      const [id] = await db.add(ORDERS_TABLE, [{
        userId: user.userId,
        items: data.items,
        total: data.total || 0,
        pickupTime: data.pickupTime || '12:00',
        status: 'Preparing',
        createdAt: Date.now(),
      }]);
      return json({ id, ok: true });
    },
  ],

  'POST /api/expenses/list': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);

      const { items } = await db.list(EXPENSES_TABLE, { limit: 100 });
      const mine = items
        .filter((e: any) => e.userId === user.userId)
        .sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0));
      return json({ items: mine });
    },
  ],

  'POST /api/expenses': [
    async ({ body, event }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);
      if (user.role !== 'student') return error('Finance entry is student-only', 403);

      const data = (body || {}) as any;
      if (!data.title || data.amount == null || !Number.isFinite(Number(data.amount)) || Number(data.amount) < 0) {
        return error('A title and valid non-negative amount are required', 400);
      }
      const [id] = await db.add(EXPENSES_TABLE, [
        {
          userId: user.userId,
          title: data.title,
          amount: Number(data.amount),
          category: String(data.category || 'General').trim(),
          date: data.date ? String(data.date) : new Date().toISOString().slice(0, 10),
          expenseType: 'daily',
          createdAt: Date.now(),
        },
      ]);
      return json({ id, ok: true });
    },
  ],

  'POST /api/expenses/update': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'student') return error('Student access required', 403);
      const data = (body || {}) as any;
      const id = String(data.id || '');
      const title = String(data.title || '').trim();
      const amount = Number(data.amount);
      const category = String(data.category || 'General').trim();
      const date = String(data.date || '');
      if (!id || !title || !category || !/^\\d{4}-\\d{2}-\\d{2}$/.test(date) || !Number.isFinite(amount) || amount < 0) return error('Enter a title, category, valid date and non-negative amount', 400);
      const [expense] = await db.get(EXPENSES_TABLE, [id]);
      if (!expense || (expense as any).userId !== user.userId) return error('Expense not found', 404);
      await db.tx.update(EXPENSES_TABLE, [{ id, record: { title, amount, category, date, updatedAt: Date.now() } }], { patch: true });
      return json({ ok: true });
    },
  ],
  'POST /api/expenses/delete': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'student') return error('Student access required', 403);
      const id = String((body as any)?.id || '');
      if (!id) return error('Expense id required', 400);
      const [expense] = await db.get(EXPENSES_TABLE, [id]);
      if (!expense || (expense as any).userId !== user.userId) return error('Expense not found', 404);
      await db.delete(EXPENSES_TABLE, [id]);
      return json({ ok: true });
    },
  ],

  'POST /api/budget/get': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);
      if (user.role !== 'student') return error('Student finance only', 403);

      const [budget] = await db.get(BUDGETS_TABLE, [user.userId]);
      return json({
        monthlyBudget: (budget as any)?.monthlyBudget ?? 0,
      });
    },
  ],

  'POST /api/budget/set': [
    async ({ body, event }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);
      if (user.role !== 'student') return error('Student finance only', 403);

      const data = (body || {}) as any;
      const monthlyBudget = Number(data.monthlyBudget);
      if (isNaN(monthlyBudget) || monthlyBudget < 0) {
        return error('Valid monthly budget required', 400);
      }

      await db.tx.add(BUDGETS_TABLE, [
        { id: user.userId, monthlyBudget, updatedAt: Date.now() },
      ]);
      await db.tx.update(
        BUDGETS_TABLE,
        [{ id: user.userId, record: { monthlyBudget, updatedAt: Date.now() } }],
        { patch: true }
      );

      return json({ monthlyBudget });
    },
  ],

  'GET /api/queue': [
    async () => {
      await ensureSeed();
      const [q] = await db.get(QUEUE_TABLE, ['main']);
      if (!q) {
        return json({ length: 0, estimatedWait: 0, updatedAt: Date.now() });
      }
      return json(q);
    },
  ],

  'POST /api/queue/join': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);
      if (user.role !== 'student') return error('Only student accounts can join the cafeteria queue', 403);
      await ensureSeed();
      const [q] = await db.get(QUEUE_TABLE, ['main']);
      const current = (q as any) || { length: 0, estimatedWait: 0 };
      const newLength = (current.length || 0) + 1;
      const newWait = Math.max(5, Math.round(newLength * 1.5));
      const payload = {
        length: newLength,
        estimatedWait: newWait,
        updatedAt: Date.now(),
      };
      await db.tx.update(
        QUEUE_TABLE,
        [{ id: 'main', record: payload }],
        { patch: true }
      );
      await notifySubscribers('queue', 'main', payload);
      return json(payload);
    },
  ],

  'POST /api/admin/stats': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'admin') {
        return error('Admin access required', 403);
      }

      const { items: users } = await db.list(USERS_TABLE, { limit: 500 });
      const { items: sessions } = await db.list(SESSIONS_TABLE, { limit: 500 });
      const { items: usageEvents } = await db.list(USAGE_TABLE, { limit: 500 });
      const usageByCategory: Record<string, number> = {};
      usageEvents.forEach((entry: any) => { const category = String(entry.category || 'other'); usageByCategory[category] = (usageByCategory[category] || 0) + 1; });
      const uniqueUsersTracked = new Set(usageEvents.map((entry: any) => entry.userId).filter(Boolean)).size;
      const buildUsageBuckets = (period: 'daily' | 'weekly' | 'monthly', limit: number) => {
        const grouped = new Map<string, { visits: number; users: Set<string>; byCategory: Record<string, number> }>();
        usageEvents.forEach((entry: any) => {
          const timestamp = Number(entry.createdAt || 0);
          if (!timestamp) return;
          const local = new Date(timestamp + 3 * 60 * 60 * 1000);
          let key = local.toISOString().slice(0, 10);
          if (period === 'weekly') {
            const mondayOffset = (local.getUTCDay() + 6) % 7;
            local.setUTCDate(local.getUTCDate() - mondayOffset);
            key = local.toISOString().slice(0, 10);
          } else if (period === 'monthly') {
            key = local.toISOString().slice(0, 7);
          }
          if (!grouped.has(key)) grouped.set(key, { visits: 0, users: new Set<string>(), byCategory: {} });
          const bucket = grouped.get(key)!;
          bucket.visits += 1;
          if (entry.userId) bucket.users.add(String(entry.userId));
          const category = String(entry.category || 'other');
          bucket.byCategory[category] = (bucket.byCategory[category] || 0) + 1;
        });
        return Array.from(grouped.entries()).sort((a, b) => b[0].localeCompare(a[0])).slice(0, limit).map(([key, value]) => ({
          key,
          visits: value.visits,
          uniqueUsers: value.users.size,
          byCategory: value.byCategory,
        }));
      };
      const usageReports = {
        daily: buildUsageBuckets('daily', 7),
        weekly: buildUsageBuckets('weekly', 8),
        monthly: buildUsageBuckets('monthly', 6),
      };
      const now = Date.now();
      const activeSessions = sessions.filter(
        (s: any) => !s.expiresAt || s.expiresAt > now
      );
      const activeUserIds = new Set(
        activeSessions.map((s: any) => s.userId).filter(Boolean)
      );

      const recentUsers = users
        .slice()
        .sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 30)
        .map((u: any) => ({
          id: u.id,
          email: u.email,
          name: u.name || u.email,
          role: u.role === 'admin' ? 'admin' : 'student',
          createdAt: u.createdAt || null,
          isSignedIn: activeUserIds.has(u.id),
        }));

      return json({
        totalUsers: users.length,
        activeSessions: activeSessions.length,
        signedInUsers: activeUserIds.size,
        recentUsers,
        totalUsageEvents: usageEvents.length,
        usageByCategory,
        uniqueUsersTracked,
        usageReports,
      });
    },
  ],

  'POST /api/recurring-expenses/list': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'student') return error('Student access required', 403);
      const { items } = await db.list(RECURRING_EXPENSES_TABLE, { limit: 200 });
      return json({ items: items.filter((item: any) => item.userId === user.userId).sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0)) });
    },
  ],
  'POST /api/recurring-expenses': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'student') return error('Student access required', 403);
      const data = (body || {}) as any;
      const amount = Number(data.amount), title = String(data.title || '').trim(), category = String(data.category || 'General').trim();
      if (!title || !category || !Number.isFinite(amount) || amount < 0) return error('A title, category and valid amount are required', 400);
      const [id] = await db.add(RECURRING_EXPENSES_TABLE, [{ userId: user.userId, title, amount, category, createdAt: Date.now() }]);
      return json({ id, ok: true });
    },
  ],
  'POST /api/recurring-expenses/delete': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user || user.role !== 'student') return error('Student access required', 403);
      const id = String((body as any)?.id || '');
      if (!id) return error('Expense id required', 400);
      const [item] = await db.get(RECURRING_EXPENSES_TABLE, [id]);
      if (!item || (item as any).userId !== user.userId) return error('Expense not found', 404);
      await db.delete(RECURRING_EXPENSES_TABLE, [id]);
      return json({ ok: true });
    },
  ],
  'POST /api/usage/track': [
    async ({ event, body }) => {
      const token = getTokenFromEvent(event, body);
      const user = await getUserFromToken(token);
      if (!user) return error('Not authenticated', 401);
      const allowed = ['home', 'events', 'services', 'lostfound', 'cafeteria', 'finance', 'admin'];
      const category = String((body as any)?.category || '');
      if (!allowed.includes(category)) return error('Invalid app area', 400);
      if (category === 'finance' && user.role !== 'student') return error('Finance is student-only', 403);
      if (category === 'admin' && user.role !== 'admin') return error('Admin access required', 403);
      await db.add(USAGE_TABLE, [{ userId: user.userId, role: user.role, category, createdAt: Date.now() }]);
      return json({ ok: true });
    },
  ],
});
