import React from "react";
import USIUChatbot from "../src/USIUChatbot.jsx";
import { createUSIUChatClient } from "../src/chat-client.js";

// Vite reads this browser-safe setting at build time. It is a backend URL, not a secret.
const chatbotClient = createUSIUChatClient({
  baseUrl: import.meta.env.VITE_USIU_CHAT_API_BASE_URL || ""
});

/**
 * Example only: mount this component or the <USIUChatbot /> section inside an
 * existing React page. Keep the host navigation, auth, dashboard, and other
 * campus features where they already are.
 */
export default function ExistingReactPage() {
  return (
    <main>
      {/* Keep your existing header, authentication state, and page content here. */}
      <section aria-label="Existing host application content">
        {/* Existing dashboard or campus features stay unchanged. */}
      </section>

      <aside aria-label="USIU campus assistant">
        <USIUChatbot
          client={chatbotClient}
          language="auto"
          onDestination={destination => {
            // Optional: hand the destination to an existing host map.
            // No global event or host route is assumed by this package.
            console.info("Chatbot selected campus destination:", destination.id);
          }}
        />
      </aside>
    </main>
  );
}
