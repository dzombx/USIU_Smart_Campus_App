# USIU Campus Chatbot — React integration package

This is a small, isolated React chat widget and client adapter for embedding the **existing USIU Campus Chatbot** inside another React application. It is not a new full application, and it does not replace the host project.

The package contains a real API client. It does **not** return mock answers. If the configured backend is missing or unavailable, the component displays an error and retry option.

## Scope and important backend dependency

The widget covers the chat window, message list, user/assistant styling, composer, send button, empty/loading/error states, responsive layout, keyboard support, HTTPS source links, and an optional destination callback.

The widget is only the frontend. The actual USIU answer service remains a Node.js backend that calls Gemini and Google Search grounding. This ZIP does not contain that backend, its protected Gemini key, campus/event datasets, or the map. The existing `server.js` imports other files from the full chatbot repository and is not a standalone file that can simply be copied. Deploy the existing backend intact or provide a host API with the contract in [`docs/API-CONTRACT.md`](docs/API-CONTRACT.md).

The current API does not implement user authentication or CORS. It is normally called on the same origin. Read the API contract before exposing it from a different site.

## Installation inside an existing React project

1. Unzip this package and copy the `src/` folder into a non-conflicting location in the existing React project. Copy `examples/ExistingReactPage.jsx` only if useful as a reference. Do not replace the host app or its routing, authentication, dashboard, database, or campus features.
2. Ensure the host already has React 18 or newer and a React-compatible bundler that supports JSX and CSS imports (for example, Vite). The widget has no UI framework or icon-library dependency.
3. Copy `.env.example` to the host’s local environment file if it uses Vite. Leave the API origin blank when the host can proxy `/api/chat` on the same origin. Otherwise set `VITE_USIU_CHAT_API_BASE_URL` to the backend origin, such as `https://your-chat-backend.example` (without `/api/chat`). This is a public URL, not a secret.
4. Import the component and stylesheet into an existing page. Adapt paths to the host’s actual file structure; the example path is illustrative, not an assumption about the host repository.
5. Make sure the existing USIU backend is deployed and reachable. For cross-origin requests, configure an exact CORS allow-list on the backend or use a same-origin reverse proxy. The current backend does not enable CORS by itself.

## Example use inside an existing page

See [`examples/ExistingReactPage.jsx`](examples/ExistingReactPage.jsx) for a complete insertion example. The essential usage is:

```jsx
import USIUChatbot from "./path-you-selected/USIUChatbot.jsx";
import "./path-you-selected/usiu-chatbot.css";

<USIUChatbot backendUrl={import.meta.env.VITE_USIU_CHAT_API_BASE_URL || ""} />
```

You may create a client explicitly and pass it through `client`:

```jsx
import { createUSIUChatClient } from "./path-you-selected/chat-client.js";

const chatbotClient = createUSIUChatClient({
  baseUrl: import.meta.env.VITE_USIU_CHAT_API_BASE_URL || ""
});

<USIUChatbot client={chatbotClient} language="auto" />
```

`language` can be `auto`, `en`, `sw`, `fr`, `ar`, `so`, or `es`. `onDestination` is optional; if the API returns a campus destination, the widget passes `{ id, name }` to that callback. Connect it to an existing host map only if desired. This package does not include 3D mapping or GPS features.

To show the current backend’s local official-source IDs as links, pass `sourceResolver(ids)` and return verified `{ label, url }` records. The adapter already displays safe HTTPS links in `webSources` from Google Search grounding.

This widget is text-only. The response includes `speechLanguage` for a host that wants to add its own voice layer, but browser speech playback and microphone input are not included.

## API contract and configuration

The adapter calls `POST /api/chat`. Its public component interface accepts `{ message, history, language }`, then maps `message` to the existing backend’s required `question` field. The existing backend does not support `conversationId`; it is stateless and receives recent conversation messages in `history`. See [`docs/API-CONTRACT.md`](docs/API-CONTRACT.md) for exact request/response schemas, errors, auth, CORS, rate limits, and environment variables.

Keep `GEMINI_API_KEY` on the backend only. Do not put it in Vite, a React prop, browser storage, or any `.env` variable exposed to client code. This package contains only `.env.example` with an empty URL placeholder.

## Dependencies

**Widget runtime:** React `>=18` is a peer dependency expected to be provided by the host. `react-dom` is needed by a browser React app but is not imported by this component. No additional runtime packages are required by the widget or adapter.

**Existing backend:** Node.js `>=22`, `@google/genai` `3.0.0`, the existing backend source/data modules, and a server-side `GEMINI_API_KEY`. `PORT` is optional and defaults to `3000`. These backend requirements belong to the existing chatbot deployment and are not bundled here.

## Runtime files to copy

For a direct source integration, copy these files to a non-conflicting location in the host project and adjust import paths as needed:

- `src/USIUChatbot.jsx`
- `src/chat-client.js`
- `src/usiu-chatbot.css`

Copy `src/index.js` only if the host wants a local package-style export. Use `.env.example` as a template for a local Vite environment file, but do not commit real credentials. The example page, API documentation, tests, and `package.json` are references; merge dependency metadata when needed instead of replacing the host manifest.

## Files in the ZIP

- `src/USIUChatbot.jsx` — reusable React component.
- `src/usiu-chatbot.css` — style-scoped responsive component styles.
- `src/chat-client.js` — backend URL configuration, request adapter, response validation, and citation sanitization.
- `src/index.js` — component/client exports.
- `examples/ExistingReactPage.jsx` — reference showing insertion into an existing page.
- `docs/API-CONTRACT.md` — actual backend routes and contract details.
- `tests/chat-client.test.js` — adapter contract tests.
- `package.json` — peer dependency metadata and test command.
- `.env.example` — empty placeholder for the non-secret backend origin.

## Files/settings not to overwrite

Do not replace the host’s `App.jsx`, `App.tsx`, `main.jsx`, `index.html`, router, navigation, authentication/session code, dashboard, database/schema, campus pages, or global stylesheet. Do not overwrite the host `package.json`; if needed, merge only the React peer dependency or a local path alias. Do not copy the current chatbot’s `server.js` alone. Do not add real keys or credentials to the package or frontend environment.

## Troubleshooting

- **“Could not reach the chatbot server”** — verify that the backend origin is correct and `POST /api/chat` is reachable. An empty `backendUrl` means the host origin itself must serve or proxy `/api/chat`.
- **CORS or `OPTIONS` failure** — the current API does not add CORS headers or handle cross-origin preflight. Prefer a same-origin reverse proxy, or add a narrowly scoped CORS allow-list on the backend.
- **HTTP 404** — the host did not route `/api/chat` to the USIU backend, or the configured base URL/path is wrong. The base URL should not include `/api/chat`.
- **HTTP 400 / 413 / 415** — check the `question` length (1–500 characters), JSON body size/content type, and request mapping.
- **HTTP 429** — this can be the current backend’s 30-requests-per-IP-per-minute guard or Gemini/Search-grounding quota. Check server and Google AI Studio usage/limits.
- **HTTP 502** — the existing backend could not complete a Gemini request. Check backend logs, provider availability, and project quota; never move the Gemini key into the browser to troubleshoot.
- **HTTP 503** — the backend has no `GEMINI_API_KEY` configured. Set it securely in the backend runtime environment.
- **No source links for a campus fact** — the current server may return symbolic `sourceIds` without URLs. Add a trusted `sourceResolver` map or extend the backend to return safe official links. Google Search `webSources` are displayed automatically.
- **No route action** — this package does not contain the 3D map. Supply an `onDestination` callback and connect it to a host map if the returned destination is available.
- **Build cannot import CSS or JSX** — use a React-compatible bundler, or adapt the component and CSS imports to the host’s build system. Do not add a new app shell just to embed the widget.

## Validation

From this package directory, run:

```sh
npm test
```

The tests use a stubbed fetch only to test client request/response mapping; they are not chatbot answers and do not constitute mock mode in the shipped component.
