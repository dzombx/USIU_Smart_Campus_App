import React, { useEffect, useMemo, useRef, useState } from "react";
import { createUSIUChatClient, publicHttpsSources } from "./chat-client.js";
import "./usiu-chatbot.css";

function makeId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function resolveExtraSources(resolver, sourceIds) {
  if (typeof resolver !== "function" || !sourceIds.length) return [];
  try {
    return publicHttpsSources(resolver(sourceIds));
  } catch {
    return [];
  }
}

export default function USIUChatbot({
  client,
  backendUrl = "",
  language = "auto",
  title = "USIU Campus Chatbot",
  className = "",
  sourceResolver,
  onDestination
}) {
  const defaultClient = useMemo(() => createUSIUChatClient({ baseUrl: backendUrl }), [backendUrl]);
  const api = client || defaultClient;
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const transcriptRef = useRef(null);
  const formRef = useRef(null);

  useEffect(() => {
    const transcript = transcriptRef.current;
    if (transcript) transcript.scrollTop = transcript.scrollHeight;
  }, [messages, loading, error]);

  async function sendQuestion(rawQuestion, { appendUser = true } = {}) {
    const question = String(rawQuestion || "").trim();
    if (!question || question.length > 500 || loading) return;
    const historyMessages = appendUser
      ? messages
      : messages.at(-1)?.role === "user" ? messages.slice(0, -1) : messages;
    const history = historyMessages
      .filter(item => item.role === "user" || item.role === "assistant")
      .slice(-8)
      .map(({ role, text }) => ({ role, text }));
    if (appendUser) setMessages(current => [...current, { id: makeId(), role: "user", text: question }]);
    setError("");
    setLoading(true);
    try {
      const result = await api.sendMessage({ message: question, history, language });
      const extraSources = resolveExtraSources(sourceResolver, result.sourceIds || []);
      const sources = publicHttpsSources([...(result.sources || []), ...extraSources]);
      setMessages(current => [...current, {
        id: makeId(),
        role: "assistant",
        text: result.reply,
        sources,
        destination: result.destination || null
      }]);
    } catch (requestError) {
      setError(requestError?.message || "The chatbot could not complete that request. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
    const question = draft.trim();
    if (!question || loading) return;
    setDraft("");
    void sendQuestion(question);
  }

  function handleKeyDown(event) {
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent?.isComposing) {
      event.preventDefault();
      formRef.current?.requestSubmit();
    }
  }

  function startNewChat() {
    if (loading) return;
    setMessages([]);
    setDraft("");
    setError("");
  }

  const retryQuestion = messages.at(-1)?.role === "user" ? messages.at(-1).text : "";
  const rootClass = ["usiu-chatbot", className].filter(Boolean).join(" ");

  return (
    <section className={rootClass} aria-label={title}>
      <header className="usiu-chatbot__header">
        <div className="usiu-chatbot__brand">
          <span className="usiu-chatbot__brand-mark" aria-hidden="true">U</span>
          <div>
            <h2 className="usiu-chatbot__title">{title}</h2>
            <p className="usiu-chatbot__subtitle">Campus information assistant</p>
          </div>
        </div>
        <button className="usiu-chatbot__new-chat" type="button" onClick={startNewChat} disabled={loading}>
          New chat
        </button>
      </header>

      <div
        className="usiu-chatbot__messages"
        ref={transcriptRef}
        role="log"
        aria-live="polite"
        aria-relevant="additions text"
        aria-busy={loading}
      >
        {messages.length === 0 && (
          <div className="usiu-chatbot__empty">
            <div className="usiu-chatbot__empty-mark" aria-hidden="true">✦</div>
            <h3>How can I help?</h3>
            <p>Ask about USIU-Africa, campus services, admissions, or events.</p>
          </div>
        )}

        {messages.map(message => (
          <article className={`usiu-chatbot__message usiu-chatbot__message--${message.role}`} key={message.id}>
            <div className="usiu-chatbot__sender">{message.role === "assistant" ? title : "You"}</div>
            <div className="usiu-chatbot__bubble" dir="auto">{message.text}</div>
            {message.role === "assistant" && message.sources?.length > 0 && (
              <nav className="usiu-chatbot__sources" aria-label="Answer sources">
                {message.sources.map(source => (
                  <a key={source.url} href={source.url} target="_blank" rel="noopener noreferrer">
                    {source.label}
                  </a>
                ))}
              </nav>
            )}
            {message.role === "assistant" && message.destination && typeof onDestination === "function" && (
              <button
                className="usiu-chatbot__route"
                type="button"
                onClick={() => onDestination(message.destination)}
              >
                Show route to {message.destination.name}
              </button>
            )}
          </article>
        ))}

        {loading && (
          <div className="usiu-chatbot__loading" role="status" aria-live="polite">
            <span className="usiu-chatbot__spinner" aria-hidden="true" />
            <span>Finding an answer…</span>
          </div>
        )}
      </div>

      {error && (
        <div className="usiu-chatbot__error" role="alert">
          <span>{error}</span>
          {retryQuestion && (
            <button type="button" onClick={() => void sendQuestion(retryQuestion, { appendUser: false })} disabled={loading}>
              Try again
            </button>
          )}
        </div>
      )}

      <form className="usiu-chatbot__composer" ref={formRef} onSubmit={handleSubmit}>
        <label className="usiu-chatbot__sr-only" htmlFor="usiu-chatbot-question">Ask a campus question</label>
        <textarea
          id="usiu-chatbot-question"
          className="usiu-chatbot__input"
          value={draft}
          onChange={event => setDraft(event.target.value.slice(0, 500))}
          onKeyDown={handleKeyDown}
          maxLength={500}
          rows={2}
          placeholder="Type your question…"
          disabled={loading}
        />
        <div className="usiu-chatbot__composer-footer">
          <span className="usiu-chatbot__hint">Enter to send · Shift+Enter for a new line</span>
          <span className="usiu-chatbot__count" aria-live="off">{draft.length}/500</span>
          <button className="usiu-chatbot__send" type="submit" disabled={loading || !draft.trim()}>
            {loading ? "Sending…" : "Send"}
          </button>
        </div>
      </form>
    </section>
  );
}
