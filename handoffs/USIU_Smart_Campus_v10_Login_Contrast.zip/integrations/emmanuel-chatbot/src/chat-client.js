const API_PATH = "/api/chat";
const SUPPORTED_LANGUAGES = new Set(["auto", "en", "sw", "fr", "ar", "so", "es"]);

export class ChatApiError extends Error {
  constructor(message, status = 0, code = "CHAT_API_ERROR") {
    super(message);
    this.name = "ChatApiError";
    this.status = status;
    this.code = code;
  }
}

function publicHttpsSources(entries) {
  if (!Array.isArray(entries)) return [];
  const seen = new Set();
  const safe = [];
  for (const item of entries) {
    const raw = item?.url || item?.uri;
    if (typeof raw !== "string" || raw.length > 2048) continue;
    let url;
    try {
      url = new URL(raw);
    } catch {
      continue;
    }
    const host = url.hostname.toLowerCase().replace(/\.$/, "");
    if (url.protocol !== "https:" || url.username || url.password || !host.includes(".")
      || host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")
      || host.endsWith(".internal") || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.startsWith("[")) continue;
    if (seen.has(url.href)) continue;
    seen.add(url.href);
    const label = String(item?.label || item?.title || host).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, 140) || host;
    safe.push({ label, url: url.href });
    if (safe.length === 5) break;
  }
  return safe;
}

function cleanHistory(history) {
  if (!Array.isArray(history)) return [];
  return history.slice(-8).flatMap(turn => {
    if (!turn || !["user", "assistant"].includes(turn.role) || typeof turn.text !== "string") return [];
    const text = turn.text.trim().slice(0, 1200);
    return text ? [{ role: turn.role, text }] : [];
  });
}

function cleanDestination(value) {
  if (!value || typeof value.id !== "string" || typeof value.name !== "string") return null;
  const id = value.id.trim();
  const name = value.name.trim();
  return id && id.length <= 120 && name && name.length <= 120 ? { id, name } : null;
}

/**
 * Adapts the existing USIU Node API ({ question, history, language }) to the
 * component-facing shape ({ message, history, language } => { reply, ... }).
 * The base URL is an origin, such as "https://chat.example.org", not an API key.
 * An empty base URL uses same-origin /api/chat.
 */
export function createUSIUChatClient({ baseUrl = "", fetchImpl = globalThis.fetch, timeoutMs = 35_000 } = {}) {
  if (typeof fetchImpl !== "function") throw new TypeError("A fetch implementation is required.");
  const normalizedBase = typeof baseUrl === "string" ? baseUrl.trim().replace(/\/+$/, "") : "";
  const endpoint = `${normalizedBase}${API_PATH}`;

  return {
    endpoint,
    async sendMessage({ message, history = [], language = "auto", signal } = {}) {
      const question = typeof message === "string" ? message.trim() : "";
      if (!question || question.length > 500) {
        throw new ChatApiError("Enter a question between 1 and 500 characters.", 400, "INVALID_MESSAGE");
      }
      const requestedLanguage = SUPPORTED_LANGUAGES.has(language) ? language : "auto";
      const controller = new AbortController();
      const timer = Number.isFinite(timeoutMs) && timeoutMs > 0
        ? setTimeout(() => controller.abort(), timeoutMs)
        : null;
      const forwardAbort = () => controller.abort();
      signal?.addEventListener?.("abort", forwardAbort, { once: true });

      try {
        const response = await fetchImpl(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ question, history: cleanHistory(history), language: requestedLanguage }),
          signal: controller.signal
        });
        let payload = {};
        try {
          payload = await response.json();
        } catch {
          payload = {};
        }
        if (!response.ok) {
          const messageFromServer = typeof payload?.error === "string" && payload.error.trim()
            ? payload.error.trim()
            : `The chatbot request failed (HTTP ${response.status}).`;
          throw new ChatApiError(messageFromServer, response.status, "HTTP_ERROR");
        }
        if (typeof payload?.answer !== "string" || !payload.answer.trim()) {
          throw new ChatApiError("The chatbot returned an incomplete response.", response.status, "INVALID_RESPONSE");
        }
        return {
          reply: payload.answer.trim(),
          sourceIds: Array.isArray(payload.sourceIds)
            ? [...new Set(payload.sourceIds.filter(id => typeof id === "string" && id.length <= 120))].slice(0, 5)
            : [],
          sources: publicHttpsSources(payload.webSources),
          destination: cleanDestination(payload.destination),
          speechLanguage: typeof payload.speechLanguage === "string" ? payload.speechLanguage : "en"
        };
      } catch (error) {
        if (controller.signal.aborted) {
          throw new ChatApiError("The chatbot request timed out or was cancelled. Please try again.", 0, "TIMEOUT");
        }
        if (error instanceof ChatApiError) throw error;
        throw new ChatApiError("Could not reach the chatbot server. Check its URL and connection, then try again.", 0, "NETWORK_ERROR");
      } finally {
        if (timer) clearTimeout(timer);
        signal?.removeEventListener?.("abort", forwardAbort);
      }
    }
  };
}

export { publicHttpsSources };
