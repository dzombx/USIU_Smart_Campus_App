import test from "node:test";
import assert from "node:assert/strict";
import { ChatApiError, createUSIUChatClient } from "../src/chat-client.js";

function jsonResponse(body, status = 200) {
  return { ok: status >= 200 && status < 300, status, json: async () => body };
}

test("maps the component request to the existing backend and adapts its response", async () => {
  let captured;
  const client = createUSIUChatClient({
    baseUrl: "https://chat.example.test/",
    timeoutMs: 0,
    fetchImpl: async (url, options) => {
      captured = { url, options, body: JSON.parse(options.body) };
      return jsonResponse({
        answer: "The campus has several student facilities.",
        sourceIds: ["facilities"],
        webSources: [
          { label: "USIU", url: "https://www.usiu.ac.ke/facilities" },
          { label: "Unsafe", url: "http://localhost/private" }
        ],
        destination: { id: "library", name: "Library" },
        speechLanguage: "en"
      });
    }
  });

  const result = await client.sendMessage({
    message: "  What facilities are available?  ",
    language: "en",
    history: [
      { role: "system", text: "discard" },
      { role: "user", text: "Earlier question" },
      { role: "assistant", text: "Earlier answer" }
    ]
  });

  assert.equal(captured.url, "https://chat.example.test/api/chat");
  assert.equal(captured.options.method, "POST");
  assert.equal(captured.options.headers["Content-Type"], "application/json");
  assert.deepEqual(captured.body, {
    question: "What facilities are available?",
    history: [
      { role: "user", text: "Earlier question" },
      { role: "assistant", text: "Earlier answer" }
    ],
    language: "en"
  });
  assert.equal(result.reply, "The campus has several student facilities.");
  assert.deepEqual(result.sources, [{ label: "USIU", url: "https://www.usiu.ac.ke/facilities" }]);
  assert.deepEqual(result.destination, { id: "library", name: "Library" });
  assert.equal(result.speechLanguage, "en");
});

test("uses same-origin /api/chat when no backend origin is configured", () => {
  const client = createUSIUChatClient({ timeoutMs: 0, fetchImpl: async () => jsonResponse({ answer: "ok" }) });
  assert.equal(client.endpoint, "/api/chat");
});

test("rejects invalid questions before making a network request", async () => {
  let called = false;
  const client = createUSIUChatClient({ fetchImpl: async () => { called = true; return jsonResponse({}); } });
  await assert.rejects(client.sendMessage({ message: "  " }), error => error instanceof ChatApiError && error.code === "INVALID_MESSAGE");
  await assert.rejects(client.sendMessage({ message: "x".repeat(501) }), error => error.status === 400);
  assert.equal(called, false);
});

test("preserves a useful JSON error and HTTP status", async () => {
  const client = createUSIUChatClient({ timeoutMs: 0, fetchImpl: async () => jsonResponse({ error: "Quota reached." }, 429) });
  await assert.rejects(
    client.sendMessage({ message: "What is happening?" }),
    error => error instanceof ChatApiError && error.status === 429 && error.message === "Quota reached."
  );
});

test("rejects an incomplete success response", async () => {
  const client = createUSIUChatClient({ timeoutMs: 0, fetchImpl: async () => jsonResponse({ answer: " " }) });
  await assert.rejects(client.sendMessage({ message: "Hello" }), error => error.code === "INVALID_RESPONSE");
});
