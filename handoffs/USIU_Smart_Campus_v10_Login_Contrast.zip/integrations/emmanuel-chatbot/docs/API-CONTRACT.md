# USIU Campus Chatbot API contract

This document describes the **current USIU chatbot backend**, not a hypothetical mock service. The React package adapts this API to a small component-facing contract.

## Endpoint

- Method: `POST`
- Path: `/api/chat`
- Content type: `application/json`
- Authentication: none in the current backend
- API key: `GEMINI_API_KEY` is read only by the Node.js server and must never be sent to the browser

### Request

```json
{
  "question": "What facilities are available?",
  "history": [
    { "role": "user", "text": "I am visiting campus." },
    { "role": "assistant", "text": "What would you like to know?" }
  ],
  "language": "en"
}
```

`question` is required and must contain 1–500 characters. The complete JSON body must not exceed 12,000 bytes. `history` is optional; accepted roles are `user` and `assistant`, and the backend keeps at most the last eight messages, trimming each message to 1,200 characters. `language` is optional and supports `auto`, `en`, `sw`, `fr`, `ar`, `so`, and `es`; unknown values are treated as `auto`.

The server does **not** accept `message` or `conversationId`. It is stateless: the React component retains the visible conversation in memory and sends recent history with each question. Nothing in this contract stores a conversation on the server.

### Success response

```json
{
  "answer": "USIU-Africa has ...",
  "sourceIds": ["facilities"],
  "webSources": [
    { "label": "Official page", "url": "https://www.usiu.ac.ke/example" }
  ],
  "destination": null,
  "speechLanguage": "en"
}
```

`sourceIds` are internal source identifiers, not URLs. The included React component renders safe HTTPS `webSources` automatically. To render the current application's local USIU source IDs as links, provide a `sourceResolver` callback that maps IDs to verified `{ label, url }` entries, or update the backend to return those links. `destination` may be `{ "id": "...", "name": "..." }` for a routable campus location. The component only forwards that value to the optional `onDestination` callback; it does not include a map.

### Error responses

Most errors use JSON:

```json
{ "error": "Human-readable error message" }
```

Common statuses from the current backend:

- `400`: invalid JSON or missing/invalid question
- `413`: request body too large
- `415`: request must use JSON
- `429`: backend per-IP rate limit or Gemini/Search grounding quota limit
- `502`: Gemini request failed
- `503`: `GEMINI_API_KEY` is missing in the backend environment

A non-POST request to `/api/chat` receives `405 Method Not Allowed` with `Allow: POST`; the current server does not include a JSON error body for that case. The in-memory server rate limiter allows up to 30 requests per IP per minute; this does not replace Google’s provider quotas.

## Backend environment and runtime

The current server reads:

- `GEMINI_API_KEY` — required secret, backend only
- `PORT` — optional listener port; defaults to `3000`

The existing backend uses Node.js `>=22` and `@google/genai` `3.0.0`, currently selects `gemini-3.6-flash`, and enables Google Search grounding. This integration ZIP **does not include the backend**, its credential, curated data, event catalog, or campus map. The current `server.js` imports those files from the existing chatbot repository, so copying `server.js` alone will not create a working backend. Deploy the existing backend intact or implement an API-compatible service in the host project.

## CORS and deployment topology

The current server does not send `Access-Control-Allow-Origin` and does not implement an `OPTIONS` preflight response. Its own frontend uses a same-origin relative URL. The simplest host integration is a same-origin reverse proxy from `/api/chat` to the existing chatbot backend.

If the backend must be called from another origin, the backend operator must add a narrow origin allow-list and respond to the browser preflight, for example:

```http
Access-Control-Allow-Origin: https://your-host-app.example
Vary: Origin
Access-Control-Allow-Methods: POST, OPTIONS
Access-Control-Allow-Headers: Content-Type
```

Replace the example origin with the real host origin. Do not expose the Gemini key in frontend configuration. The client does not use cookies or attach credentials.

## Frontend URL configuration

`createUSIUChatClient({ baseUrl })` expects the backend **origin**, without `/api/chat`. An empty string uses same-origin `/api/chat`. In a Vite host, `VITE_USIU_CHAT_API_BASE_URL` is read at build time. Other React build systems may require their own public-variable prefix; pass the resulting URL to the client. This variable is a URL, not a secret.
