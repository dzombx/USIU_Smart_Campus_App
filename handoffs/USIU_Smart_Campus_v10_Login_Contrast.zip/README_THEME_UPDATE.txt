USIU Smart Campus — audited consolidated UI and chatbot handoff

This package includes the refined USIU visual system, app-wide chatbot, and verification notes.

Chatbot:
- Persistent blue bottom-right launcher across authenticated sections.
- Dedicated Chat tab with a spacious full-screen chatbot page.
- Blue high-contrast user bubbles and yellow high-contrast assistant bubbles.
- Shared frosted-glass blur system across page, header, transcript, composer, controls, and launcher.
- Light/dark bubble and surface tokens.
- Same-origin POST /api/chat by default.
- Emmanuel’s API client tests pass: 5 passed, 0 failed.
- Backend, curated datasets, and GEMINI_API_KEY are not included in the frontend package.

Visual system:
- Explicit USIU blue, cobalt, sky-blue, navy, and yellow tokens.
- High-contrast light/dark tiles, calendar dates, selected dates, icons, and labels.
- Frosted-glass tile surfaces with layered gradients, inner highlights, dot-grid signal patterns, circular motifs, and line motifs.
- Editorial spacing and modular tile rhythm inspired by the supplied sybiosme.com reference without copying its layout, wording, branding, or brutalist palette.
- Lightweight tactile hover lift, press compression, focus feedback, and reduced-motion support.

Verification:
- App.tsx bundle parse passed with AppDeploy runtime externalized.
- index.css parse passed.
- Chatbot contract tests passed.
- No API keys, private keys, or secret tokens found.
- Backend integrity audit is included in BACKEND_INTEGRITY_AUDIT.md.
- The only difference from the earliest handoff is Marlies’ pre-existing demo-account/contact update, documented in the audit.
