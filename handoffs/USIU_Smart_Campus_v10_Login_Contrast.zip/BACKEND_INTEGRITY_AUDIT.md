# Backend integrity audit

The current UI/chatbot pass changed only frontend source and included chatbot integration files. The backend directory currently contains these hashes:

```text
a8edacafd722e6dd6b0caae067ace8415e8d8d226cca2fac10620a0f9ea9c376  source/backend/index.ts
e30693812a67dbc80332122f20f6ad349fdd200370e140a920cf6ec4dbe5a9e2  source/backend/realtime-subscribers.ts
6ddf726664ea9c7218c4668b476cc86945dca4293ed075e319c44c421bc86945dca4293ed075e319c44c421bc14384a  source/backend/realtime.ts
```

The `index.ts` difference compared with the earliest original handoff is pre-existing in Marlies’ later update. It changes placeholder demo identities to the team addresses and updates one lost-and-found contact:

- `admin-one@example.invalid` → `marlsadmin@usiu.edu`
- `admin-two@example.invalid` → `trevoradmin@usiu.edu`
- `admin-three@example.invalid` → `emmanueladmin@usiu.edu`
- `student-demo@example.invalid` → `studentdemo@usiu.edu`
- `demo-student@example.invalid` → `student@campus.edu`

Those values were already present in the updated handoff before this UI/chatbot pass. No backend file was edited by this pass.

No `.env` file is included. The credential-pattern scan found no API key, private key, Gemini key value, or secret token in the final source. Emmanuel’s chatbot package includes only an empty `.env.example`; `GEMINI_API_KEY` remains a backend-only requirement.
